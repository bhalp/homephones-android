package com.example.bhalprin.homephones;

/**
 * Modified by bhalprin on 11/14/2016.
 */

public class Userid {
    private int miId;
    private int miUserId;
    private int miOrigUserId;
    private String msUserName;
    private String msUserBrowsePwd;
    private String msUserUpatePwd;
    private String msUserInserted;
    private String msUserDeleted;
    private boolean mbSpecial = false;

    public Userid() {

    }

    public Userid(int iId, int iUserId, int iOrigUserId, String sUserName, String sUserBrowsePwd, String sUserUpdatePwd, String sUserInserted, String sUserDeleted, boolean bSpecial)
    {
        this.miId = iId;
        this.miUserId = iUserId;
        this.miOrigUserId = iOrigUserId;
        this.msUserName = sUserName;
        this.msUserBrowsePwd = sUserBrowsePwd;
        this.msUserUpatePwd = sUserUpdatePwd;
        this.msUserInserted = sUserInserted;
        this.msUserDeleted = sUserDeleted;
        this.mbSpecial = bSpecial;
    }

    public Userid(int iUserId, int iOrigUserId, String sUserName, String sUserBrowsePwd, String sUserUpdatePwd, String sUserInserted, String sUserDeleted, boolean bSpecial)
    {
        this.miUserId = iUserId;
        this.miOrigUserId = iOrigUserId;
        this.msUserName = sUserName;
        this.msUserBrowsePwd = sUserBrowsePwd;
        this.msUserUpatePwd = sUserUpdatePwd;
        this.msUserInserted = sUserInserted;
        this.msUserDeleted = sUserDeleted;
        this.mbSpecial = bSpecial;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public int getUserId()
    {
        return this.miUserId;
    }
    public void setUserId(int iValue)
    {
        this.miUserId = iValue;
    }
    public int getOrigUserId()
    {
        return this.miOrigUserId;
    }
    public void setOrigUserId(int iValue)
    {
        this.miOrigUserId = iValue;
    }
    public String getUserName()
    {
        return this.msUserName;
    }
    public void setUserName(String sValue)
    {
        this.msUserName = sValue;
    }
    public String getUserBrowsePwd()
    {
        return this.msUserBrowsePwd;
    }
    public void setUserBrowsePwd(String sValue)
    {
        this.msUserBrowsePwd = sValue;
    }
    public String getUserUpdatePwd()
    {
        return this.msUserUpatePwd;
    }
    public void setUserUpdatePwd(String sValue)
    {
        this.msUserUpatePwd = sValue;
    }
    public String getUserInserted()
    {
        return this.msUserInserted;
    }
    public void setUserInserted(String sValue)
    {
        this.msUserInserted = sValue;
    }
    public String getUserDeleted()
    {
        return this.msUserDeleted;
    }
    public void setUserDeleted(String sValue)
    {
        this.msUserDeleted = sValue;
    }
    public boolean getSpecial()
    {
        return this.mbSpecial;
    }
    public void setSpecial(boolean bValue)
    {
        this.mbSpecial = bValue;
    }

}
