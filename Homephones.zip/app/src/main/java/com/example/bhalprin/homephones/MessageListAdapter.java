package com.example.bhalprin.homephones;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.regex.Pattern;
import android.util.Log;



public class MessageListAdapter extends BaseAdapter {
    private ArrayList<String> listData;
    private LayoutInflater layoutInflater;
    private Boolean bDoingSelect = false;
    private ListView mListView;
    public Activity activity;
    public MessageListAdapter(Context aContext, Activity act, ArrayList<String> listData, Boolean bInDoingSelect, ListView lView) {
        this.listData = listData;
        this.mListView = lView;
        activity = act;
        layoutInflater = LayoutInflater.from(aContext);
        bDoingSelect = bInDoingSelect;
    }
    @Override
    public int getCount() {
        return listData.size();
    }
    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    public View getView(final int position, View v, ViewGroup vg) {
        final ViewHolder holder;
        if (v == null) {
            v = layoutInflater.inflate(R.layout.listrow_message, null);
            holder = new ViewHolder();
            holder.tvTimeLeft = (TextView) v.findViewById(R.id.tvTimeLeft);
            holder.tvTimeRight = (TextView) v.findViewById(R.id.tvTimeRight);
            holder.tvMessageLeft = (TextView) v.findViewById(R.id.tvMessageLeft);
            holder.tvMessageRight = (TextView) v.findViewById(R.id.tvMessageRight);
            holder.tvText = (TextView) v.findViewById(R.id.textViewMessage);
            holder.llMessageLeft = (ConstraintLayout) v.findViewById(R.id.llMessageLeft);
            holder.llMessageRight = (ConstraintLayout) v.findViewById(R.id.llMessageRight);
            holder.llMessageDate = (ConstraintLayout) v.findViewById(R.id.llMessageDate);
//            holder.etMessage = (EditText) v.findViewById(R.id.etMessage);
//            holder.btnSend = (Button) v.findViewById(R.id.btnSend);
            holder.chkSelectedLeft = (CheckBox) v.findViewById(R.id.chkSelectLeft);
            holder.chkSelectedRight = (CheckBox) v.findViewById(R.id.chkSelectRight);
            holder.chkSelectedDate = (CheckBox) v.findViewById(R.id.chkSelectDate);
            v.setTag(holder);
        } else {
            holder = (ViewHolder) v.getTag();
        }
        String sWords [];
        sWords = listData.get(position).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
        /*sWords will contain:
            1) "No messages yet"
            2) Date + FieldSeparator + 0 (not checked or 1 (checked)
            3) Me + FieldSeparator + the message + FieldSeparator + message db id + FieldSeparator + 0 (not checked or 1 (checked)
            4) To Contact Name + FieldSeparator + the message + FieldSeparator + message db id + FieldSeparator + 0 (not checked or 1 (checked)
        */
        if (sWords.length > 0) {
            if (sWords.length == 1) {
                //no messages yet
                holder.llMessageLeft.setVisibility(View.GONE);
                holder.llMessageRight.setVisibility(View.GONE);
                holder.llMessageDate.setVisibility(View.VISIBLE);

                holder.chkSelectedDate.setVisibility(View.GONE);
                holder.tvText.setText(sWords[0]);
            } else if (sWords.length < 3) {
                holder.llMessageLeft.setVisibility(View.GONE);
                holder.llMessageRight.setVisibility(View.GONE);
                holder.llMessageDate.setVisibility(View.VISIBLE);

//                holder.tvText.setVisibility(View.VISIBLE);
                holder.chkSelectedDate.setVisibility(View.GONE);
//                if (!bDoingSelect) {
//                    holder.chkSelectedDate.setVisibility(View.GONE);
//                } else {
//                    if (holder.chkSelectedRight.isChecked()) {
//                        if (sWords[1].equals("0")) {
//                            holder.chkSelectedRight.setChecked(false);
//                        }
//                    } else if (sWords[1].equals("0")) {
//                        holder.chkSelectedRight.setChecked(false);
//                    } else {
//                        holder.chkSelectedRight.setChecked(true);
//                    }
//                    holder.chkSelectedDate.setTag(position);
//                    holder.chkSelectedDate.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            Log.d("MessageListAdapter", "position = " + ((Integer)position).toString() + ", tag = " + ((Integer)v.getTag()).toString());
//                            String sTmp [] = listData.get((int)v.getTag()).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
//                            boolean bChecked = false;
//                            if (sTmp[1].equals("0")) {
//                                sTmp[1] = "1";
//                                bChecked = true;
//                            } else {
//                                sTmp[1] = "0";
//                            }
//                            listData.set((int)v.getTag(), sTmp[0] + MainActivity.gksMessageFieldSeparator +
//                                    sTmp[1]);
//
//                            //now set or clear all messages under this date
//                            int localPosition = (int)v.getTag() + 1;
//                            sTmp = listData.get(localPosition).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
//                            while (sTmp.length > 3) {
//                                if (bChecked) {
//                                    listData.set(localPosition, sTmp[0] + MainActivity.gksMessageFieldSeparator +
//                                            sTmp[1] + MainActivity.gksMessageFieldSeparator +
//                                            sTmp[2] + MainActivity.gksMessageFieldSeparator +
//                                            sTmp[3] + MainActivity.gksMessageFieldSeparator +
//                                            "1");
//
//                                } else {
//                                    listData.set(localPosition, sTmp[0] + MainActivity.gksMessageFieldSeparator +
//                                            sTmp[1] + MainActivity.gksMessageFieldSeparator +
//                                            sTmp[2] + MainActivity.gksMessageFieldSeparator +
//                                            sTmp[3] + MainActivity.gksMessageFieldSeparator +
//                                            "0");
//                                }
////                                mListView.setSelection(localPosition);
////                                ((CheckBox) vItem.findViewById(R.id.chkSelectDate)).setChecked(bChecked);
//                                localPosition++;
//                                if (localPosition == listData.size()) {
//                                    break;
//                                }
//                                sTmp = listData.get(localPosition).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
//                            }
//
//                        }
//                    });
//                }
                holder.tvText.setText(sWords[0]);
            } else if (sWords.length > 3) {
                holder.llMessageDate.setVisibility(View.GONE);
                if (sWords[1].equals("me")) {
                    holder.llMessageLeft.setVisibility(View.GONE);
                    holder.llMessageRight.setVisibility(View.VISIBLE);

                    if (!bDoingSelect) {
                        holder.chkSelectedRight.setVisibility(View.GONE);
                    } else {
                        if (sWords[4].equals("0")) {
                            holder.chkSelectedRight.setChecked(false);
                        } else {
                            holder.chkSelectedRight.setChecked(true);
                        }
                        holder.chkSelectedRight.setTag(position);
                        holder.chkSelectedRight.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String sTmp [] = listData.get((int)v.getTag()).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
                                if (sTmp[4].equals("0")) {
                                    sTmp[4] = "1";
                                    MessageActivity mActivity = (MessageActivity) mListView.getContext();
                                    mActivity.iNumSelectedToDelete++;
                                    mActivity.setTitle(mActivity.sBaseTitle
                                            + "      (" + mActivity.iNumSelectedToDelete.toString()
                                            + ")");
                                    mActivity.btnSend.setEnabled(true);
                                } else {
                                    sTmp[4] = "0";
                                    MessageActivity mActivity = (MessageActivity) mListView.getContext();
                                    mActivity.iNumSelectedToDelete--;
                                    if (mActivity.iNumSelectedToDelete > 0) {
                                        mActivity.setTitle(mActivity.sBaseTitle
                                                + "      (" + mActivity.iNumSelectedToDelete.toString()
                                                + ")");
                                        mActivity.btnSend.setEnabled(true);
                                    } else {
                                        mActivity.setTitle(mActivity.sBaseTitle);
                                        mActivity.btnSend.setEnabled(false);

                                    }
                                }
                                listData.set(position, sTmp[0] + MainActivity.gksMessageFieldSeparator +
                                                       sTmp[1] + MainActivity.gksMessageFieldSeparator +
                                                       sTmp[2] + MainActivity.gksMessageFieldSeparator +
                                                       sTmp[3] + MainActivity.gksMessageFieldSeparator +
                                                       sTmp[4]);
                            }
                        });
                    }

                    ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) holder.tvMessageRight.getLayoutParams();
                    params.matchConstraintMaxWidth = Integer.valueOf ( new Float(((Integer)MainActivity.dm.widthPixels).floatValue() * 0.75).intValue());
                    holder.tvMessageRight.setLayoutParams(params);

//                    holder.tvText.setVisibility (View.GONE);

                    holder.tvMessageRight.setText(sWords[2]);
                    holder.tvMessageRight.refreshDrawableState();
                    holder.tvTimeRight.setText(sWords[0] + " ");
                    holder.tvTimeRight.refreshDrawableState();
                } else {
                    holder.llMessageRight.setVisibility(View.GONE);
                    holder.llMessageDate.setVisibility(View.GONE);

                    if (!bDoingSelect) {
                        holder.chkSelectedLeft.setVisibility(View.GONE);
                    } else {
                        if (sWords[4].equals("0")) {
                            holder.chkSelectedLeft.setChecked(false);
                        } else {
                            holder.chkSelectedLeft.setChecked(true);
                        }
                    }
                    holder.chkSelectedLeft.setTag(position);
                    holder.chkSelectedLeft.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String sTmp [] = listData.get((int)v.getTag()).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
                            if (sTmp[4].equals("0")) {
                                sTmp[4] = "1";
                                MessageActivity mActivity = (MessageActivity) mListView.getContext();
                                mActivity.iNumSelectedToDelete++;
                                mActivity.setTitle(mActivity.sBaseTitle
                                        + "      (" + mActivity.iNumSelectedToDelete.toString()
                                        + ")");
                                mActivity.btnSend.setEnabled(true);
                            } else {
                                sTmp[4] = "0";
                                MessageActivity mActivity = (MessageActivity) mListView.getContext();
                                mActivity.iNumSelectedToDelete--;
                                if (mActivity.iNumSelectedToDelete > 0) {
                                    mActivity.setTitle(mActivity.sBaseTitle
                                            + "      (" + mActivity.iNumSelectedToDelete.toString()
                                            + ")");
                                    mActivity.btnSend.setEnabled(true);
                                } else {
                                    mActivity.setTitle(mActivity.sBaseTitle);
                                    mActivity.btnSend.setEnabled(false);
                                }
                            }
                            listData.set(position, sTmp[0] + MainActivity.gksMessageFieldSeparator +
                                    sTmp[1] + MainActivity.gksMessageFieldSeparator +
                                    sTmp[2] + MainActivity.gksMessageFieldSeparator +
                                    sTmp[3] + MainActivity.gksMessageFieldSeparator +
                                    sTmp[4]);
                        }
                    });

                    ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) holder.tvMessageLeft.getLayoutParams();
                    params.matchConstraintMaxWidth = Integer.valueOf ( new Float(((Integer)MainActivity.dm.widthPixels).floatValue() * 0.75).intValue());
                    holder.tvMessageLeft.setLayoutParams(params);

                    holder.llMessageLeft.setVisibility(View.VISIBLE);

//                    holder.tvText.setVisibility (View.GONE);

                    holder.tvMessageLeft.setText(sWords[2]);
                    holder.tvMessageLeft.refreshDrawableState();
                    holder.tvTimeLeft.setText(" " + sWords[0]);
                    holder.tvTimeLeft.refreshDrawableState();

                }

            } else {
                //shouldn't get here
                holder.llMessageLeft.setVisibility(View.GONE);
                holder.llMessageRight.setVisibility(View.GONE);
                holder.llMessageDate.setVisibility(View.VISIBLE);

                if (!bDoingSelect) {
                    holder.chkSelectedDate.setVisibility(View.GONE);
                }
//                holder.tvText.setVisibility(View.VISIBLE);
                holder.tvText.setText("Invalid data at position = " + ((Integer) position).toString());

            }

        }
//        if (position == (listData.size() - 1)) {
//            holder.btnSend.setTag(position);
//            holder.btnSend.setVisibility(View.VISIBLE);
//            holder.etMessage.setVisibility(View.VISIBLE);
//            holder.btnSend.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//                    ((MessageActivity) activity).iTryConnectCnt = 0;
//                    ((MessageActivity) activity).sMessageToSend = holder.etMessage.getText().toString().trim();
//                    ((MessageActivity) activity).StartThreadStart();
//                }
//            });
//        } else {
//            holder.btnSend.setVisibility(View.GONE);
//            holder.etMessage.setVisibility(View.GONE);
//        }
        return v;
    }
    static class ViewHolder {
        TextView tvTimeLeft;
        TextView tvTimeRight;
        TextView tvMessageLeft;
        TextView tvMessageRight;
        TextView tvText;
        ConstraintLayout llMessageLeft;
        ConstraintLayout llMessageRight;
        ConstraintLayout llMessageDate;
//        EditText etMessage;
//        Button btnSend;
        CheckBox chkSelectedLeft;
        CheckBox chkSelectedRight;
        CheckBox chkSelectedDate;
    }
}