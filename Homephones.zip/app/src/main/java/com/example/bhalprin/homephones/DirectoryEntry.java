package com.example.bhalprin.homephones;

import android.net.Uri;

import java.net.URI;

/**
 * Entity class that represents an directory entry.
 */
public class DirectoryEntry {
    public String directory;
    public String fileName;
    public String mimeType;
    public Long fileLength;
    public Uri uri;
}