package com.example.bhalprin.homephones;

public class TDSymbol {

    private int miId;
    private String msAccountId;
    private String msSymbol;
    private String msCurrentPrice;
    private String msShares;
    private String msGainLoss;

    public TDSymbol() {

    }

    public TDSymbol(int iId, String sAccountId, String sSymbol, String sCurrentPrice, String sShares, String sGainLoss)
    {
        this.miId = iId;
        this.msAccountId = sAccountId;
        this.msSymbol = sSymbol;
        this.msCurrentPrice = sCurrentPrice;
        this.msShares = sShares;
        this.msGainLoss = sGainLoss;
    }

    public TDSymbol(String sAccountId, String sSymbol, String sCurrentPrice, String sShares, String sGainLoss)
    {
        this.msAccountId = sAccountId;
        this.msSymbol = sSymbol;
        this.msCurrentPrice = sCurrentPrice;
        this.msShares = sShares;
        this.msGainLoss = sGainLoss;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public String getAccountId()
    {
        return this.msAccountId;
    }
    public void setAccountId(String sValue)
    {
        this.msAccountId = sValue;
    }
    public String getSymbol()
    {
        return this.msSymbol;
    }
    public void setSymbol(String sValue)
    {
        this.msSymbol = sValue;
    }
    public String getCurrentPrice()
    {
        return this.msCurrentPrice;
    }
    public void setCurrentPrice(String sValue)
    {
        this.msCurrentPrice = sValue;
    }
    public String getShares()
    {
        return this.msShares;
    }
    public void setShares(String sValue)
    {
        this.msShares = sValue;
    }
    public String getGainLoss()
    {
        return this.msGainLoss;
    }
    public void setGainLoss(String sValue) { this.msGainLoss = sValue; }

}
