package com.example.bhalprin.homephones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;

import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import java.util.regex.Pattern;

public class AddMessageContactActivity extends AppCompatActivity {


    private AddMessageContactAddTask mAddAddTask = null;
    private AddMessageContactUpdateTask mAddUpdateTask = null;
    private AddMessageContactDeleteTask mAddDeleteTask = null;

    private static final String TAG = "AddMessageContactActivity";

    // UI references.
    private EditText mMessageContactNameView;
    private EditText mMessageContactIPView;
    private View mProgressView;
    private View mLoginFormView;
    private String sID = "";

    private static final Pattern PARTIAl_IP_ADDRESS =
            Pattern.compile("^((25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9])\\.){0,3}"+
                    "((25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9])){0,1}$");


    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            boolean keepOriginal = true;
            StringBuilder sb = new StringBuilder(end - start);
            for (int i = start; i < end; i++) {
                char c = source.charAt(i);
                if (isCharAllowed(c)) // put your condition here
                    sb.append(c);
                else
                    keepOriginal = false;
            }
            if (keepOriginal)
                return null;
            else {
                if (source instanceof Spanned) {
                    SpannableString sp = new SpannableString(sb);
                    TextUtils.copySpansFrom((Spanned) source, start, sb.length(), null, sp, 0);
                    return sp;
                } else {
                    return sb;
                }
            }
        }

        private boolean isCharAllowed(char c)
        {
            if (c < 128)
            {
                return MainActivity.giAllowedCharsUserInfo[c] == 1;
            }
            else
            {
                return false;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_message_contact);
        // Set up the login form.
        mMessageContactNameView = (EditText) findViewById(R.id.addmessagecontactname);
        mMessageContactNameView.setFilters(new InputFilter[] { filter });
        mMessageContactIPView = (EditText) findViewById(R.id.addmessagecontactIP);

        mMessageContactIPView.addTextChangedListener(new TextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}

            private String mPreviousText = "";
            @Override
            public void afterTextChanged(Editable s) {
                if(PARTIAl_IP_ADDRESS.matcher(s).matches()) {
                    mPreviousText = s.toString();
                } else {
                    s.replace(0, s.length(), mPreviousText);
                }
            }
        });

        Intent data = getIntent();
        if (data.hasExtra("id"))
        {
            sID = data.getExtras().getString("id");
            mMessageContactNameView.setText(data.getExtras().getString("name"));
            mMessageContactIPView.setText(data.getExtras().getString("ip"));
        }

        Button mAddButton = (Button) findViewById(R.id.addmessagecontact_cmdAdd);
        mAddButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptAddMessageContact();
            }
        });
        if (!sID.equals(""))
        {
            Button mDeleteButton = (Button) findViewById(R.id.addmessagecontact_cmdUpdate);
            mDeleteButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    attemptUpdateMessageContact();
                }
            });

            Button mUpdateButton = (Button) findViewById(R.id.addmessagecontact_cmdDelete);
            mUpdateButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    attemptDeleteMessageContact();
                }
            });

            this.setTitle("Updating - " + mMessageContactNameView.getText());
        } else {
            Button mUpdateButton = (Button) findViewById(R.id.addmessagecontact_cmdDelete);
            mUpdateButton.setEnabled(false);
            Button mDeleteButton = (Button) findViewById(R.id.addmessagecontact_cmdUpdate);
            mDeleteButton.setEnabled(false);
            this.setTitle("Adding New Message Contact");
        }

        mLoginFormView = findViewById(R.id.addmessagecontact_form);
        mProgressView = findViewById(R.id.addmessagecontact_progress);

    }

    private void setReturnStatus (String sStatus)
    {
        Intent data = getIntent();
        data.putExtra("status", sStatus);
        setResult(RESULT_OK, data);
    }

    private void attemptAddMessageContact() {
        if (mAddAddTask != null) {
            return;
        }

        // Reset errors.
        mMessageContactNameView.setError(null);
        mMessageContactIPView.setError(null);

        // Store values at the time of the login attempt.
        String contactname = mMessageContactNameView.getText().toString();
        String contactIP = mMessageContactIPView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password.
        if (!isContactNameValid(contactIP)) {
            mMessageContactIPView.setError(getString(R.string.error_missing_ip));
            focusView = mMessageContactIPView;
            cancel = true;
        }

        // Check for a valid user name.
        if (!isContactNameValid(contactname)) {
            mMessageContactNameView.setError(getString(R.string.error_field_required));
            focusView = mMessageContactNameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {

            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mAddAddTask = new AddMessageContactAddTask();
                    mAddAddTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    mMessageContactNameView.requestFocus();
                }

            });
            altBx.show();
        }

    }

    private void attemptUpdateMessageContact() {
        if (mAddUpdateTask != null) {
            return;
        }

        // Reset errors.
        mMessageContactNameView.setError(null);
        mMessageContactIPView.setError(null);

        // Store values at the time of the login attempt.
        String contactname = mMessageContactNameView.getText().toString();
        String contactIP = mMessageContactIPView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password.
        if (!isContactNameValid(contactIP)) {
            mMessageContactIPView.setError(getString(R.string.error_missing_ip));
            focusView = mMessageContactIPView;
            cancel = true;
        }

        // Check for a valid user name.
        if (!isContactNameValid(contactname)) {
            mMessageContactNameView.setError(getString(R.string.error_field_required));
            focusView = mMessageContactNameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {

            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mAddUpdateTask = new AddMessageContactUpdateTask();
                    mAddUpdateTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    mMessageContactNameView.requestFocus();
                }

            });
            altBx.show();
        }

    }

    private void attemptDeleteMessageContact() {
        if (mAddDeleteTask != null) {
            return;
        }

        // Reset errors.
        mMessageContactNameView.setError(null);
        mMessageContactIPView.setError(null);

        AlertDialog.Builder altBx = new AlertDialog.Builder(this);
        altBx.setTitle("");
        altBx.setMessage("All messages relating to this contact will also be deleted. Continue to delete?");

        altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                // Show a progress spinner, and kick off a background task to
                // perform the user login attempt.
                showProgress(true);
                mAddDeleteTask = new AddMessageContactDeleteTask();
                mAddDeleteTask.execute((String) null);
            }
        });
        altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                mMessageContactNameView.requestFocus();
            }

        });
        altBx.show();

    }

    private boolean isContactNameValid(String contact) {
        return !(contact.length() < 1);
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }


    /**
     * Represents an asynchronous task used to insert a new user record.
     */
    public class AddMessageContactAddTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String contactName = mMessageContactNameView.getText().toString();
        String contactIP = mMessageContactIPView.getText().toString();
        int iNewUserid = 0;

        @Override
        protected String doInBackground(String... params) {
            try {

                MyDBHandlerMessage dbHandler = new MyDBHandlerMessage(AddMessageContactActivity.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                //check for duplicate contact name
                MessageContact contact = null;
                contact = dbHandler.findContact(contactName);
                if (!(contact == null))
                {
                    //contact already exists
                    return "2";
                }
                else
                {
                    contact = new MessageContact(contactName.toUpperCase(), contactIP,  sInsertDate, "");
                    dbHandler.addContact(contact);
                    return "1";
                }
            }
            catch (Exception e) {
                return e.getMessage(); //exception occurred
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mAddAddTask = null;
            showProgress(false);

            if (sStatus.equals("1")) {
                setReturnStatus(sStatus);
                finish();
            }
            else if (sStatus.equals("2"))
            {
                mMessageContactNameView.setError(getString(R.string.error_contact_already_exists));
                mMessageContactNameView.requestFocus();
            }
            else
            {
                mMessageContactNameView.setError(sStatus);
                mMessageContactNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mAddAddTask = null;
            showProgress(false);
        }
    }

    public class AddMessageContactUpdateTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String contactName = mMessageContactNameView.getText().toString();
        String contactIP = mMessageContactIPView.getText().toString();
        String dbID = sID;

        @Override
        protected String doInBackground(String... params) {
            try {

                MyDBHandlerMessage dbHandler = new MyDBHandlerMessage(AddMessageContactActivity.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                //check for duplicate contact name
                MessageContact contact = null;
                contact = dbHandler.findContact(contactName);
                if (!(contact == null))
                {
                    if (contact.getId() != Integer.parseInt(sID)) {
                        //contact already exists
                        return "2";
                    } else {
                        dbHandler.updateContact(sID, contactName, contactIP, sInsertDate );
                        return "1";
                    }
                }
                else
                {
                    dbHandler.updateContact(sID, contactName, contactIP, sInsertDate );
                    return "1";
                }
            }
            catch (Exception e) {
                return e.getMessage(); //exception occurred
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mAddUpdateTask = null;
            showProgress(false);

            if (sStatus.equals("1")) {
                setReturnStatus(sStatus);
                finish();
            }
            else if (sStatus.equals("2"))
            {
                mMessageContactNameView.setError(getString(R.string.error_contact_already_exists));
                mMessageContactNameView.requestFocus();
            }
            else
            {
                mMessageContactNameView.setError(sStatus);
                mMessageContactNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mAddUpdateTask = null;
            showProgress(false);
        }
    }

    public class AddMessageContactDeleteTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String dbID = sID;

        @Override
        protected String doInBackground(String... params) {
            try {

                MyDBHandlerMessage dbHandler = new MyDBHandlerMessage(AddMessageContactActivity.this, null, null, 1);
                String sDeleteDate = tu.CurrentUTCDateTime();

                if (dbHandler.deleteAllMessagesByContactId(sID, sDeleteDate)) {
                    if (dbHandler.deleteContact(sID, sDeleteDate )) {
                        return "1";
                    } else {
                        return getString(R.string.error_contact_delete_failed);
                    }
                } else {
                    return getString(R.string.error_contact_delete_failed);
                }

            }
            catch (Exception e) {
                return e.getMessage(); //exception occurred
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mAddDeleteTask = null;
            showProgress(false);

            if (sStatus.equals("1")) {
                setReturnStatus(sStatus);
                finish();
            }
            else
            {
                mMessageContactNameView.setError(sStatus);
                mMessageContactNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mAddDeleteTask = null;
            showProgress(false);
        }
    }

}

