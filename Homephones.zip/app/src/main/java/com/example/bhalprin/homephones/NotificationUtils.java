package com.example.bhalprin.homephones;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;

public class NotificationUtils {

    public static void GenerateNotification (String sTitle, String sMessage, Integer iMessageId, Intent intent,
                                             Boolean bUseIntent, Context context,
                                             NotificationManagerCompat notificationManager,
                                             int priority) {

        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
        bigTextStyle.setBigContentTitle(sTitle);
        bigTextStyle.bigText(sMessage);
        MainActivity.giMessageID++;
        if (bUseIntent) {
            PendingIntent pi = PendingIntent.getActivity(context,0,intent,0);
            Notification notification = new NotificationCompat.Builder(context)
                    .setSmallIcon(R.mipmap.ic_launcher_message) // notification icon
                    .setContentTitle(sTitle) // title for notification
                    .setContentText(sMessage) // message for notification
                    .setStyle(bigTextStyle)
                    .setPriority(priority)
                    .setContentIntent(pi)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .build(); // clear notification after click

            notificationManager.notify(MainActivity.giMessageID, notification);
        } else {
            Notification notification = new NotificationCompat.Builder(context)
                    .setSmallIcon(R.mipmap.ic_launcher_message) // notification icon
                    .setContentTitle(sTitle) // title for notification
                    .setContentText(sMessage) // message for notification
                    .setStyle(bigTextStyle)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setDefaults(Notification.DEFAULT_ALL)
                    .build(); // clear notification after click

            notificationManager.notify(MainActivity.giMessageID, notification);
        }

    }
}
