package com.example.bhalprin.homephones;

public class MessageData {

    private int miId;
    private int miDataFromContactID;
    private int miDataToContactID;
    private String msDataMessage;
    private String msDataInserted;
    private String msDataDeleted;

    public MessageData() {

    }

    public MessageData(int iId, int iFromContactID, int iToContactID, String sMessage, String sInserted,  String sDeleted)
    {
        this.miId = iId;
        this.miDataFromContactID = iFromContactID;
        this.miDataToContactID = iToContactID;
        this.msDataMessage = sMessage;
        this.msDataInserted = sInserted;
        this.msDataDeleted = sDeleted;
    }

    public MessageData(int iFromContactID, int iToContactID, String sMessage, String sInserted,  String sDeleted)
    {
        this.miDataFromContactID = iFromContactID;
        this.miDataToContactID = iToContactID;
        this.msDataMessage = sMessage;
        this.msDataInserted = sInserted;
        this.msDataDeleted = sDeleted;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public int getDataFromContactID()
    {
        return this.miDataFromContactID;
    }
    public void setDataFromContactID (int iValue)
    {
        this.miDataFromContactID = iValue;
    }
    public int getDataToContactID()
    {
        return this.miDataToContactID;
    }
    public void setDataToContactID (int iValue)
    {
        this.miDataToContactID = iValue;
    }
    public String getDataMessage()
    {
        return this.msDataMessage;
    }
    public void setDataMessage(String sValue)
    {
        this.msDataMessage = sValue;
    }
    public String getDataInserted()
    {
        return this.msDataInserted;
    }
    public void setDataInserted(String sValue)
    {
        this.msDataInserted = sValue;
    }
    public String getDataDeleted()
    {
        return this.msDataDeleted;
    }
    public void setDataDeleted(String sValue)
    {
        this.msDataDeleted = sValue;
    }

}
