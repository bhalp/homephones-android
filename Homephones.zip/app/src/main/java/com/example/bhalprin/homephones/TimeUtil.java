package com.example.bhalprin.homephones;
/**
 * Created by bhalprin on 11/5/2016.
 */
import android.text.format.DateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public class TimeUtil {

    public String CurrentUTCDateyyyy_MM_dd () {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdf.setTimeZone(new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC"));
        return sdf.format(new Date());
    }

    public String CurrentUTCDateTime () {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.US);
        sdf.setTimeZone(new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC"));
        return sdf.format(new Date());
    }

    public String CurrentUTCDateTimeAddMinutes (long lMinutes) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.US);
        sdf.setTimeZone(new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC"));

        Date dt = new Date();
        long t= dt.getTime();
        Date afterAddingMins = new Date(t + (lMinutes * 60000));

        return sdf.format(afterAddingMins);
    }

    public String CurrentUTCDateTimeFromDate (Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss000", Locale.US);
        sdf.setTimeZone(new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC"));
        return sdf.format(date);
    }

    public String CurrentDateTimeFromDate (Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm", Locale.US);
        return sdf.format(date);
    }

    public String CurrentDateTime () {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.US);
        return sdf.format(new Date());
    }

    public String CurrentDate () {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.US);
        return sdf.format(new Date());
    }

    public String CurrentDateFromDate (Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd", Locale.US);
        return sdf.format(date);
    }

    public String MyUTCToLocal(String datesToConvert, String sDateFormatOutput) {

        String dateToReturn = datesToConvert;

        String sDateFormatInput = "yyyyMMddHHmmssSSS";
        SimpleDateFormat sdf = new SimpleDateFormat(sDateFormatInput);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

        Date gmt = null;

        SimpleDateFormat sdfOutPutToSend = new SimpleDateFormat(sDateFormatOutput);
        sdfOutPutToSend.setTimeZone(TimeZone.getDefault());

        try {

            gmt = sdf.parse(datesToConvert);
            dateToReturn = sdfOutPutToSend.format(gmt);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        return dateToReturn; }

}
