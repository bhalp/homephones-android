package com.example.bhalprin.homephones;

/**
 * Created by bhalprin on 9/13/2016.
 */
import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.DataSetObserver;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.SparseArray;

public class MyDBHandlerMessage extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 9;
    private static final String DATABASE_NAME = "homeinfoMessageDB.db";

    public static final String TABLE_MESSAGE_CONTACTS = "messagecontacts";
    public static final String TABLE_MESSAGE_DATA = "messagedata";

    public static final String COLUMN_MESSAGE_CONTACTS_ID = "ID"; //the first record will always match the message name from setup
    public static final String COLUMN_MESSAGE_CONTACTS_Name = "ContactName";
    public static final String COLUMN_MESSAGE_CONTACTS_IP = "ContactIP"; //will be blank in first record
    public static final String COLUMN_MESSAGE_CONTACTS_Inserted = "ContactInserted";
    public static final String COLUMN_MESSAGE_CONTACTS_Deleted = "ContactDeleted";

    public static final int COLUMN_MESSAGE_CONTACTS_ID_IDX = 0;
    public static final int COLUMN_MESSAGE_CONTACTS_Name_IDX = 1;
    public static final int COLUMN_MESSAGE_CONTACTS_IP_IDX = 2;
    public static final int COLUMN_MESSAGE_CONTACTS_Inserted_IDX = 3;
    public static final int COLUMN_MESSAGE_CONTACTS_Deleted_IDX = 4;

    public static final String COLUMN_MESSAGE_DATA_ID = "ID";
    public static final String COLUMN_MESSAGE_DATA_FromContactID = "FromContactID";
    public static final String COLUMN_MESSAGE_DATA_ToContactID = "ToContactID";
    public static final String COLUMN_MESSAGE_DATA_Message = "Message";
    public static final String COLUMN_MESSAGE_DATA_Inserted = "Inserted";
    public static final String COLUMN_MESSAGE_DATA_Deleted = "Deleted";

    public static final int COLUMN_MESSAGE_DATA_ID_IDX = 0;
    public static final int COLUMN_MESSAGE_DATA_FromContact_ID_IDX = 1;
    public static final int COLUMN_MESSAGE_DATA_ToConctactID_IDX = 2;
    public static final int COLUMN_MESSAGE_DATA_Message_IDX = 3;
    public static final int COLUMN_MESSAGE_DATA_Inserted_IDX = 4;
    public static final int COLUMN_MESSAGE_DATA_Deleted_IDX = 5;

    Context callerContext;

    public MyDBHandlerMessage(Context context, String name,
                       SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
        callerContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        TimeUtil tu = new TimeUtil();
        String CREATE_MESSAGE_CONTACTS_TABLE = "CREATE TABLE " +
                TABLE_MESSAGE_CONTACTS + "("
                + COLUMN_MESSAGE_CONTACTS_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_MESSAGE_CONTACTS_Name + " TEXT collate nocase,"
                + COLUMN_MESSAGE_CONTACTS_IP + " TEXT collate nocase,"
                + COLUMN_MESSAGE_CONTACTS_Inserted + " TEXT collate nocase,"
                + COLUMN_MESSAGE_CONTACTS_Deleted + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_MESSAGE_CONTACTS_TABLE);

        //insert a record for me
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(callerContext);
        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_CONTACTS_Name, sharedPref.getString("message_name", "NoName"));
        values.put(COLUMN_MESSAGE_CONTACTS_IP, "");
        values.put(COLUMN_MESSAGE_CONTACTS_Inserted, tu.CurrentUTCDateTime());
        values.put(COLUMN_MESSAGE_CONTACTS_Deleted, "");

        db.insert(TABLE_MESSAGE_CONTACTS, null, values);

        String CREATE_MESSAGE_DATA_TABLE = "CREATE TABLE " +
                TABLE_MESSAGE_DATA + "("
                + COLUMN_MESSAGE_DATA_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_MESSAGE_DATA_FromContactID + " INTEGER,"
                + COLUMN_MESSAGE_DATA_ToContactID + " INTEGER,"
                + COLUMN_MESSAGE_DATA_Message + " TEXT collate nocase,"
                + COLUMN_MESSAGE_DATA_Inserted + " TEXT collate nocase,"
                + COLUMN_MESSAGE_DATA_Deleted + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_MESSAGE_DATA_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGE_CONTACTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MESSAGE_DATA);
        onCreate(db);
    }

    public void forceCreate ()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        onUpgrade(db, 0, 0);
    }

    public void addContact(MessageContact contact) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_CONTACTS_Name, contact.getContactName());
        values.put(COLUMN_MESSAGE_CONTACTS_IP, contact.getContactIP());
        values.put(COLUMN_MESSAGE_CONTACTS_Inserted, contact.getContactInserted());
        values.put(COLUMN_MESSAGE_CONTACTS_Deleted, contact.getContactDeleted());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_MESSAGE_CONTACTS, null, values);
        db.close();
    }

    public void addMessage(MessageData data) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_DATA_FromContactID, data.getDataFromContactID());
        values.put(COLUMN_MESSAGE_DATA_ToContactID, data.getDataToContactID());
        values.put(COLUMN_MESSAGE_DATA_Message, data.getDataMessage());
        values.put(COLUMN_MESSAGE_DATA_Inserted, data.getDataInserted());
        values.put(COLUMN_MESSAGE_DATA_Deleted, data.getDataDeleted());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_MESSAGE_DATA, null, values);
        db.close();
    }

    public boolean deleteAllMessagesByContactId(String sID, String sDeleted)
    {
        String [] sWhereArgs = {sID, sID};
        boolean bOK = true;

        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_DATA_Deleted, sDeleted);

        SQLiteDatabase db = this.getWritableDatabase();

//        bOK = db.update(TABLE_MESSAGE_DATA, values, "fromcontactid=? or tocontactid=?", sWhereArgs) > 0;
        db.update(TABLE_MESSAGE_DATA, values, "fromcontactid=? or tocontactid=?", sWhereArgs);

        db.close();
        return bOK;
    }

    public boolean deleteContact(String sID, String sDeleted)
    {
        String [] sWhereArgs = {sID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_CONTACTS_Deleted, sDeleted);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_MESSAGE_CONTACTS, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public boolean deleteMessage(String sID)
    {
        String [] sWhereArgs = {sID};
        boolean bOK = false;

        TimeUtil tu = new TimeUtil();
        String sDeleted = tu.CurrentUTCDateTime();

        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_DATA_Deleted, sDeleted);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_MESSAGE_DATA, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public MessageContact findContact(String sContactName) {
        String query = "Select * FROM " + TABLE_MESSAGE_CONTACTS + " WHERE "
                + "(" + COLUMN_MESSAGE_CONTACTS_Deleted + " is null or " + COLUMN_MESSAGE_CONTACTS_Deleted + " = \"\") and "
                + COLUMN_MESSAGE_CONTACTS_Name + " =  \"" + sContactName + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        MessageContact contact = new MessageContact();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            contact.setId(Integer.parseInt(cursor.getString(COLUMN_MESSAGE_CONTACTS_ID_IDX)));
            contact.setContactName(cursor.getString(COLUMN_MESSAGE_CONTACTS_Name_IDX));
            contact.setContactIP(cursor.getString(COLUMN_MESSAGE_CONTACTS_IP_IDX));
            contact.setContactInserted(cursor.getString(COLUMN_MESSAGE_CONTACTS_Inserted_IDX));
            contact.setContactDeleted(cursor.getString(COLUMN_MESSAGE_CONTACTS_Deleted_IDX));
            cursor.close();
        } else {
            contact = null;
        }
        db.close();
        return contact;
    }

    public MessageContact findContactById(String sId) {
        String query = "Select * FROM " + TABLE_MESSAGE_CONTACTS + " WHERE "
                + COLUMN_MESSAGE_CONTACTS_ID + " = " + sId;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        MessageContact contact = new MessageContact();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            contact.setId(Integer.parseInt(cursor.getString(COLUMN_MESSAGE_CONTACTS_ID_IDX)));
            contact.setContactName(cursor.getString(COLUMN_MESSAGE_CONTACTS_Name_IDX));
            contact.setContactIP(cursor.getString(COLUMN_MESSAGE_CONTACTS_IP_IDX));
            contact.setContactInserted(cursor.getString(COLUMN_MESSAGE_CONTACTS_Inserted_IDX));
            contact.setContactDeleted(cursor.getString(COLUMN_MESSAGE_CONTACTS_Deleted_IDX));
            cursor.close();
        } else {
            contact = null;
        }
        db.close();
        return contact;
    }

    public MessageContact findContactByIp(String sIp) {
        String query = "Select * FROM " + TABLE_MESSAGE_CONTACTS + " WHERE "
                + "(" + COLUMN_MESSAGE_CONTACTS_Deleted + " is null or " + COLUMN_MESSAGE_CONTACTS_Deleted + " = \"\") and "
                + COLUMN_MESSAGE_CONTACTS_IP + " = \"" + sIp + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        MessageContact contact = new MessageContact();

        Cursor cursor;
        try {
            cursor = db.rawQuery(query, null);
        } catch (SQLException e) {
            e.printStackTrace();
            db.close();
            return contact;
        }

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            contact.setId(Integer.parseInt(cursor.getString(COLUMN_MESSAGE_CONTACTS_ID_IDX)));
            contact.setContactName(cursor.getString(COLUMN_MESSAGE_CONTACTS_Name_IDX));
            contact.setContactIP(cursor.getString(COLUMN_MESSAGE_CONTACTS_IP_IDX));
            contact.setContactInserted(cursor.getString(COLUMN_MESSAGE_CONTACTS_Inserted_IDX));
            contact.setContactDeleted(cursor.getString(COLUMN_MESSAGE_CONTACTS_Deleted_IDX));
            cursor.close();
        }
        db.close();
        return contact;
    }

    public SparseArray<DataGroup> getAllMessageContacts() {
        int iCount = countContacts();
        TimeUtil tu = new TimeUtil();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_MESSAGE_CONTACTS + " WHERE "
                    + "(" + COLUMN_MESSAGE_CONTACTS_Deleted + " is null or " + COLUMN_MESSAGE_CONTACTS_Deleted + " = \"\")"
                    + " order by " + COLUMN_MESSAGE_CONTACTS_Name;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_MESSAGE_CONTACTS_ID_IDX);
                group.userid  = 1;
                group.string =  cursor.getString(COLUMN_MESSAGE_CONTACTS_Name_IDX);
                group.phone =  cursor.getString(COLUMN_MESSAGE_CONTACTS_IP_IDX);
                group.findPhoneNumbers();
                group.children.add("");
                group.misc = "";
                group.mapinfo = "";
                if (group.phone.equals("")) {
                    iCount = -1;
                } else {
                    groups.append(iCount, group);
                }
                while (cursor.moveToNext())
                {
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_MESSAGE_CONTACTS_ID_IDX);
                    group.userid  = 1;
                    group.string =  cursor.getString(COLUMN_MESSAGE_CONTACTS_Name_IDX);
                    group.phone =  cursor.getString(COLUMN_MESSAGE_CONTACTS_IP_IDX);
                    group.findPhoneNumbers();
                    group.children.add("");
                    group.misc = "";
                    group.mapinfo = "";
                    if (!group.phone.equals("")) {
                        iCount++;
                        groups.append(iCount, group);
                    }
                }
                cursor.close();

                //now add all messages for each contact
                String sMessages = "";
                if (groups.size() > 0) {
                    for (int idx = 0; idx < groups.size(); idx++) {
                        group = getAllMessagesForContact(groups.get(idx));

//                        group = groups.get(idx);
//                        query = "Select * FROM " + TABLE_MESSAGE_DATA + " WHERE "
//                                + "((" + COLUMN_MESSAGE_DATA_FromContactID + "=" + ((Integer) group.id).toString() + ") or "
//                                + "(" + COLUMN_MESSAGE_DATA_ToContactID + "=" + ((Integer) group.id).toString() + ")) and "
//                                + "(" + COLUMN_MESSAGE_DATA_Deleted + " is null or " + COLUMN_MESSAGE_DATA_Deleted + " = \"\")"
//                                + " order by " + COLUMN_MESSAGE_DATA_Inserted;
//
//
//                        cursor = db.rawQuery(query, null);
//                        iCount  = cursor.getCount();
//                        sMessages = "";
//
//                        group.messagechildren.clear();
//                        String sLastMessageDate = ""; // MMMddyyyy
//                        String sMsgTemp = "";
//
//                        if (cursor.moveToFirst()) {
//                            cursor.moveToFirst();
//                            iCount = 0;
//                            MessageData data = new MessageData();
//                            data.setId(cursor.getInt(COLUMN_MESSAGE_DATA_ID_IDX));
//                            data.setDataFromContactID(cursor.getInt(COLUMN_MESSAGE_DATA_FromContact_ID_IDX));
//                            data.setDataToContactID(cursor.getInt(COLUMN_MESSAGE_DATA_ToConctactID_IDX));
//                            data.setDataMessage(cursor.getString(COLUMN_MESSAGE_DATA_Message_IDX));
//                            data.setDataInserted(cursor.getString(COLUMN_MESSAGE_DATA_Inserted_IDX));
//
////                            sMsgTemp = data.getDataMessage();
////                            for (int idxTemp = 0; idxTemp < 5; idxTemp++) {
////                                sMsgTemp = sMsgTemp + "\n" + data.getDataMessage();
////                            }
////                            data.setDataMessage(sMsgTemp);
//
//                            //get the date of the message using the local timezone
//                            String sMsgDate = "";
//                            sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "MMMddyyyy");
//                            if (sMsgDate.equals(sLastMessageDate)) {
//                                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
//                            } else {
//                                sLastMessageDate = sMsgDate;
//                                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "EEEE MMMM d, yyyy");
//                                group.messagechildren.add(sMsgDate);
//                                sMessages = sMessages + sMsgDate + "\n";
//                                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
//                            }
//
//                            if (data.getDataFromContactID() == group.id) {
//                                // message from contact
//                                group.messagechildren.add(sMsgDate + MainActivity.gksMessageFieldSeparator + group.string + MainActivity.gksMessageFieldSeparator + data.getDataMessage());
//                                sMessages = sMessages + sMsgDate + MainActivity.gksMessageFieldSeparator + group.string + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
//                            } else {
//                                //message to contact
//                                group.messagechildren.add(sMsgDate + MainActivity.gksMessageFieldSeparator + "me" + MainActivity.gksMessageFieldSeparator + data.getDataMessage());
//                                sMessages = sMessages + sMsgDate + MainActivity.gksMessageFieldSeparator + "me" + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
//                            }
//                            while (cursor.moveToNext())
//                            {
//                                iCount++;
//                                data = new MessageData();
//                                data.setId(cursor.getInt(COLUMN_MESSAGE_DATA_ID_IDX));
//                                data.setDataFromContactID(cursor.getInt(COLUMN_MESSAGE_DATA_FromContact_ID_IDX));
//                                data.setDataToContactID(cursor.getInt(COLUMN_MESSAGE_DATA_ToConctactID_IDX));
//                                data.setDataMessage(cursor.getString(COLUMN_MESSAGE_DATA_Message_IDX));
//
//                                data.setDataInserted(cursor.getString(COLUMN_MESSAGE_DATA_Inserted_IDX));
//
//                                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "MMMddyyyy");
//                                if (sMsgDate.equals(sLastMessageDate)) {
//                                    sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
//                                } else {
//                                    sLastMessageDate = sMsgDate;
//                                    sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "EEEE MMMM d, yyyy");
//                                    group.messagechildren.add(sMsgDate);
//                                    sMessages = sMessages + "\n" + sMsgDate;
//                                    sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
//                                }
//
//                                if (data.getDataFromContactID() == group.id) {
//                                    // message from contact
//                                    group.messagechildren.add(sMsgDate + MainActivity.gksMessageFieldSeparator + group.string + MainActivity.gksMessageFieldSeparator + data.getDataMessage());
//                                    sMessages = sMessages + "\n" + sMsgDate + MainActivity.gksMessageFieldSeparator + group.string + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
//                                } else {
//                                    //message to contact
//                                    group.messagechildren.add(sMsgDate + MainActivity.gksMessageFieldSeparator + "me" + MainActivity.gksMessageFieldSeparator + data.getDataMessage());
//                                    sMessages = sMessages + "\n" + sMsgDate + MainActivity.gksMessageFieldSeparator + "me" + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
//                                }
//                            }
//                            cursor.close();
//
//                        }
//
//                        group.misc = sMessages;
                        groups.put(idx, group);
                    }

                }

            }
            db.close();
        }

        return groups;
    }

    public DataGroup getAllMessagesForContact(DataGroup group ) {
        int iCount = countContacts();
        TimeUtil tu = new TimeUtil();

        SQLiteDatabase db = this.getWritableDatabase();

        String query = "Select * FROM " + TABLE_MESSAGE_DATA + " WHERE "
                + "((" + COLUMN_MESSAGE_DATA_FromContactID + "=" + ((Integer) group.id).toString() + ") or "
                + "(" + COLUMN_MESSAGE_DATA_ToContactID + "=" + ((Integer) group.id).toString() + ")) and "
                + "(" + COLUMN_MESSAGE_DATA_Deleted + " is null or " + COLUMN_MESSAGE_DATA_Deleted + " = \"\")"
                + " order by " + COLUMN_MESSAGE_DATA_Inserted;


        Cursor cursor = db.rawQuery(query, null);
//        iCount  = cursor.getCount();
//        String sMessages = "";

        group.messagechildren.clear();
        String sLastMessageDate = ""; // MMMddyyyy
        String sMsgTemp = "";

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
//            iCount = 0;
            MessageData data = new MessageData();
            data.setId(cursor.getInt(COLUMN_MESSAGE_DATA_ID_IDX));
            data.setDataFromContactID(cursor.getInt(COLUMN_MESSAGE_DATA_FromContact_ID_IDX));
            data.setDataToContactID(cursor.getInt(COLUMN_MESSAGE_DATA_ToConctactID_IDX));
            data.setDataMessage(cursor.getString(COLUMN_MESSAGE_DATA_Message_IDX));
            data.setDataInserted(cursor.getString(COLUMN_MESSAGE_DATA_Inserted_IDX));

            //get the date of the message using the local timezone
            String sMsgDate = "";
            sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "MMMddyyyy");
            if (sMsgDate.equals(sLastMessageDate)) {
                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
            } else {
                sLastMessageDate = sMsgDate;
                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "EEEE MMMM d, yyyy");
                group.messagechildren.add(sMsgDate
                                    + MainActivity.gksMessageFieldSeparator + "0");

//                sMessages = sMessages + sMsgDate + "\n";
                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
            }

            if (data.getDataFromContactID() == group.id) {
                // message from contact
                group.messagechildren.add(sMsgDate
                                    + MainActivity.gksMessageFieldSeparator + group.string
                                    + MainActivity.gksMessageFieldSeparator + data.getDataMessage()
                                    + MainActivity.gksMessageFieldSeparator + ((Integer)data.getId()).toString()
                                    + MainActivity.gksMessageFieldSeparator + "0");
//                sMessages = sMessages + sMsgDate + MainActivity.gksMessageFieldSeparator + group.string + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
            } else {
                //message to contact
                group.messagechildren.add(sMsgDate
                        + MainActivity.gksMessageFieldSeparator + "me"
                        + MainActivity.gksMessageFieldSeparator + data.getDataMessage()
                        + MainActivity.gksMessageFieldSeparator + ((Integer)data.getId()).toString()
                        + MainActivity.gksMessageFieldSeparator + "0");
//                sMessages = sMessages + sMsgDate + MainActivity.gksMessageFieldSeparator + "me" + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
            }
            while (cursor.moveToNext())
            {
                iCount++;
                data = new MessageData();
                data.setId(cursor.getInt(COLUMN_MESSAGE_DATA_ID_IDX));
                data.setDataFromContactID(cursor.getInt(COLUMN_MESSAGE_DATA_FromContact_ID_IDX));
                data.setDataToContactID(cursor.getInt(COLUMN_MESSAGE_DATA_ToConctactID_IDX));
                data.setDataMessage(cursor.getString(COLUMN_MESSAGE_DATA_Message_IDX));

                data.setDataInserted(cursor.getString(COLUMN_MESSAGE_DATA_Inserted_IDX));

                sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "MMMddyyyy");
                if (sMsgDate.equals(sLastMessageDate)) {
                    sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
                } else {
                    sLastMessageDate = sMsgDate;
                    sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "EEEE MMMM d, yyyy");
                    group.messagechildren.add(sMsgDate
                            + MainActivity.gksMessageFieldSeparator + "0");
//                    sMessages = sMessages + "\n" + sMsgDate;
                    sMsgDate = tu.MyUTCToLocal(data.getDataInserted(), "h:mm a");
                }

                if (data.getDataFromContactID() == group.id) {
                    // message from contact
                    group.messagechildren.add(sMsgDate
                            + MainActivity.gksMessageFieldSeparator + group.string
                            + MainActivity.gksMessageFieldSeparator + data.getDataMessage()
                            + MainActivity.gksMessageFieldSeparator + ((Integer)data.getId()).toString()
                            + MainActivity.gksMessageFieldSeparator + "0");
//                    sMessages = sMessages + "\n" + sMsgDate + MainActivity.gksMessageFieldSeparator + group.string + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
                } else {
                    //message to contact
                    group.messagechildren.add(sMsgDate
                            + MainActivity.gksMessageFieldSeparator + "me"
                            + MainActivity.gksMessageFieldSeparator + data.getDataMessage()
                            + MainActivity.gksMessageFieldSeparator + ((Integer)data.getId()).toString()
                            + MainActivity.gksMessageFieldSeparator + "0");
//                    sMessages = sMessages + "\n" + sMsgDate + MainActivity.gksMessageFieldSeparator + "me" + MainActivity.gksMessageFieldSeparator + data.getDataMessage();
                }
            }
            cursor.close();

        }

//        group.misc = sMessages;
        db.close();

        return group;

    }

    public boolean updateContact(String dbID, String sContactName, String sContactIP, String sInserted)
    {
        String [] sWhereArgs = {dbID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_MESSAGE_CONTACTS_Name, sContactName);
        values.put(COLUMN_MESSAGE_CONTACTS_IP, sContactIP);
        values.put(COLUMN_MESSAGE_CONTACTS_Inserted, sInserted);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_MESSAGE_CONTACTS, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public int countContacts ()
    {
        String query = "Select Count(*) FROM " + TABLE_MESSAGE_CONTACTS;
        int iCount = 0;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst())
        {
            cursor.moveToFirst();
            iCount = cursor.getInt(0);
            cursor.close();
        }
        db.close();
        return iCount;
    }



}
