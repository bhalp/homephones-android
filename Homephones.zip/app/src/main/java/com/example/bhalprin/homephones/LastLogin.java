package com.example.bhalprin.homephones;

public class LastLogin {
    private int miId;
    private int miUserId;
    private int miUpdating;

    public LastLogin() {

    }

    public LastLogin(int iId, int iUserId, int iUpdating) {
        this.miId = iId;
        this.miUserId = iUserId;
        this.miUpdating = iUpdating;
    }

    public LastLogin(int iUserId, int iUpdating) {
        this.miUserId = iUserId;
        this.miUpdating = iUpdating;
    }

    public int getId() {
        return this.miId;
    }

    public void setId(int iValue) {
        this.miId = iValue;
    }

    public int getUserId() {
        return this.miUserId;
    }

    public void setUserId(int iValue) {
        this.miUserId = iValue;
    }

    public int getUpdating() {
        return this.miUpdating;
    }

    public void setUpdating(int iValue) {
        this.miUpdating = iValue;
    }

}