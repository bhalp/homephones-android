package com.example.bhalprin.homephones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;

import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.util.Log;
import android.util.Base64;

public class AddUser extends AppCompatActivity {

    private AdduserAddTask mAuthTask = null;
    private static final String TAG = "AddUserActivity";

    // UI references.
    private EditText mUsernameView;
    private EditText mPasswordView;
    private EditText mPasswordRetypeView;
    private EditText mUpdatePasswordView;
    private EditText mUpdatePasswordRetypeView;
    private View mProgressView;
    private View mLoginFormView;

    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            boolean keepOriginal = true;
            StringBuilder sb = new StringBuilder(end - start);
            for (int i = start; i < end; i++) {
                char c = source.charAt(i);
                if (isCharAllowed(c)) // put your condition here
                    sb.append(c);
                else
                    keepOriginal = false;
            }
            if (keepOriginal)
                return null;
            else {
                if (source instanceof Spanned) {
                    SpannableString sp = new SpannableString(sb);
                    TextUtils.copySpansFrom((Spanned) source, start, sb.length(), null, sp, 0);
                    return sp;
                } else {
                    return sb;
                }
            }
        }

        private boolean isCharAllowed(char c)
        {
            if (c < 128)
            {
                return MainActivity.giAllowedCharsUserInfo[c] == 1;
            }
            else
            {
                return false;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        // Set up the login form.
        mUsernameView = (EditText) findViewById(R.id.adduserusername);
        mUsernameView.setFilters(new InputFilter[] { filter });
        mPasswordView = (EditText) findViewById(R.id.adduserpassword);
        mPasswordView.setFilters(new InputFilter[] { filter });
        mPasswordRetypeView = (EditText) findViewById(R.id.adduserpassword_retype);
        mPasswordRetypeView.setFilters(new InputFilter[] { filter });
        mUpdatePasswordView = (EditText) findViewById(R.id.adduserupdatepassword);
        mUpdatePasswordView.setFilters(new InputFilter[] { filter });
        mUpdatePasswordRetypeView = (EditText) findViewById(R.id.adduserupdatepassword_retype);
        mUpdatePasswordRetypeView.setFilters(new InputFilter[] { filter });

        Button mAddButton = (Button) findViewById(R.id.adduser_cmdAdd);
        mAddButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                //uncomment so don't have to enter logon info when debugging
//                setUserID("3", "BOB", "xxxx", "xxxx", true);
//                finish();

                attemptAdduser();
            }
        });

        mLoginFormView = findViewById(R.id.adduser_form);
        mProgressView = findViewById(R.id.add_user_progress);

    }

    private void setUserID (String sValue, String sUsername, String sPassword, String sUpdatePassword,  boolean bUpdating)
    {
        Intent data = getIntent();
        data.putExtra("userid", sValue);
        data.putExtra("username", sUsername);
        data.putExtra("password", sPassword);
        data.putExtra("updatepassword", sUpdatePassword);
        data.putExtra("updating", bUpdating);
        setResult(RESULT_OK, data);
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptAdduser() {
        if (mAuthTask != null) {
            return;
        }

        // Reset errors.
        mUsernameView.setError(null);
        mPasswordView.setError(null);
        mPasswordRetypeView.setError(null);
        mUpdatePasswordView.setError(null);
        mUpdatePasswordRetypeView.setError(null);

        // Store values at the time of the login attempt.
        String username = mUsernameView.getText().toString();
        String password = mPasswordView.getText().toString();
        String passwordretype = mPasswordRetypeView.getText().toString();
        String updatepassword = mUpdatePasswordView.getText().toString();
        String updatepasswordretype = mUpdatePasswordRetypeView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password.
        if (!isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid password.
        if (!isPasswordValid(updatepassword)) {
            mUpdatePasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mUpdatePasswordView;
            cancel = true;
        }

        // Check for a matching passwords.
        if (!password.equals(passwordretype)) {
            mPasswordView.setError(getString(R.string.error_passwords_dont_match));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a matching updatepasswords.
        if (!updatepassword.equals(updatepasswordretype)) {
            mUpdatePasswordView.setError(getString(R.string.error_passwords_dont_match));
            focusView = mUpdatePasswordView;
            cancel = true;
        }

        // Check for a valid user name.
        if (TextUtils.isEmpty(username)) {
            mUsernameView.setError(getString(R.string.error_field_required));
            focusView = mUsernameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {

            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mAuthTask = new AdduserAddTask();
                    mAuthTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    mUsernameView.requestFocus();
                }

            });
            altBx.show();
        }

    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return !(password.length() < 1);
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }


    /**
     * Represents an asynchronous task used to insert a new user record.
     */
    public class AdduserAddTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String username = mUsernameView.getText().toString();
        String password = mPasswordView.getText().toString();
        String updatepassword = mUpdatePasswordView.getText().toString();
        int iNewUserid = 0;

        @Override
        protected String doInBackground(String... params) {
            try {

                MyDBHandler dbHandler = new MyDBHandler(AddUser.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                //check for duplicate username
                Userid us = null;
                us = dbHandler.findUserid(username);
                if (!(us == null))
                {
                    //username already exists
                    return "2";
                }
                else
                {
                    //get a new user id
                    iNewUserid = dbHandler.GetNextUserid();
                    if (iNewUserid == 0)
                    {
                        return "0"; //failure - could not get the next user id
                    }
                    else
                    {
                        String password64 = Base64.encodeToString( password.toUpperCase().getBytes(), Base64.DEFAULT );
                        String updatepassword64 = Base64.encodeToString( updatepassword.toUpperCase().getBytes(), Base64.DEFAULT );
                        if (iNewUserid == MainActivity.gkiInitialUserId) {
                            us = new Userid(iNewUserid, -1, username.toUpperCase(), password64.substring(0,password64.length() - 1), updatepassword64.substring(0,updatepassword64.length() - 1), sInsertDate, "", true);
                        } else {
                            us = new Userid(iNewUserid, -1, username.toUpperCase(), password64.substring(0,password64.length() - 1), updatepassword64.substring(0,updatepassword64.length() - 1), sInsertDate, "", false);
                        }
                        dbHandler.addUserid(us);
                        if (dbHandler.updateStatus(sInsertDate))
                        {
                            return "1";
                        }
                        else
                        {
                            return "3";
                        }
                    }
                }

            }
            catch (Exception e) {
                return e.getMessage(); //exception occurred
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mAuthTask = null;
            showProgress(false);

            if (sStatus.equals("1")) {
                setUserID(String.valueOf(iNewUserid), username, password, updatepassword, true);
                finish();
            }
            else if (sStatus.equals("0"))
            {
                mUsernameView.setError(getString(R.string.error_adduser_next_user_not_found));
                mUsernameView.requestFocus();
            }
            else if (sStatus.equals("2"))
            {
                mUsernameView.setError(getString(R.string.error_adduser_user_already_exists));
                mUsernameView.requestFocus();
            }
            else if (sStatus.equals("3"))
            {
                mUsernameView.setError(getString(R.string.error_adduser_update_updatestatus));
                mUsernameView.requestFocus();
            }
            else
            {
                mUsernameView.setError(sStatus);
                mUsernameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mAuthTask = null;
            showProgress(false);
        }
    }

}

