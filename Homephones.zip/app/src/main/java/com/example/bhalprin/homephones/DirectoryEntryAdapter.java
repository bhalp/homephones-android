package com.example.bhalprin.homephones;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.List;
/**
 * Provide views to RecyclerView with the directory entries.
 */
public class DirectoryEntryAdapter extends RecyclerView.Adapter<DirectoryEntryAdapter.ViewHolder> {
    static final String DIRECTORY_MIME_TYPE = "vnd.android.document/directory";
    private List<DirectoryEntry> mDirectoryEntries;
    private ItemClickListener mClickListener;

    /**
     * Provide a reference to the type of views that you are using (custom ViewHolder)
     */
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final TextView mFileName;
        private final TextView mMimeType;
        private final ImageView mImageView;
        public ViewHolder(View v) {
            super(v);
            mFileName = (TextView) v.findViewById(R.id.textview_filename);
            mMimeType = (TextView) v.findViewById(R.id.textview_mimetype);
            mImageView = (ImageView) v.findViewById(R.id.entry_image);

            v.setOnClickListener(this);

        }
        @Override
        public void onClick(View view) {
            if (mClickListener != null) mClickListener.onItemClick(view, getAdapterPosition());
        }

        public TextView getFileName() {
            return mFileName;
        }
        public TextView getMimeType() {
            return mMimeType;
        }
        public ImageView getImageView() {
            return mImageView;
        }
    }

    // convenience method for getting data at click position
    DirectoryEntry getItem(int id) {
        return mDirectoryEntries.get(id);
    }

    // allows clicks events to be caught
    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }
    /**
     * Initialize the directory entries of the Adapter.
     *
     * @param directoryEntries an array of {@link DirectoryEntry}.
     */
    public DirectoryEntryAdapter(List<DirectoryEntry> directoryEntries) {
        mDirectoryEntries = directoryEntries;
    }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.directory_item, viewGroup, false);
        return new ViewHolder(v);
    }
    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {
        viewHolder.getFileName().setText(mDirectoryEntries.get(position).fileName);
        viewHolder.getMimeType().setText(mDirectoryEntries.get(position).mimeType);
        if (DIRECTORY_MIME_TYPE.equals(mDirectoryEntries.get(position).mimeType)) {
            viewHolder.getImageView().setImageResource(R.mipmap.ic_directory_grey600_36dp);
        } else {
            viewHolder.getImageView().setImageResource(R.mipmap.ic_description_grey600_36dp);
        }
    }
    @Override
    public int getItemCount() {
        return mDirectoryEntries.size();
    }
    public void setDirectoryEntries(List<DirectoryEntry> directoryEntries) {
        mDirectoryEntries = directoryEntries;
    }
}
