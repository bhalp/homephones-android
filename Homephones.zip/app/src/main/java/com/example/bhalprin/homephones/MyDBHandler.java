package com.example.bhalprin.homephones;

/**
 * Created by bhalprin on 9/13/2016.
 */
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.SparseArray;

import java.lang.reflect.Array;

public class MyDBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 9;
    private static final String DATABASE_NAME = "homeinfoDB.db";
    private static final String TABLE_DISPLAY = "display";
    private static final String TABLE_USERID = "userid";
    private static final String TABLE_UPDATE_STATUS = "updatestatus";
    private static final String TABLE_LAST_LOGIN = "lastlogin";

    public static final String COLUMN_LASTLOGIN_ID = "ID";
    public static final String COLUMN_LASTLOGIN_UserID = "UserID";
    public static final String COLUMN_LASTLOGIN_Updating = "Updating";

    public static final int COLUMN_LASTLOGIN_ID_IDX = 0;
    public static final int COLUMN_LASTLOGIN_UserID_IDX = 1;
    public static final int COLUMN_LASTLOGIN_Updating_IDX = 2;

    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_MainDBID = "MainDBID";
    public static final String COLUMN_UserID = "UserID";
    public static final String COLUMN_NAME = "Name";
    public static final String COLUMN_PHONE = "Phone";
    public static final String COLUMN_MISC = "Misc";
    public static final String COLUMN_MAPINFO = "MapInfo";
    public static final String COLUMN_INSERTED = "INSERTED";
    public static final String COLUMN_DELETED = "DELETED";

    public static final int COLUMN_ID_IDX = 0;
    public static final int COLUMN_MainDBID_IDX = 1;
    public static final int COLUMN_UserID_IDX = 2;
    public static final int COLUMN_NAME_IDX = 3;
    public static final int COLUMN_PHONE_IDX = 4;
    public static final int COLUMN_MISC_IDX = 5;
    public static final int COLUMN_MAPINFO_IDX = 6;
    public static final int COLUMN_INSERTED_IDX = 7;
    public static final int COLUMN_DELETED_IDX = 8;


    public static final String COLUMN_USER_USERID = "UserID";
    public static final String COLUMN_USER_ORIGUSERID = "OrigUserID";
    public static final String COLUMN_USER_USERNAME = "UserName";
    public static final String COLUMN_USER_BROWSEPWD = "UserBrowsePwd";
    public static final String COLUMN_USER_UPDATEPWD = "UserUpdatePwd";
    public static final String COLUMN_USER_INSERTED = "UserInserted";
    public static final String COLUMN_USER_DELETED = "UserDeleted";
    public static final String COLUMN_USER_SPECIAL = "Special";

    public static final int COLUMN_USER_ID_IDX = 0;
    public static final int COLUMN_USER_USERID_IDX = 1;
    public static final int COLUMN_USER_ORIGUSERID_IDX = 2;
    public static final int COLUMN_USER_USERNAME_IDX = 3;
    public static final int COLUMN_USER_BROWSEPWD_IDX = 4;
    public static final int COLUMN_USER_UPDATEPWD_IDX = 5;
    public static final int COLUMN_USER_INSERTED_IDX = 6;
    public static final int COLUMN_USER_DELETED_IDX = 7;
    public static final int COLUMN_USER_SPECIAL_IDX = 8;


    public static final String COLUMN_US_LASTINSERTED = "LastInserted";
    public static final String COLUMN_US_LASTDELETED = "LastDeleted";
    public static final String COLUMN_US_ORIGLASTINSERTED = "OrigLastInserted";
    public static final String COLUMN_US_ORIGLASTDELETED = "OrigLastDeleted";

    public static final int COLUMN_US_ID_IDX = 0;
    public static final int COLUMN_US_LASTINSERTED_IDX = 1;
    public static final int COLUMN_US_LASTDELETED_IDX = 2;
    public static final int COLUMN_US_ORIGLASTINSERTED_IDX = 3;
    public static final int COLUMN_US_ORIGLASTDELETED_IDX = 4;


    public MyDBHandler(Context context, String name,
                       SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_DISPLAY_TABLE = "CREATE TABLE " +
                TABLE_DISPLAY + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_MainDBID + " INTEGER,"
                + COLUMN_UserID + " INTEGER,"
                + COLUMN_NAME + " TEXT collate nocase,"
                + COLUMN_PHONE + " TEXT collate nocase,"
                + COLUMN_MISC + " TEXT collate nocase,"
                + COLUMN_MAPINFO + " TEXT collate nocase,"
                + COLUMN_INSERTED + " TEXT collate nocase,"
                + COLUMN_DELETED + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_DISPLAY_TABLE);

        String CREATE_LASTLOGIN_TABLE = "CREATE TABLE " +
                TABLE_LAST_LOGIN + "("
                + COLUMN_LASTLOGIN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_LASTLOGIN_UserID + " INTEGER,"
                + COLUMN_LASTLOGIN_Updating + " INTEGER"
                + ")";
        db.execSQL(CREATE_LASTLOGIN_TABLE);

        //insert a record into the LASTLOGIN  table showing no one is currently logged in - userid = -1
        ContentValues values = new ContentValues();
        values.put(COLUMN_LASTLOGIN_UserID, -1);
        values.put(COLUMN_LASTLOGIN_Updating, 0);

        db.insert(TABLE_LAST_LOGIN, null, values);


        String CREATE_USERID_TABLE = "CREATE TABLE " +
                TABLE_USERID + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_USER_USERID + " INTEGER,"
                + COLUMN_USER_ORIGUSERID + " INTEGER,"
                + COLUMN_USER_USERNAME + " TEXT collate nocase,"
                + COLUMN_USER_BROWSEPWD + " TEXT collate nocase,"
                + COLUMN_USER_UPDATEPWD + " TEXT collate nocase,"
                + COLUMN_USER_INSERTED + " TEXT collate nocase,"
                + COLUMN_USER_DELETED + " TEXT collate nocase,"
                + COLUMN_USER_SPECIAL + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_USERID_TABLE);

        String CREATE_UPDATESTATUS_TABLE = "CREATE TABLE " +
                TABLE_UPDATE_STATUS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_US_LASTINSERTED + " TEXT collate nocase,"
                + COLUMN_US_LASTDELETED + " TEXT collate nocase,"
                + COLUMN_US_ORIGLASTINSERTED + " TEXT collate nocase,"
                + COLUMN_US_ORIGLASTDELETED + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_UPDATESTATUS_TABLE);

        //insert a blank record into the Update_status table
        values = new ContentValues();
        values.put(COLUMN_US_LASTINSERTED, "");
        values.put(COLUMN_US_LASTDELETED, "");
        values.put(COLUMN_US_ORIGLASTINSERTED, "");
        values.put(COLUMN_US_ORIGLASTDELETED, "");

        db.insert(TABLE_UPDATE_STATUS, null, values);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DISPLAY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERID);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_UPDATE_STATUS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LAST_LOGIN);
        onCreate(db);
    }

    public void forceCreate ()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        onUpgrade(db, 0, 0);
    }

    public void addDisplay(Display display) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_MainDBID, display.getDisplayMainDBId());
        values.put(COLUMN_UserID, display.getDisplayUserId());
        values.put(COLUMN_NAME, display.getDisplayName());
        values.put(COLUMN_PHONE, display.getDisplayPhone());
        values.put(COLUMN_MISC, display.getDisplayMisc());
        values.put(COLUMN_MAPINFO, display.getDisplayMapInfo());
        values.put(COLUMN_INSERTED, display.getDisplayInserted());
        values.put(COLUMN_DELETED, display.getDisplayDeleted());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_DISPLAY, null, values);
        db.close();
    }

    public void addDisplayAutoSync(String iMainDBId, String sUserId, String sName, String sPhone, String sMisc, String sMapInfo, String sInserted) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_MainDBID, iMainDBId);
        values.put(COLUMN_UserID, sUserId);
        values.put(COLUMN_NAME, sName);
        values.put(COLUMN_PHONE, sPhone);
        values.put(COLUMN_MISC, sMisc);
        values.put(COLUMN_MAPINFO, sMapInfo);
        values.put(COLUMN_INSERTED, sInserted);
        values.put(COLUMN_DELETED, "");

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_DISPLAY, null, values);
        db.close();
    }

    public void addUserIdAutoSync(String iMainDBId, String sUserId, String sUserName, String sBrowsePwd, String sUpdaePwd, String sSpecial, String sInserted) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ORIGUSERID, iMainDBId);
        values.put(COLUMN_USER_USERID, sUserId);
        values.put(COLUMN_USER_USERNAME, sUserName);
        values.put(COLUMN_USER_BROWSEPWD, sBrowsePwd);
        values.put(COLUMN_USER_UPDATEPWD, sUpdaePwd);
        values.put(COLUMN_USER_SPECIAL, sSpecial);
        values.put(COLUMN_USER_INSERTED, sInserted);
        values.put(COLUMN_USER_DELETED, "");

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_USERID, null, values);
        db.close();
    }

    public void addUserid(Userid userid) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERID, userid.getUserId());
        values.put(COLUMN_USER_ORIGUSERID, userid.getOrigUserId());
        values.put(COLUMN_USER_USERNAME, userid.getUserName());
        values.put(COLUMN_USER_BROWSEPWD, userid.getUserBrowsePwd());
        values.put(COLUMN_USER_UPDATEPWD, userid.getUserUpdatePwd());
        values.put(COLUMN_USER_INSERTED, userid.getUserInserted());
        values.put(COLUMN_USER_DELETED, userid.getUserDeleted());
        values.put(COLUMN_USER_SPECIAL, (userid.getSpecial() ? "1": ""));

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_USERID, null, values);
        db.close();
    }

    public void addUpdateStatus(UpdateStatus us) {

        String [] sWhereArgs = {"1"};
        ContentValues values = new ContentValues();
        values.put(COLUMN_US_LASTINSERTED, us.getLastInserted());
        values.put(COLUMN_US_LASTDELETED, us.getLastDeleted());
        values.put(COLUMN_US_ORIGLASTINSERTED, us.getLastInserted());
        values.put(COLUMN_US_ORIGLASTDELETED, us.getLastDeleted());

        SQLiteDatabase db = this.getWritableDatabase();

//        db.insert(TABLE_UPDATE_STATUS, null, values);
        db.update(TABLE_UPDATE_STATUS, values, "id=?", sWhereArgs);
        db.close();

    }

    public LastLogin findLastLogin() {
        String query = "Select * FROM " + TABLE_LAST_LOGIN ;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        LastLogin lastlogin = new LastLogin();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            lastlogin.setId(Integer.parseInt(cursor.getString(COLUMN_LASTLOGIN_ID_IDX)));
            lastlogin.setUserId(Integer.parseInt(cursor.getString(COLUMN_LASTLOGIN_UserID_IDX)));
            lastlogin.setUpdating(Integer.parseInt(cursor.getString(COLUMN_LASTLOGIN_Updating_IDX)));
            cursor.close();
        }
        db.close();
        return lastlogin;
    }

    public boolean updateLastLogin(LastLogin lastlogin)
    {
        boolean bOK = false;

        ContentValues values = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();
        values.put(COLUMN_LASTLOGIN_UserID, lastlogin.getUserId());
        values.put(COLUMN_LASTLOGIN_Updating, lastlogin.getUpdating());

        bOK = db.update(TABLE_LAST_LOGIN, values, null, null) > 0;

        db.close();
        return bOK;
    }

    public Userid findUserid(String sUserName) {
        String query = "Select * FROM " + TABLE_USERID + " WHERE "
                + COLUMN_USER_USERNAME + " =  \"" + sUserName + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        Userid userid = new Userid();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            userid.setId(Integer.parseInt(cursor.getString(COLUMN_USER_ID_IDX)));
            userid.setUserId(Integer.parseInt(cursor.getString(COLUMN_USER_USERID_IDX)));
            userid.setOrigUserId(Integer.parseInt(cursor.getString(COLUMN_USER_ORIGUSERID_IDX)));
            userid.setUserName(cursor.getString(COLUMN_USER_USERNAME_IDX));
            userid.setUserBrowsePwd(cursor.getString(COLUMN_USER_BROWSEPWD_IDX));
            userid.setUserUpdatePwd(cursor.getString(COLUMN_USER_UPDATEPWD_IDX));
            userid.setUserInserted(cursor.getString(COLUMN_USER_INSERTED_IDX));
            userid.setUserDeleted(cursor.getString(COLUMN_USER_DELETED_IDX));
            userid.setSpecial((cursor.getString(COLUMN_USER_SPECIAL_IDX).equals("1")));
            cursor.close();
        } else {
            userid = null;
        }
        db.close();
        return userid;
    }

    public Userid findUseridByUserId(Integer iUserId) {
        String query = "Select * FROM " + TABLE_USERID + " WHERE "
                + COLUMN_USER_USERID + " = " + iUserId.toString();

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        Userid userid = new Userid();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            userid.setId(Integer.parseInt(cursor.getString(COLUMN_USER_ID_IDX)));
            userid.setUserId(Integer.parseInt(cursor.getString(COLUMN_USER_USERID_IDX)));
            userid.setOrigUserId(Integer.parseInt(cursor.getString(COLUMN_USER_ORIGUSERID_IDX)));
            userid.setUserName(cursor.getString(COLUMN_USER_USERNAME_IDX));
            userid.setUserBrowsePwd(cursor.getString(COLUMN_USER_BROWSEPWD_IDX));
            userid.setUserUpdatePwd(cursor.getString(COLUMN_USER_UPDATEPWD_IDX));
            userid.setUserInserted(cursor.getString(COLUMN_USER_INSERTED_IDX));
            userid.setUserDeleted(cursor.getString(COLUMN_USER_DELETED_IDX));
            userid.setSpecial((cursor.getString(COLUMN_USER_SPECIAL_IDX).equals("1")));
            cursor.close();
        } else {
            userid = null;
        }
        db.close();
        return userid;
    }

    public UpdateStatus findUpdateStatus() {
        String query = "Select * FROM " + TABLE_UPDATE_STATUS;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        UpdateStatus us = new UpdateStatus();

        if (cursor.moveToLast()) {
            cursor.moveToLast();
            us.setId(Integer.parseInt(cursor.getString(COLUMN_US_ID_IDX)));
            us.setLastInserted(cursor.getString(COLUMN_US_LASTINSERTED_IDX));
            us.setLastDeleted(cursor.getString(COLUMN_US_LASTDELETED_IDX));
            us.setOrigLastInserted(cursor.getString(COLUMN_US_ORIGLASTINSERTED_IDX));
            us.setOrigLastDeleted(cursor.getString(COLUMN_US_ORIGLASTDELETED_IDX));
            cursor.close();
        } else {
            us = null;
        }
        db.close();
        return us;
    }

    public Cursor findAllUserid() {
        String query = "Select * FROM " + TABLE_USERID + " order by "
                + COLUMN_USER_USERNAME ;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);
        db.close();
        return cursor;
    }

    public int GetNextUserid() {
        String query = "Select * FROM " + TABLE_USERID + " order by "
                + COLUMN_USER_USERID + " desc";

        SQLiteDatabase db = this.getWritableDatabase();
        int iReturnValue = 0;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            iReturnValue = Integer.parseInt(cursor.getString(COLUMN_USER_USERID_IDX)) + 1;
        }
        else
        {
            iReturnValue = MainActivity.gkiInitialUserId;
        }
        cursor.close();
        db.close();
        return iReturnValue;
    }

    public SparseArray<DataGroup> GetSyncInfo() {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {

            UpdateStatus us = findUpdateStatus();
            SQLiteDatabase db = this.getWritableDatabase();
            String query = "";
            Cursor cursor;

            //are there any new user records
            //Inserted greater than OrigLastInserted and Deleted is null
            query = "Select * FROM " + TABLE_USERID + " WHERE "
                    + COLUMN_USER_ORIGUSERID + " = -1 and "
                    + COLUMN_USER_INSERTED + " > \"" + us.getOrigLastInserted() + "\" and "
                    + "(" + COLUMN_USER_DELETED + " is null or " + COLUMN_USER_DELETED + " = \"\")"
                    + " order by " + COLUMN_USER_USERNAME;

            cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (iCount > 0)
            {
                if (cursor.moveToFirst()) {
                    cursor.moveToFirst();
                    group = new DataGroup();
                    group.id = -1;
                    group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                    group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                    group.phone = cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                    group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                    group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                    group.sStatus = "InsertedUser";
                    group.sInserted = cursor.getString(COLUMN_USER_INSERTED_IDX);
                    groups.append(groups.size(), group);
                    while (cursor.moveToNext())
                    {
                        group = new DataGroup();
                        group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                        group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                        group.phone = cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                        group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                        group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                        group.sStatus = "InsertedUser";
                        group.sInserted = cursor.getString(COLUMN_USER_INSERTED_IDX);
                        groups.append(groups.size(), group);
                    }
                    cursor.close();
                }
                else
                {
                    cursor.close();
                }
            }
            else
            {
                cursor.close();
            }

            //are there any updated user records
            //Inserted greater than OrigLastInserted and OrigUserid != -1 and Deleted is null
            query = "Select * FROM " + TABLE_USERID + " WHERE "
                    + COLUMN_USER_ORIGUSERID + " > -1 and "
                    + COLUMN_USER_INSERTED + " > \"" + us.getOrigLastInserted() + "\" and "
                    + "(" + COLUMN_USER_DELETED + " is null or " + COLUMN_USER_DELETED + " = \"\")"
                    + " order by " + COLUMN_USER_USERNAME;

            cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (iCount > 0)
            {
                if (cursor.moveToFirst()) {
                    cursor.moveToFirst();
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_USER_ORIGUSERID_IDX);
                    group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                    group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                    group.phone = cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                    group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                    group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                    group.sStatus = "UpdatedUser";
                    group.sInserted = cursor.getString(COLUMN_USER_INSERTED_IDX);
                    groups.append(groups.size(), group);
                    while (cursor.moveToNext())
                    {
                        group = new DataGroup();
                        group.id = cursor.getInt(COLUMN_USER_ORIGUSERID_IDX);
                        group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                        group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                        group.phone = cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                        group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                        group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                        group.sStatus = "UpdatedUser";
                        group.sInserted = cursor.getString(COLUMN_USER_INSERTED_IDX);
                        groups.append(groups.size(), group);
                    }
                    cursor.close();
                }
                else
                {
                    cursor.close();
                }
            }
            else
            {
                cursor.close();
            }

            //are there any new records
            //Inserted greater than OrigLastInserted and Deleted is null and OrigId = -1
            query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_INSERTED + " > \"" + us.getOrigLastInserted() + "\" and "
                    + COLUMN_MainDBID + " = -1 and "
                    + "(" + COLUMN_DELETED + " is null or " + COLUMN_DELETED + " = \"\")"
                    + " order by " + COLUMN_NAME;

            cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (iCount > 0)
            {
                if (cursor.moveToFirst()) {
                    cursor.moveToFirst();
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    group.sStatus = "Inserted";
                    group.sInserted = cursor.getString(COLUMN_INSERTED_IDX);
                    groups.append(groups.size(), group);
                    while (cursor.moveToNext())
                    {
                        group = new DataGroup();
                        group.id = cursor.getInt(COLUMN_ID_IDX);
                        group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                        group.string =  cursor.getString(COLUMN_NAME_IDX);
                        group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                        group.findPhoneNumbers();
                        group.children.add(cursor.getString(COLUMN_MISC_IDX));
                        group.misc = cursor.getString(COLUMN_MISC_IDX);
                        group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                        group.sInserted = cursor.getString(COLUMN_INSERTED_IDX);
                        group.sStatus = "Inserted";
                        groups.append(groups.size(), group);
                    }
                    cursor.close();
                }
                else
                {
                    cursor.close();
                }
            }
            else
            {
                cursor.close();
            }

//            while (!cursor.isClosed())
//            {
//                try
//                {
//                    wait(500);
//                }
//                catch (Exception ex)
//                {
//
//                }
//            }

            //are there any deleted records
            //Inserted less than or equal to OrigLastInserted and Deleted is not null
            query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_INSERTED + " <= \"" + us.getOrigLastInserted() + "\" and "
                    + COLUMN_MainDBID + " > -1 and "
                    + COLUMN_DELETED + " > \"" + us.getOrigLastDeleted() + "\""
                    + " order by " + COLUMN_NAME;

            cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (iCount > 0)
            {
                if (cursor.moveToFirst()) {
                    cursor.moveToFirst();
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.iMainDBId = cursor.getInt(COLUMN_MainDBID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    group.sDeleted = cursor.getString(COLUMN_DELETED_IDX);
                    group.sStatus = "Deleted";
                    groups.append(groups.size(), group);
                    while (cursor.moveToNext())
                    {
                        group = new DataGroup();
                        group.id = cursor.getInt(COLUMN_ID_IDX);
                        group.iMainDBId = cursor.getInt(COLUMN_MainDBID_IDX);
                        group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                        group.string =  cursor.getString(COLUMN_NAME_IDX);
                        group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                        group.findPhoneNumbers();
                        group.children.add(cursor.getString(COLUMN_MISC_IDX));
                        group.misc = cursor.getString(COLUMN_MISC_IDX);
                        group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                        group.sDeleted = cursor.getString(COLUMN_DELETED_IDX);
                        group.sStatus = "Deleted";
                        groups.append(groups.size(), group);
                    }
                    cursor.close();
                }
                else
                {
                    cursor.close();
                }
            }
            else
            {
                cursor.close();
            }

//            while (!cursor.isClosed())
//            {
//                try
//                {
//                    wait(500);
//                }
//                catch (Exception ex)
//                {
//
//                }
//            }


            //are there any changed records
            //Inserted greater than OrigLastInserted and Deleted is null and OrigId not = -1
            query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_INSERTED + " > \"" + us.getOrigLastInserted() + "\" and "
                    + COLUMN_MainDBID + " > -1 and "
                    + "(" + COLUMN_DELETED + " is null or " + COLUMN_DELETED + " = \"\")"
                    + " order by " + COLUMN_NAME;

            cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (iCount > 0)
            {
                if (cursor.moveToFirst()) {
                    cursor.moveToFirst();
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.iMainDBId = cursor.getInt(COLUMN_MainDBID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    group.sInserted = cursor.getString(COLUMN_INSERTED_IDX);
                    group.sStatus = "Updated";
                    groups.append(groups.size(), group);
                    while (cursor.moveToNext())
                    {
                        group = new DataGroup();
                        group.id = cursor.getInt(COLUMN_ID_IDX);
                        group.iMainDBId = cursor.getInt(COLUMN_MainDBID_IDX);
                        group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                        group.string =  cursor.getString(COLUMN_NAME_IDX);
                        group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                        group.findPhoneNumbers();
                        group.children.add(cursor.getString(COLUMN_MISC_IDX));
                        group.misc = cursor.getString(COLUMN_MISC_IDX);
                        group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                        group.sInserted = cursor.getString(COLUMN_INSERTED_IDX);
                        group.sStatus = "Updated";
                        groups.append(groups.size(), group);
                    }
                    cursor.close();
                }
                else
                {
                    cursor.close();
                }
            }
            else
            {
                cursor.close();
            }

            db.close();
        }

        return groups;
    }


    public SparseArray<DataGroup> findAllDisplay(String sUserId, String sName) {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_UserID + " = " + sUserId + " and "
                    + COLUMN_NAME + " like  \"" + sName + "%\" and "
                    + "(" + COLUMN_DELETED + " is null or " + COLUMN_DELETED + " = \"\")"
                    + " order by " + COLUMN_NAME;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_ID_IDX);
                group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                group.string =  cursor.getString(COLUMN_NAME_IDX);
                group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                group.findPhoneNumbers();
                group.children.add(cursor.getString(COLUMN_MISC_IDX));
                group.misc = cursor.getString(COLUMN_MISC_IDX);
                group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<DataGroup> findAllDisplayByID (Integer iId) {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_ID + " = " + String.valueOf(iId)
                    + " order by " + COLUMN_NAME;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_ID_IDX);
                group.iMainDBId = cursor.getInt(COLUMN_MainDBID_IDX);
                group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                group.string =  cursor.getString(COLUMN_NAME_IDX);
                group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                group.findPhoneNumbers();
                group.children.add(cursor.getString(COLUMN_MISC_IDX));
                group.misc = cursor.getString(COLUMN_MISC_IDX);
                group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<DataGroup> findAllDisplayByMainID (Integer iId) {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_MainDBID + " = " + String.valueOf(iId)
                    + " order by " + COLUMN_NAME;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_ID_IDX);
                group.iMainDBId = cursor.getInt(COLUMN_MainDBID_IDX);
                group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                group.string =  cursor.getString(COLUMN_NAME_IDX);
                group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                group.findPhoneNumbers();
                group.children.add(cursor.getString(COLUMN_MISC_IDX));
                group.misc = cursor.getString(COLUMN_MISC_IDX);
                group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<DataGroup> findAllDisplayDeleted(String sUserId) {
        int iCount = count();
        String sDeleteDate = "";
        TimeUtil tu = new TimeUtil();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_UserID + " = " + sUserId + " and "
                    + "not (" + COLUMN_DELETED + " is null or " + COLUMN_DELETED + " = \"\")"
                    + " order by " + COLUMN_NAME;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();

                group.sDeleted = cursor.getString(COLUMN_DELETED_IDX);
                sDeleteDate = " (" + tu.MyUTCToLocal(group.sDeleted, "M/d/yy H:mm") + ")";

                group.id = cursor.getInt(COLUMN_ID_IDX);
                group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                group.string =  cursor.getString(COLUMN_NAME_IDX) + sDeleteDate;
                group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                group.findPhoneNumbers();
                group.children.add(cursor.getString(COLUMN_MISC_IDX));
                group.misc = cursor.getString(COLUMN_MISC_IDX);
                group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();

                    group.sDeleted = cursor.getString(COLUMN_DELETED_IDX);
                    sDeleteDate = " (" + tu.MyUTCToLocal(group.sDeleted, "M/d/yy H:mm") + ")";

                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX) + sDeleteDate;
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<Display> findAllDisplayRecords() {
        int iCount = count();
        SparseArray<Display> groups = new SparseArray<Display>();
        Display group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_DISPLAY
                    + " order by " + COLUMN_NAME;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new Display();
                group.setId(cursor.getInt(COLUMN_ID_IDX));
                group.setMainDBId(cursor.getInt(COLUMN_MainDBID_IDX));
                group.setUserId(cursor.getInt(COLUMN_UserID_IDX));
                group.setName(cursor.getString(COLUMN_NAME_IDX));
                group.setPhone(cursor.getString(COLUMN_PHONE_IDX));
                group.setMisc(cursor.getString(COLUMN_MISC_IDX));
                group.setMapInfo(cursor.getString(COLUMN_MAPINFO_IDX));
                group.setInserted(cursor.getString(COLUMN_INSERTED_IDX));
                group.setDeleted(cursor.getString(COLUMN_DELETED_IDX));
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new Display();
                    group.setId(cursor.getInt(COLUMN_ID_IDX));
                    group.setMainDBId(cursor.getInt(COLUMN_MainDBID_IDX));
                    group.setUserId(cursor.getInt(COLUMN_UserID_IDX));
                    group.setName(cursor.getString(COLUMN_NAME_IDX));
                    group.setPhone(cursor.getString(COLUMN_PHONE_IDX));
                    group.setMisc(cursor.getString(COLUMN_MISC_IDX));
                    group.setMapInfo(cursor.getString(COLUMN_MAPINFO_IDX));
                    group.setInserted(cursor.getString(COLUMN_INSERTED_IDX));
                    group.setDeleted(cursor.getString(COLUMN_DELETED_IDX));
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<DataGroup> findAllDisplaySpecial(String sUserId, String sName) {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_DISPLAY + " WHERE "
                    + COLUMN_UserID + " = " + sUserId + " and ("
                    + COLUMN_NAME + " like  \"%" + sName + "%\" or "
                    + COLUMN_PHONE + " like \"%" + sName + "%\" or "
                    + COLUMN_MISC + " like \"%" + sName + "%\" ) and"
                    + "(" + COLUMN_DELETED + " is null or " + COLUMN_DELETED + " = \"\")"
                    + " order by " + COLUMN_NAME;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_ID_IDX);
                group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                group.string =  cursor.getString(COLUMN_NAME_IDX);
                group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                group.findPhoneNumbers();
                group.children.add(cursor.getString(COLUMN_MISC_IDX));
                group.misc = cursor.getString(COLUMN_MISC_IDX);
                group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_ID_IDX);
                    group.userid  = cursor.getInt(COLUMN_UserID_IDX);
                    group.string =  cursor.getString(COLUMN_NAME_IDX);
                    group.phone =  cursor.getString(COLUMN_PHONE_IDX);
                    group.findPhoneNumbers();
                    group.children.add(cursor.getString(COLUMN_MISC_IDX));
                    group.misc = cursor.getString(COLUMN_MISC_IDX);
                    group.mapinfo = cursor.getString(COLUMN_MAPINFO_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<Userid> findAllUsers () {
        int iCount = count();
        SparseArray<Userid> groups = new SparseArray<Userid>();
        Userid group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_USERID
                    + " order by " + COLUMN_USER_USERID;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new Userid();
                group.setId(cursor.getInt(COLUMN_USER_ID_IDX));
                group.setOrigUserId(cursor.getInt(COLUMN_USER_ORIGUSERID_IDX));
                group.setUserId(cursor.getInt(COLUMN_USER_USERID_IDX));
                group.setUserName(cursor.getString(COLUMN_USER_USERNAME_IDX));
                group.setUserBrowsePwd(cursor.getString(COLUMN_USER_BROWSEPWD_IDX));
                group.setUserUpdatePwd(cursor.getString(COLUMN_USER_UPDATEPWD_IDX));
                group.setUserDeleted(cursor.getString(COLUMN_USER_DELETED_IDX));
                group.setUserInserted(cursor.getString(COLUMN_USER_INSERTED_IDX));

                if (cursor.getString(COLUMN_USER_SPECIAL_IDX).equals("1")) {
                    group.setSpecial(true);
                } else {
                    group.setSpecial(false);
                }
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new Userid();
                    group.setId(cursor.getInt(COLUMN_USER_ID_IDX));
                    group.setOrigUserId(cursor.getInt(COLUMN_USER_ORIGUSERID_IDX));
                    group.setUserId(cursor.getInt(COLUMN_USER_USERID_IDX));
                    group.setUserName(cursor.getString(COLUMN_USER_USERNAME_IDX));
                    group.setUserBrowsePwd(cursor.getString(COLUMN_USER_BROWSEPWD_IDX));
                    group.setUserUpdatePwd(cursor.getString(COLUMN_USER_UPDATEPWD_IDX));
                    group.setUserDeleted(cursor.getString(COLUMN_USER_DELETED_IDX));
                    group.setUserInserted(cursor.getString(COLUMN_USER_INSERTED_IDX));
                    if (cursor.getString(COLUMN_USER_SPECIAL_IDX).equals("1")) {
                        group.setSpecial(true);
                    } else {
                        group.setSpecial(false);
                    }
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<DataGroup> findAllUsersByID (Integer iId) {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_USERID + " WHERE "
                    + COLUMN_USER_USERID + " = " + String.valueOf(iId)
                    + " order by " + COLUMN_USER_USERID;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_USER_ID_IDX);
                group.iMainDBId = cursor.getInt(COLUMN_USER_ORIGUSERID_IDX);
                group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                group.phone =  cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_USER_ID_IDX);
                    group.iMainDBId = cursor.getInt(COLUMN_USER_ORIGUSERID_IDX);
                    group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                    group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                    group.phone =  cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                    group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                    group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public SparseArray<DataGroup> findAllUsersByMainID (Integer iId) {
        int iCount = count();
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        if (iCount > 0)
        {
            String query = "Select * FROM " + TABLE_USERID + " WHERE "
                    + COLUMN_USER_ORIGUSERID + " = " + String.valueOf(iId)
                    + " order by " + COLUMN_USER_USERID;

            SQLiteDatabase db = this.getWritableDatabase();

            Cursor cursor = db.rawQuery(query, null);
            iCount  = cursor.getCount();
            if (cursor.moveToFirst()) {
                cursor.moveToFirst();
                iCount = 0;
                group = new DataGroup();
                group.id = cursor.getInt(COLUMN_USER_ID_IDX);
                group.iMainDBId = cursor.getInt(COLUMN_USER_ORIGUSERID_IDX);
                group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                group.phone =  cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                groups.append(iCount, group);
                while (cursor.moveToNext())
                {
                    iCount++;
                    group = new DataGroup();
                    group.id = cursor.getInt(COLUMN_USER_ID_IDX);
                    group.iMainDBId = cursor.getInt(COLUMN_USER_ORIGUSERID_IDX);
                    group.userid  = cursor.getInt(COLUMN_USER_USERID_IDX);
                    group.string =  cursor.getString(COLUMN_USER_USERNAME_IDX);
                    group.phone =  cursor.getString(COLUMN_USER_BROWSEPWD_IDX);
                    group.misc = cursor.getString(COLUMN_USER_UPDATEPWD_IDX);
                    group.mapinfo = cursor.getString(COLUMN_USER_SPECIAL_IDX);
                    groups.append(iCount, group);
                }
                cursor.close();
            }
            db.close();
        }

        return groups;
    }

    public boolean addDisplay (String sUserID, String sName, String sPhone, String sMisc, String sMapInfo, String sInserted)
    {
        boolean bOK = false;
        ContentValues values = new ContentValues();

        values.put(COLUMN_MainDBID, -1);
        values.put(COLUMN_UserID, sUserID);
        values.put(COLUMN_NAME, sName);
        values.put(COLUMN_PHONE, sPhone);
        values.put(COLUMN_MISC, sMisc);
        values.put(COLUMN_MAPINFO, sMapInfo);
        values.put(COLUMN_INSERTED, sInserted);

        SQLiteDatabase db = this.getWritableDatabase();

        long isAdded = db.insert(TABLE_DISPLAY, null, values);
        if (isAdded == -1)
        {
            bOK = false;
        }
        else
        {
            bOK = true;
        }

        if (bOK)
        {
            values.clear();
            values.put(COLUMN_US_LASTINSERTED, sInserted);

            bOK = db.update(TABLE_UPDATE_STATUS, values, null, null) > 0;
        }

        db.close();
        return bOK;

    }

    public boolean deleteDisplay(String sID, String sDeleted)
    {

        String [] sWhereArgs = {sID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_DELETED, sDeleted);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_DISPLAY, values, "id=?", sWhereArgs) > 0;

        if (bOK)
        {
            values.clear();
            values.put(COLUMN_US_LASTDELETED, sDeleted);

            bOK = db.update(TABLE_UPDATE_STATUS, values, null, null) > 0;
        }

        db.close();
        return bOK;
    }

    public boolean deleteDisplayNoStatusUpdate(String sID, String sDeleted)
    {

        String [] sWhereArgs = {sID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_DELETED, sDeleted);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_DISPLAY, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public boolean updateDisplayMainDBId(String sID, String sMainDBId)
    {
        String [] sWhereArgs = {sID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_MainDBID, sMainDBId);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_DISPLAY, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }


    public boolean updateDisplay(String dbID, String sName, String sPhone, String sMisc, String sMapInfo, String sInserted)
    {

        String [] sWhereArgs = {dbID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, sName);
        values.put(COLUMN_PHONE, sPhone);
        values.put(COLUMN_MISC, sMisc);
        values.put(COLUMN_MAPINFO, sMapInfo);
        values.put(COLUMN_INSERTED, sInserted);
        values.put(COLUMN_DELETED, "");

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_DISPLAY, values, "id=?", sWhereArgs) > 0;

        if (bOK)
        {
            values.clear();
            values.put(COLUMN_US_LASTINSERTED, sInserted);

            bOK = db.update(TABLE_UPDATE_STATUS, values, null, null) > 0;
        }

        db.close();
        return bOK;
    }

    public boolean updateDisplayNoStatusUpdate(String dbID, String sName, String sPhone, String sMisc, String sMapInfo, String sInserted)
    {

        String [] sWhereArgs = {dbID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, sName);
        values.put(COLUMN_PHONE, sPhone);
        values.put(COLUMN_MISC, sMisc);
        values.put(COLUMN_MAPINFO, sMapInfo);
        values.put(COLUMN_INSERTED, sInserted);
        values.put(COLUMN_DELETED, "");

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_DISPLAY, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public boolean updateUserIDNoStatusUpdate(String dbID, String sUserName, String sBrowsePwd, String sUpdatePwd, String sSpecial, String sInserted)
    {

        String [] sWhereArgs = {dbID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_BROWSEPWD, sBrowsePwd);
        values.put(COLUMN_USER_UPDATEPWD, sUpdatePwd);
        values.put(COLUMN_USER_USERNAME, sUserName);
        values.put(COLUMN_USER_SPECIAL, sSpecial);
        values.put(COLUMN_USER_INSERTED, sInserted);
        values.put(COLUMN_USER_DELETED, "");

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_USERID, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public boolean updateUserIdMainDBId(String sID, String sMainDBId)
    {
        String [] sWhereArgs = {sID};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERID, sMainDBId);
        values.put(COLUMN_USER_ORIGUSERID, sMainDBId);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_USERID, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public boolean updateStatus(String sInserted)
    {
        boolean bOK = false;

        ContentValues values = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();
        values.put(COLUMN_US_LASTINSERTED, sInserted);

        bOK = db.update(TABLE_UPDATE_STATUS, values, null, null) > 0;

        db.close();
        return bOK;
    }

    public boolean updateStatus(String sInserted, String sDeleted)
    {
        boolean bOK = false;

        ContentValues values = new ContentValues();
        SQLiteDatabase db = this.getWritableDatabase();
        values.put(COLUMN_US_LASTINSERTED, sInserted);
        values.put(COLUMN_US_LASTDELETED, sDeleted);
        values.put(COLUMN_US_ORIGLASTINSERTED, sInserted);
        values.put(COLUMN_US_ORIGLASTDELETED, sDeleted);

        bOK = db.update(TABLE_UPDATE_STATUS, values, null, null) > 0;

        db.close();
        return bOK;
    }

    public boolean updateUserid(String sUserid, String sUsername, String sBrowsePwd, String sUpdatePwd, String sInserted)
    {

        String [] sWhereArgs = {sUserid};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_BROWSEPWD, sBrowsePwd);
        values.put(COLUMN_USER_UPDATEPWD, sUpdatePwd);
        values.put(COLUMN_USER_USERNAME, sUsername);
        values.put(COLUMN_USER_INSERTED, sInserted);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_USERID, values, "userid=?", sWhereArgs) > 0;

        if (bOK)
        {
            values.clear();
            values.put(COLUMN_US_LASTINSERTED, sInserted);

            bOK = db.update(TABLE_UPDATE_STATUS, values, null, null) > 0;
        }

        db.close();
        return bOK;
    }

    public boolean updateUseridEverywhere (Integer iOldUserId, Integer iNewUserId)
    {
        String [] sWhereArgs = {String.valueOf(iOldUserId)};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_USERID, iNewUserId);

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_USERID, values, "userid=?", sWhereArgs) > 0;

        if (bOK)
        {
            values.clear();
            values.put(COLUMN_UserID, iNewUserId);

            bOK = db.update(TABLE_DISPLAY, values, "userid=?", sWhereArgs) > 0;

            if (bOK) {
                values.clear();
                values.put(COLUMN_LASTLOGIN_UserID, iNewUserId);

                bOK = db.update(TABLE_LAST_LOGIN, values, "userid=?", sWhereArgs) > 0;
            }
        }

        db.close();
        return bOK;
    }



    public int count ()
    {
        String query = "Select Count(*) FROM " + TABLE_DISPLAY ;
        int iCount = 0;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst())
        {
            cursor.moveToFirst();
            iCount = cursor.getInt(0);
            cursor.close();
        }
        db.close();
        return iCount;
    }

    public int countUsers ()
    {
        String query = "Select Count(*) FROM " + TABLE_USERID;
        int iCount = 0;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst())
        {
            cursor.moveToFirst();
            iCount = cursor.getInt(0);
            cursor.close();
        }
        db.close();
        return iCount;
    }

}
