package com.example.bhalprin.homephones;

import android.content.ContentResolver;
import android.content.SharedPreferences;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.DataSetObserver;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.SparseArray;

public class MyDBHandlerTD extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 9;
    private static final String DATABASE_NAME = "homeinfoTDDB.db";

    public static final String TABLE_TD_ACCOUNTS = "tdaccounts";
    public static final String TABLE_TD_SYMBOLS = "tdsymbols";
    public static final String TABLE_TD_TRADES = "tdtrades";

    public static final String COLUMN_TD_ACCOUNTS_ID = "ID";
    public static final String COLUMN_TD_ACCOUNTS_ACCOUNTID = "AccountID";
    public static final String COLUMN_TD_ACCOUNTS_DISPLAYNAME = "DisplayName";
    public static final String COLUMN_TD_ACCOUNTS_ACCESS_TOKEN = "AccessToken";
    public static final String COLUMN_TD_ACCOUNTS_REFRESH_TOKEN = "RefreshToken";
    public static final String COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_EXPIRATION_DATE = "AccessTokenExpirationDate";

    public static final int COLUMN_TD_ACCOUNTS_ID_IDX = 0;
    public static final int COLUMN_TD_ACCOUNTS_ACCOUNTID_IDX = 1;
    public static final int COLUMN_TD_ACCOUNTS_DISPLAYNAME_IDX = 2;
    public static final int COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_IDX = 3;
    public static final int COLUMN_TD_ACCOUNTS_REFRESH_TOKEN_IDX = 4;
    public static final int COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_EXPIRATION_DATE_IDX = 5;

    public static final String COLUMN_TD_SYMBOLS_ID = "ID";
    public static final String COLUMN_TD_SYMBOLS_ACCOUNTID = "AccountID";
    public static final String COLUMN_TD_SYMBOLS_SYMBOL = "Symbol";
    public static final String COLUMN_TD_SYMBOLS_CURRENT_PRICE = "CurrentPrice";
    public static final String COLUMN_TD_SYMBOLS_SHARES = "Shares";
    public static final String COLUMN_TD_SYMBOLS_GAINLOSS = "GainLoss";

    public static final int COLUMN_TD_SYMBOLS_ID_IDX = 0;
    public static final int COLUMN_TD_SYMBOLS_ACCOUNTID_IDX = 1;
    public static final int COLUMN_TD_SYMBOLS_SYMBOL_IDX = 2;
    public static final int COLUMN_TD_SYMBOLS_CURRENT_PRICE_IDX = 3;
    public static final int COLUMN_TD_SYMBOLS_SHARES_IDX = 4;
    public static final int COLUMN_TD_SYMBOLS_GAINLOSS_IDX = 5;

    public static final String COLUMN_TD_TRADES_ID = "ID";
    public static final String COLUMN_TD_TRADES_ACCOUNTID = "AccountID";
    public static final String COLUMN_TD_TRADES_SYMBOL = "Symbol";
    public static final String COLUMN_TD_TRADES_SHARES = "Shares";
    public static final String COLUMN_TD_TRADES_PRICE = "Price";
    public static final String COLUMN_TD_TRADES_COST = "Cost";

    public static final int COLUMN_TD_TRADES_ID_IDX = 0;
    public static final int COLUMN_TD_TRADES_ACCOUNTID_IDX = 1;
    public static final int COLUMN_TD_TRADES_SYMBOL_IDX = 2;
    public static final int COLUMN_TD_TRADES_SHARES_IDX = 3;
    public static final int COLUMN_TD_TRADES_PRICE_IDX = 4;
    public static final int COLUMN_TD_TRADES_COST_IDX = 5;
    

    Context callerContext;

    public MyDBHandlerTD(Context context, String name,
                              SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
        callerContext = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        TimeUtil tu = new TimeUtil();
        String CREATE_TD_ACCOUNTS_TABLE = "CREATE TABLE " +
                TABLE_TD_ACCOUNTS + "("
                + COLUMN_TD_ACCOUNTS_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_TD_ACCOUNTS_ACCOUNTID + " TEXT collate nocase,"
                + COLUMN_TD_ACCOUNTS_DISPLAYNAME + " TEXT collate nocase,"
                + COLUMN_TD_ACCOUNTS_ACCESS_TOKEN + " TEXT collate nocase,"
                + COLUMN_TD_ACCOUNTS_REFRESH_TOKEN + " TEXT collate nocase,"
                + COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_EXPIRATION_DATE + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_TD_ACCOUNTS_TABLE);

        String CREATE_TD_SYMBOLS_TABLE = "CREATE TABLE " +
                TABLE_TD_SYMBOLS + "("
                + COLUMN_TD_SYMBOLS_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_TD_SYMBOLS_ACCOUNTID + " TEXT collate nocase,"
                + COLUMN_TD_SYMBOLS_SYMBOL + " TEXT collate nocase,"
                + COLUMN_TD_SYMBOLS_CURRENT_PRICE + " TEXT collate nocase,"
                + COLUMN_TD_SYMBOLS_SHARES + " TEXT collate nocase,"
                + COLUMN_TD_SYMBOLS_GAINLOSS + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_TD_SYMBOLS_TABLE);

        String CREATE_TD_TRADES_TABLE = "CREATE TABLE " +
                TABLE_TD_TRADES + "("
                + COLUMN_TD_TRADES_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_TD_TRADES_ACCOUNTID + " TEXT collate nocase,"
                + COLUMN_TD_TRADES_SYMBOL + " TEXT collate nocase,"
                + COLUMN_TD_TRADES_SHARES + " TEXT collate nocase,"
                + COLUMN_TD_TRADES_PRICE + " TEXT collate nocase,"
                + COLUMN_TD_TRADES_COST + " TEXT collate nocase"
                + ")";
        db.execSQL(CREATE_TD_TRADES_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TD_ACCOUNTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TD_SYMBOLS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TD_TRADES);
        onCreate(db);
    }

    public void forceCreate ()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        onUpgrade(db, 0, 0);
    }

    public void addAccount(TDAccount account) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_TD_ACCOUNTS_ACCOUNTID, account.getAccountId());
        values.put(COLUMN_TD_ACCOUNTS_DISPLAYNAME, account.getDisplayName());
        values.put(COLUMN_TD_ACCOUNTS_ACCESS_TOKEN, account.getAccessToken());
        values.put(COLUMN_TD_ACCOUNTS_REFRESH_TOKEN, account.getRefreshToken());
        values.put(COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_EXPIRATION_DATE, account.getAccessTokenExpirationDate());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_TD_ACCOUNTS, null, values);
        db.close();
    }

    public void addSymbol(TDSymbol symbol) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_TD_SYMBOLS_ACCOUNTID, symbol.getAccountId());
        values.put(COLUMN_TD_SYMBOLS_SYMBOL, symbol.getSymbol());
        values.put(COLUMN_TD_SYMBOLS_CURRENT_PRICE, symbol.getCurrentPrice());
        values.put(COLUMN_TD_SYMBOLS_SHARES, symbol.getShares());
        values.put(COLUMN_TD_SYMBOLS_GAINLOSS, symbol.getGainLoss());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_TD_SYMBOLS, null, values);
        db.close();
    }

    public TDAccount findAccount(String sAccountId) {
        String query = "Select * FROM " + TABLE_TD_ACCOUNTS + " WHERE "
                + COLUMN_TD_ACCOUNTS_ACCOUNTID + " =  \"" + sAccountId + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        TDAccount account = new TDAccount();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            account.setId(Integer.parseInt(cursor.getString(COLUMN_TD_ACCOUNTS_ID_IDX)));
            account.setAccountId(cursor.getString(COLUMN_TD_ACCOUNTS_ACCOUNTID_IDX));
            account.setDisplayName(cursor.getString(COLUMN_TD_ACCOUNTS_DISPLAYNAME_IDX));
            account.setAccessToken(cursor.getString(COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_IDX));
            account.setRefreshToken(cursor.getString(COLUMN_TD_ACCOUNTS_REFRESH_TOKEN_IDX));
            account.setAccessTokenExpirationDate(cursor.getString(COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_EXPIRATION_DATE_IDX));
            cursor.close();
        } else {
            account = null;
        }
        db.close();
        return account;
    }

    public boolean updateAccount(TDAccount inAccount)
    {
        String [] sWhereArgs = {String.valueOf(inAccount.getId())};
        boolean bOK = false;

        ContentValues values = new ContentValues();
        values.put(COLUMN_TD_ACCOUNTS_ACCOUNTID, inAccount.getAccountId());
        values.put(COLUMN_TD_ACCOUNTS_DISPLAYNAME, inAccount.getDisplayName());
        values.put(COLUMN_TD_ACCOUNTS_ACCESS_TOKEN, inAccount.getAccessToken());
        values.put(COLUMN_TD_ACCOUNTS_REFRESH_TOKEN, inAccount.getRefreshToken());
        values.put(COLUMN_TD_ACCOUNTS_ACCESS_TOKEN_EXPIRATION_DATE, inAccount.getAccessTokenExpirationDate());

        SQLiteDatabase db = this.getWritableDatabase();

        bOK = db.update(TABLE_TD_ACCOUNTS, values, "id=?", sWhereArgs) > 0;

        db.close();
        return bOK;
    }

    public int countAccounts ()
    {
        String query = "Select Count(*) FROM " + TABLE_TD_ACCOUNTS;
        int iCount = 0;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst())
        {
            cursor.moveToFirst();
            iCount = cursor.getInt(0);
            cursor.close();
        }
        db.close();
        return iCount;
    }


}
