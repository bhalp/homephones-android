package com.example.bhalprin.homephones;

public class MessageContact {

    private int miId;
    private String msContactName;
    private String msContactIP;
    private String msContactInserted;
    private String msContactDeleted;

    public MessageContact() {

    }

    public MessageContact(int iId, String sContactName, String sContactIP, String sContactInserted, String sContactDeleted)
    {
        this.miId = iId;
        this.msContactName = sContactName;
        this.msContactIP = sContactIP;
        this.msContactInserted = sContactInserted;
        this.msContactDeleted = sContactDeleted;
    }

    public MessageContact(String sContactName, String sContactIP, String sContactInserted, String sContactDeleted)
    {
        this.msContactName = sContactName;
        this.msContactIP = sContactIP;
        this.msContactInserted = sContactInserted;
        this.msContactDeleted = sContactDeleted;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public String getContactName()
    {
        return this.msContactName;
    }
    public void setContactName(String sValue)
    {
        this.msContactName = sValue;
    }
    public String getContactIP()
    {
        return this.msContactIP;
    }
    public void setContactIP(String sValue)
    {
        this.msContactIP = sValue;
    }
    public String getContactInserted()
    {
        return this.msContactInserted;
    }
    public void setContactInserted(String sValue)
    {
        this.msContactInserted = sValue;
    }
    public String getContactDeleted()
    {
        return this.msContactDeleted;
    }
    public void setContactDeleted(String sValue)
    {
        this.msContactDeleted = sValue;
    }

}
