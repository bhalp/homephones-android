package com.example.bhalprin.homephones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.support.v7.app.AppCompatActivity;

import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.util.Log;
import android.util.Base64;


/**
 * A login screen that offers login via username/password.
 */
public class LoginActivity extends AppCompatActivity {

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private UserLoginTask mAuthTask = null;
    private UserLoginUpdateTask mAuthUpdateTask = null;
    private static final String TAG = "LogonActivity";

    // UI references.
    private EditText mUsernameView;
    private EditText mPasswordView;
    private EditText mUpdatePasswordView;
    private View mProgressView;
    private View mLoginFormView;
    private boolean mbSpecial = false;

    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            boolean keepOriginal = true;
            StringBuilder sb = new StringBuilder(end - start);
            for (int i = start; i < end; i++) {
                char c = source.charAt(i);
                if (isCharAllowed(c)) // put your condition here
                    sb.append(c);
                else
                    keepOriginal = false;
            }
            if (keepOriginal)
                return null;
            else {
                if (source instanceof Spanned) {
                    SpannableString sp = new SpannableString(sb);
                    TextUtils.copySpansFrom((Spanned) source, start, sb.length(), null, sp, 0);
                    return sp;
                } else {
                    return sb;
                }
            }
        }

        private boolean isCharAllowed(char c)
        {
            if (c < 128)
            {
                return MainActivity.giAllowedCharsUserInfo[c] == 1;
            }
            else
            {
                return false;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Set up the login form.
        mUsernameView = (EditText) findViewById(R.id.username);
        mUsernameView.setFilters(new InputFilter[] { filter });

        mPasswordView = (EditText) findViewById(R.id.password);
        mPasswordView.setFilters(new InputFilter[] { filter });
        mUpdatePasswordView = (EditText) findViewById(R.id.updatepassword);
        mUpdatePasswordView.setFilters(new InputFilter[] { filter });
//        mPasswordView.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int id, KeyEvent keyEvent) {
//                if (id == R.id.login || id == EditorInfo.IME_NULL) {
//                    attemptLogin();
//                    return true;
//                }
//                return false;
//            }
//        });

        Button mSignInButton = (Button) findViewById(R.id.sign_in_button);
        mSignInButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                //uncomment so don't have to enter logon info when debugging
//                setUserID("3", "BOB", "xxxx", "xxxx", true, false);
//                finish();

                attemptLogin();
            }
        });

        mLoginFormView = findViewById(R.id.login_form);
        mProgressView = findViewById(R.id.login_progress);

        Intent data = getIntent();
        if (data.hasExtra("username"))
        {
            mUsernameView.setText(data.getExtras().getString("username"));
        }
        if (data.hasExtra("password"))
        {
            mPasswordView.setText(data.getExtras().getString("password"));
        }
        if (data.hasExtra("updatepassword"))
        {
            mUpdatePasswordView.setText(data.getExtras().getString("updatepassword"));
        }
    }

    private void setUserID (String sValue, String sUsername, String sPassword, String sUpdatePassword,  boolean bUpdating, boolean bSpecial)
    {
        Intent data = getIntent();
        data.putExtra("userid", sValue);
        data.putExtra("username", sUsername);
        data.putExtra("password", sPassword);
        data.putExtra("updatepassword", sUpdatePassword);
        data.putExtra("updating", bUpdating);
        data.putExtra("special", bSpecial);
        setResult(RESULT_OK, data);
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptLogin() {
        if (mAuthTask != null) {
            return;
        }

        // Reset errors.
        mUsernameView.setError(null);
        mPasswordView.setError(null);
        mUpdatePasswordView.setError(null);

        // Store values at the time of the login attempt.
        String username = mUsernameView.getText().toString();
        String password = mPasswordView.getText().toString();
        String updatepassword = mUpdatePasswordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password.
        if (!isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(username)) {
            mUsernameView.setError(getString(R.string.error_field_required));
            focusView = mUsernameView;
            cancel = true;
        }

        if (TextUtils.isEmpty(updatepassword))
        {
            if (cancel) {
                // There was an error; don't attempt login and focus the first
                // form field with an error.
                focusView.requestFocus();
            } else {
                // Show a progress spinner, and kick off a background task to
                // perform the user login attempt.
                showProgress(true);
                mAuthTask = new UserLoginTask();
                mAuthTask.execute((String) null);
            }
        }
        else
        {
            if (cancel) {
                // There was an error; don't attempt login and focus the first
                // form field with an error.
                focusView.requestFocus();
            } else {
                // Show a progress spinner, and kick off a background task to
                // perform the user login attempt.
                showProgress(true);
                mAuthUpdateTask = new UserLoginUpdateTask();
                mAuthUpdateTask.execute((String) null);
            }
        }

    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return !(password.length() < 1);
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /**
     * Represents an asynchronous login/registration task used to authenticate
     * the user.
     */
    public class UserLoginTask extends AsyncTask<String, String, String>
    {

//        private final String mUsername;
//        private final String mPassword;

//        UserLoginTask(String username, String password) {
//            mUsername = username;
//            mPassword = password;
//        }

        String mUsername = mUsernameView.getText().toString();
        String mPassword = mPasswordView.getText().toString();

        @Override
        protected String doInBackground(String... params) {
            try {
                //Thread.sleep(2000);
                MyDBHandler dbHandler = new MyDBHandler(LoginActivity.this, null, null, 1);

                Userid userid = dbHandler.findUserid(mUsername);
                String mPassword64 = Base64.encodeToString( mPassword.toUpperCase().getBytes(), Base64.DEFAULT );
                if (userid != null) {
                    if (mPassword64.substring(0,mPassword64.length() - 1).equals(userid.getUserBrowsePwd()))
                    {
                        mbSpecial = userid.getSpecial();
                        return String.valueOf(userid.getUserId());
                    }
                    else
                    {
                        return "0";
                    }
                } else {
                    return "-1";
                }

            }
            catch (Exception e) {
                return "0";
            }
//            catch (InterruptedException e) {
//                return "0";
//            }
        }

        @Override
        protected void onPostExecute(String userid) {
            mAuthTask = null;
            showProgress(false);

            if (userid.equals("0"))
            {
                mPasswordView.setError(getString(R.string.error_incorrect_password));
                mPasswordView.requestFocus();
            }
            else if (userid.equals("-1"))
            {
                mUsernameView.setError(getString(R.string.error_invalid_username));
                mUsernameView.requestFocus();
            }
            else
            {
                setUserID(userid, mUsername, mPassword, "", false, mbSpecial);
                finish();
            }
        }

        @Override
        protected void onCancelled() {
            mAuthTask = null;
            showProgress(false);
        }
    }

    public class UserLoginUpdateTask extends AsyncTask<String, String, String>
    {

        String mUsername = mUsernameView.getText().toString();
        String mPassword = mPasswordView.getText().toString();
        String mUpdatePassword = mUpdatePasswordView.getText().toString();

        @Override
        protected String doInBackground(String... params) {
            try {
                //Thread.sleep(2000);
                MyDBHandler dbHandler = new MyDBHandler(LoginActivity.this, null, null, 1);

                Userid userid = dbHandler.findUserid(mUsername);
                String mPassword64 = Base64.encodeToString( mPassword.toUpperCase().getBytes(), Base64.DEFAULT );
                String mUpdatePassword64 = Base64.encodeToString( mUpdatePassword.toUpperCase().getBytes(), Base64.DEFAULT );
                if (userid != null) {
                    if (mPassword64.substring(0,mPassword64.length() - 1).equals(userid.getUserBrowsePwd()))
                    {
                        if (mUpdatePassword64.substring(0,mUpdatePassword64.length() - 1).equals(userid.getUserUpdatePwd()))
                        {
                            mbSpecial = userid.getSpecial();
                            return String.valueOf(userid.getUserId());
                        }
                        else
                        {
                            return "-2";
                        }
                    }
                    else
                    {
                        return "0";
                    }
                } else {
                    return "-1";
                }

            }
            catch (Exception e) {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String userid) {
            mAuthUpdateTask = null;
            showProgress(false);

            if (userid.equals("0"))
            {
                mPasswordView.setError(getString(R.string.error_incorrect_password));
                mPasswordView.requestFocus();
            }
            else if (userid.equals("-1"))
            {
                mUsernameView.setError(getString(R.string.error_invalid_username));
                mUsernameView.requestFocus();
            }
            else if (userid.equals("-2"))
            {
                mUpdatePasswordView.setError(getString(R.string.error_incorrect_updatepassword));
                mUpdatePasswordView.requestFocus();
            }
            else
            {
                setUserID(userid, mUsername, mPassword, mUpdatePassword, true, mbSpecial);
                finish();
            }
        }

        @Override
        protected void onCancelled() {
            mAuthUpdateTask = null;
            showProgress(false);
        }
    }

}

