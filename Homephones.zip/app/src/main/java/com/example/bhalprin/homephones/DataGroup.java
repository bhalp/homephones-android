package com.example.bhalprin.homephones;

/**
 * Created by bhalprin on 9/20/2016.
 */
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import android.telephony.PhoneNumberUtils;

import com.google.i18n.phonenumbers.PhoneNumberMatch;
import com.google.i18n.phonenumbers.PhoneNumberUtil;


public class DataGroup {

    public String string;
    public String phone;
    public final List<String> children = new ArrayList<String>();
    public final ArrayList messagechildren = new ArrayList();
    public String misc;
    public String mapinfo;
    public int id;
    public int userid;
    public String sStatus = ""; //Inserted, Deleted, Updated
    public String sInserted = "";
    public String sDeleted = "";
    public int iMainDBId = 0;
    public final List<String> phoneNumbers = new ArrayList<String>();

    public DataGroup (){
    }

    public DataGroup(String string, String phone) {
        this.string = string;
        this.phone = phone;
    }

    public void findPhoneNumbers ()
    {
        phoneNumbers.clear();
        if (!this.phone.isEmpty())
        {
            Iterator<PhoneNumberMatch> existsPhone= PhoneNumberUtil.getInstance().findNumbers(this.phone, "US").iterator();

            while (existsPhone.hasNext()){
                phoneNumbers.add(String.valueOf(existsPhone.next().number().getNationalNumber()));
                //System.out.println("Phone == " + existsPhone.next().number());
            }
//            String [] sTmp;
//            sTmp = this.phone.split(" ");
//            for (int idx = 0; idx < sTmp.length; idx++)
//            {
//                PhoneNumberUtils pu = new PhoneNumberUtils();
//                String sPhoneNumber = pu.formatNumber (sTmp[idx], pu.get)
//            }


        }
    }

}