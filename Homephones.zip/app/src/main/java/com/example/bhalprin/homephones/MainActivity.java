package com.example.bhalprin.homephones;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLEncoder;
import java.util.regex.Pattern;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;

import android.content.ContentResolver;
//import android.provider.DocumentsContract;
//import android.provider.DocumentsContract.Document;
import android.database.Cursor;

import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.widget.SearchView;
import android.telephony.SmsManager;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.util.SparseArray;
import java.util.ArrayList;
import android.util.Log;

//import android.widget.TextView;
//import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Environment;

import android.widget.ExpandableListView;
import android.app.AlertDialog;
import android.content.DialogInterface;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    SearchView edtsearch;
//    EditText edtsearch;
    ProgressBar pbbar;

    public int progressStatus = 0;
    private Handler handler = new Handler();

    public static DoListenForMessages dlm = new DoListenForMessages();
    public static DoSendSMSMessage dSendSMS = new DoSendSMSMessage();

    //    TextView lblUpdateStatusInfo;
    ExpandableListView listView;
    MyExpandableListAdapter adapter;

    public static NotificationManagerCompat notificationManager;

    SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
    public SparseArray<DataGroup> groupsNeedSync = new SparseArray<DataGroup>();
    public SparseArray<DataGroup> groupsNeedSyncLocal = new SparseArray<DataGroup>();
    public SparseArray<DataGroup> groupsNeedSyncMain = new SparseArray<DataGroup>();
    public SparseArray<DataGroup> groupsTemp = new SparseArray<DataGroup>();
    public static SparseArray<DataGroup> groupsMessages = new SparseArray<DataGroup>();

    public static final int LOGON_REQUEST = 1;
    public static final int UPDATE_REQUEST = 2;
    public static final int ADDUSER_REQUEST = 3;
    public static final int UPDATEUSER_REQUEST = 4;
    public static final int CLEANDB_REQUEST = 5;
    public static final int WEBVIEW_REQUEST = 6;
    public static final int MESSAGE_UPDATE_CONTACT_REQUEST = 7;
    public static final int MESSAGE_SEND_REQUEST = 8;
    public static final int MESSAGE_ADD_CONTACT_REQUEST = 9;
    public static final int MESSAGE_SELECT_FILE_TO_SEND = 10;
    public static final int REINSTATE_REQUEST = 11;


    public static final String gsCodeOutGt = "xxgtxx"; // >
    public static final String gsCodeOutLt = "xxltxx"; // <
    public static final String gsCodeOutBar = "xxbarxx"; // |
    public static final String gsCodeOutApos = "xxaposxx"; // '
    public static final String gsCodeOutAmpersand = "xxampxx"; // &
    public static final String gsCodeOutQuote = "xxquotexx"; // "
    public static final String gsCodeOutPercent = "xxpercentxx"; // %
    public static final String gsCodeCRLF = "xxbrxx"; // \n

    private String msUserId = "";
    private String msUsername = "";
    private String msPassword = "";
    private String msUpdatePassword = "";
    public boolean mbCanUpdate = false;
    private String msLastSearchArg = "";
    private String msLastSearchType = "0"; //0 - no searches done yet, 1 - normal, 2 - special
    private boolean mbSpecialUser = false;

    private boolean mbCanReadContacts = false;
    private boolean mbCanGetLocation = false;
    private boolean mbCanSendSMS = false;
    private boolean mbCanReceiveSMS = false;
    private boolean mbCanReadExternalDirectory = false;
    private boolean mbCanWriteExternalDirectory = false;
    private Integer iPermissionsNeeded = 0;

    public static final Integer READ_CONTACTS_PERMISSION_NEEDED = 2;
    public static final Integer ACCESS_FINE_LOCATION_PERMISSION_NEEDED = 4;
    public static final Integer ACCESS_COURSE_LOCATION_PERMISSION_NEEDED = 8;
    public static final Integer READ_EXTERNAL_STORAGE_NEEDED = 16;
    public static final Integer WRITE_EXTERNAL_STORAGE_NEEDED = 32;
    public static final Integer SEND_SMS_PERMISSION_NEEDED = 64;
    public static final Integer RECEIVE_SMS_PERMISSION_NEEDED = 128;

    public static final int REQUEST_READ_CONTACTS = 79;
    public static final int REQUEST_FINE_LOCATION = 80;
    public static final int REQUEST_COURSE_LOCATION = 81;
    public static final int REQUEST_READ_EXTERNAL_STORAGE = 82;
    public static final int REQUEST_WRITE_EXTERNAL_STORAGE = 83;


    private String msDebugInfo = "";

    public static final int MENU_FIND_IDX = 0;
    public static final int MENU_FIND_SPECIAL_IDX = 1;
    public static final int MENU_SHOW_MESSAGES_IDX = 2;
    public static final int MENU_ADD_MESSAGE_CONTACT_IDX = 3;
    public static final int MENU_LOGIN_IDX = 4;
    public static final int MENU_ADD_RECORD_IDX = 5;
    public static final int MENU_TDAPP_IDX = 6;
    public static final int MENU_SYNC_IDX = 7;
    public static final int MENU_COPY_DB_TO_ALT_IDX = 8;
    public static final int MENU_COPY_LOCAL_DB_TO_ALT_IDX = 9;
    public static final int MENU_COPY_MEDITATIONDB_TO_ALT_IDX = 10;
    public static final int MENU_COPY_MILEAGEDB_TO_ALT_IDX = 11;
    public static final int MENU_COPY_SUPERBOWLDB_TO_ALT_IDX = 12;
    public static final int MENU_LOAD_DB_IDX = 13;
    public static final int MENU_ADD_CONTACTS_TO_DB_IDX = 14;
    public static final int MENU_ADD_USER_IDX = 15;
    public static final int MENU_UPDATE_USER_IDX = 16;
    public static final int MENU_CLEAN_DB_IDX = 17;
    public static final int MENU_SHOW_BLOODPRESSURESITE_IDX = 18;
    public static final int MENU_SHOW_HOMEPHONESSITE_IDX = 19;
    public static final int MENU_SHOW_MEDITATIONSITE_IDX = 20;
    public static final int MENU_SHOW_MILEAGESITE_IDX = 21;
    public static final int MENU_SHOW_SUPERBOWLSITE_IDX = 22;
    public static final int MENU_SHOW_VIEWAGENDAS_IDX = 23;
    public static final int MENU_SHOW_VIEWPICTURES_IDX = 24;
    public static final int MENU_FIND_DELETED_IDX = 25;
    public static final int MENU_LOGOUT_IDX = 26;
    public static final int MENU_SETTINGS_IDX =27;

    public static final int [] giAllowedChars = {0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,    //0 - 15   ..........\n.....
                                                0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //16 - 31   ................
                                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,    //32 - 47    !"#$%&'()*+,-./
                                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,    //48 - 63   0123456789:;<=>?
                                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,    //64 - 79   @ABCDEFGHIJKLMNO
                                                1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,    //80 - 95   PQRSTUVWXYZ[.]._
                                                0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,    //96 - 111  .abcdefghijklmno
                                                1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0};   //112 - 127 pqrstuvwxyz{|}..

    public static final int [] giAllowedCharsUserInfo = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //0 - 15   ................
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //16 - 31   ................
            1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,    //32 - 47    ..#............
            1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,    //48 - 63   0123456789......
            0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,    //64 - 79   .ABCDEFGHIJKLMNO
            1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,    //80 - 95   PQRSTUVWXYZ...._
            0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,    //96 - 111  .abcdefghijklmno
            1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0};   //112 - 127 pqrstuvwxyz.....

    public static final int [] giAllowedCharsIPAddr = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //0 - 15   ................
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //16 - 31   ................
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,    //32 - 47   ................ only period
            1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,    //48 - 63   0123456789......
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //64 - 79   ................
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //80 - 95   ................
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,    //96 - 111  ................
            0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};   //112 - 127 ................

    public static final String gksMessageFieldSeparator = "<<>>";

    ArrayList mobileArray;

    public static int giMessageID = 1;
    public static DisplayMetrics dm = new DisplayMetrics();
    public static Context context;
    public static int gkiMessagePort = 8080;

    public static DirectoryEntry mDirectoryEntry;
    public static MessageContact mContact;

    public static final int gkiInitialUserId = 1;
    public static final String DefaultRedirectUrl = "https://bhalp.github.io/mySite/defaultCell.htm";
    public static final String APIKey = "5V5GTTHEURLAUGI2JAFC06QKAIVPAVYF";

    public static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;

        android.view.Display mDisplay= this.getWindowManager().getDefaultDisplay();
        mDisplay.getMetrics(dm);
        Log.d("MainActivity - onCreate",  "widthPixels = " + ((Integer)dm.widthPixels).toString());

        notificationManager = NotificationManagerCompat.from(this);

//        edtsearch = (EditText) findViewById(R.id.edtsearch);
        edtsearch = (SearchView) findViewById(R.id.edtsearch);

        ImageView closeButton = (ImageView) this.edtsearch.findViewById(android.support.v7.appcompat.R.id.search_close_btn);

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Manage this event.
                clearList(true);
            }
        });

        edtsearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {


                doFind();

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }

        });


//        edtsearch.setOnCloseListener(new SearchView.OnCloseListener() {
//            @Override
//            public boolean onClose() {
//                clearList();
////                Toast t = Toast.makeText(MainActivity.this, "close", Toast.LENGTH_SHORT);
////                t.show();
////
//                return false;
//            }
//        });



        pbbar = (ProgressBar) findViewById(R.id.pbbar);
        pbbar.setVisibility(View.GONE);
        listView = (ExpandableListView) findViewById(R.id.lvData);

        SetupSearchButtons ();
        //        lblUpdateStatusInfo = (TextView) findViewById(R.id.lblUpdateStatusInfo);

//        getUpdateStatusInfo();

        NetworkManager.getInstance(this);
        NetworkManagerAlt.getInstance(this);
        NetworkManagerAltMeditation.getInstance(this);
        NetworkManagerMeditation.getInstance(this);
        NetworkManagerAltMileage.getInstance(this);
        NetworkManagerMileage.getInstance(this);
        NetworkManagerAltSuperbowl.getInstance(this);
        NetworkManagerSuperbowl.getInstance(this);

        getLastLoginInfo ();
        if (!(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_CONTACTS)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += READ_CONTACTS_PERMISSION_NEEDED;
            };
        } else {
            mbCanReadContacts = true;
        }
        if (!(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_FINE_LOCATION)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += ACCESS_FINE_LOCATION_PERMISSION_NEEDED;
            };
        } else {
            mbCanGetLocation = true;
        }

        if (!(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += ACCESS_COURSE_LOCATION_PERMISSION_NEEDED;
            };
        } else {
            mbCanGetLocation = true;
        }

        if (!(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += READ_EXTERNAL_STORAGE_NEEDED;
            };
        } else {
            mbCanReadExternalDirectory = true;
        }

        if (!(ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += WRITE_EXTERNAL_STORAGE_NEEDED;
            };
        } else {
            mbCanWriteExternalDirectory = true;
        }

        if (!(ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += SEND_SMS_PERMISSION_NEEDED;
            };
        } else {
            mbCanSendSMS = true;
            dSendSMS.bCanSendSMS = true;
        }

        if (!(ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
                == PackageManager.PERMISSION_GRANTED)) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)) {
                //already denied this permission
            } else {
                iPermissionsNeeded += RECEIVE_SMS_PERMISSION_NEEDED;
            };
        } else {
            mbCanReceiveSMS = true;
        }



        if (iPermissionsNeeded > 0) {
            Log.d("MainActivity - onCreate",  "iPermissionsNeeded = " + iPermissionsNeeded.toString());
        }

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        gkiMessagePort = Integer.parseInt(sharedPref.getString("message_port", "8080"));
        if (sharedPref.getBoolean("chkprefAllowMessages", false)) {
            if (ConnectivityHelper.isConnectedToNetwork(this)) {
                if (mbCanGetLocation) // if can't get location then can't get ssid - might not really care about ssid
                {
                    if (NetworkUtils.checkWifiOnAndConnected(this)) {
                        if (!dlm.bStarted) {
                            dlm.StartServer(this, notificationManager);
                        }
                    }
                }
            }
        } else {
            if (dlm.bStarted) {
                dlm.StopServer();
            }
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d ("MainActivity", "onDestroy");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d ("MainActivity", "onStop");
    }



    private void requestPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.READ_CONTACTS)) {
        } else {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.READ_CONTACTS},
                    REQUEST_READ_CONTACTS);
        }
    }

//    private void requestPermissionFineLocation() {
//        if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_FINE_LOCATION)) {
//        } else {
//            ActivityCompat.requestPermissions(this,
//                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
//                    REQUEST_FINE_LOCATION);
//        }
//    }
//
//    private void requestPermissionCourseLocation() {
//        if (ActivityCompat.shouldShowRequestPermissionRationale(this, android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
//        } else {
//            ActivityCompat.requestPermissions(this,
//                    new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION},
//                    REQUEST_COURSE_LOCATION);
//        }
//    }
//
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {


        int idxResult = 0;
        if ((requestCode & ACCESS_FINE_LOCATION_PERMISSION_NEEDED) == ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanGetLocation = true;
            }
            idxResult++;
        }
        if ((requestCode & ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanGetLocation = true;
            }
            idxResult++;
        }
        if ((requestCode & READ_CONTACTS_PERMISSION_NEEDED) == READ_CONTACTS_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanReadContacts = true;
            }
            idxResult++;
        }
        if ((requestCode & READ_EXTERNAL_STORAGE_NEEDED) == READ_EXTERNAL_STORAGE_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanReadExternalDirectory = true;
            }
            idxResult++;
        }
        if ((requestCode & WRITE_EXTERNAL_STORAGE_NEEDED) == WRITE_EXTERNAL_STORAGE_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanWriteExternalDirectory = true;
            }
            idxResult++;
        }
        if ((requestCode & SEND_SMS_PERMISSION_NEEDED) == SEND_SMS_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanSendSMS = true;
                dSendSMS.bCanSendSMS = true;
            }
            idxResult++;
        }
        if ((requestCode & RECEIVE_SMS_PERMISSION_NEEDED) == RECEIVE_SMS_PERMISSION_NEEDED) {
            if (grantResults.length > idxResult && grantResults[idxResult] == PackageManager.PERMISSION_GRANTED) {
                mbCanReceiveSMS = true;
            }
            idxResult++;
        }

//        if (requestCode == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED + ACCESS_FINE_LOCATION_PERMISSION_NEEDED + READ_CONTACTS_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanReadContacts = true;
//            }
//            if (grantResults.length > 1 && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//            if (grantResults.length > 2 && grantResults[2] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//        } else if (requestCode == READ_CONTACTS_PERMISSION_NEEDED + ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanReadContacts = true;
//            }
//            if (grantResults.length > 1 && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//        } else if (requestCode == READ_CONTACTS_PERMISSION_NEEDED + ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanReadContacts = true;
//            }
//            if (grantResults.length > 1 && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//        } else if (requestCode == ACCESS_FINE_LOCATION_PERMISSION_NEEDED + ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//            if (grantResults.length > 1 && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//        } else if (requestCode == READ_CONTACTS_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanReadContacts = true;
//            }
//        } else if (requestCode == ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//        } else { //if (requestCode == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                mbCanGetLocation = true;
//            }
//        }
        return;

//        switch (requestCode) {
//            case REQUEST_READ_CONTACTS: {
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
////                    mobileArray = getAllContacts();
//                } else {
//                    // permission denied,Disable the
//                    // functionality that depends on this permission.
//                }
//                return;
//            }
//            case REQUEST_FINE_LOCATION: {
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
////                    mobileArray = getAllContacts();
//                } else {
//                    // permission denied,Disable the
//                    // functionality that depends on this permission.
//                }
//                return;
//            }
//            case REQUEST_COURSE_LOCATION: {
//                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
////                    mobileArray = getAllContacts();
//                } else {
//                    // permission denied,Disable the
//                    // functionality that depends on this permission.
//                }
//                return;
//            }
//        }
    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

        if (sharedPref.getBoolean("chkprefDoAutoSync", false)){
            if (ConnectivityHelper.isConnectedToNetwork(this)) //do we need to sync with master dbs
            {
                // Set the progress status zero on each button click
                progressStatus = 0;
                // Visible the progress bar and text view
                pbbar.setVisibility(View.VISIBLE);

                // Start the lengthy operation in a background thread
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while(progressStatus < 100){

                            // Try to sleep the thread for 20 milliseconds
                            try{
                                Thread.sleep(20);
                            }catch(InterruptedException e){
                                e.printStackTrace();
                            }

                            // Update the progress bar
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    pbbar.setProgress(progressStatus);
                                    // If task execution completed
                                    if(progressStatus == 100){
                                        // Hide the progress bar from layout after finishing task
                                        pbbar.setVisibility(View.GONE);
                                    }
                                }
                            });
                        }
                    }
                }).start(); // Start the operation

                DoAutoSync doAutoSync = new DoAutoSync();
                doAutoSync.execute("");

            }
        }

        if (iPermissionsNeeded > 0) {
            String sPermissonsList = "";
            String sSep = "";
            if ((iPermissionsNeeded & ACCESS_FINE_LOCATION_PERMISSION_NEEDED) == ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.ACCESS_FINE_LOCATION;
                sSep = "|";
            }
            if ((iPermissionsNeeded & ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.ACCESS_COARSE_LOCATION;
                sSep = "|";
            }
            if ((iPermissionsNeeded & READ_CONTACTS_PERMISSION_NEEDED) == READ_CONTACTS_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.READ_CONTACTS;
                sSep = "|";
            }
            if ((iPermissionsNeeded & READ_EXTERNAL_STORAGE_NEEDED) == READ_EXTERNAL_STORAGE_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.READ_EXTERNAL_STORAGE;
                sSep = "|";
            }
            if ((iPermissionsNeeded & WRITE_EXTERNAL_STORAGE_NEEDED) == WRITE_EXTERNAL_STORAGE_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.WRITE_EXTERNAL_STORAGE;
                sSep = "|";
            }
            if ((iPermissionsNeeded & SEND_SMS_PERMISSION_NEEDED) == SEND_SMS_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.SEND_SMS;
                sSep = "|";
            }
            if ((iPermissionsNeeded & RECEIVE_SMS_PERMISSION_NEEDED) == RECEIVE_SMS_PERMISSION_NEEDED) {
                sPermissonsList = sPermissonsList + sSep + Manifest.permission.RECEIVE_SMS;
                sSep = "|";
            }

            if (!sPermissonsList.equals("")) {
                String sPermissions [] = sPermissonsList.split(Pattern.quote("|"));
                ActivityCompat.requestPermissions(this,
                        sPermissions,
                        iPermissionsNeeded);
           }

//            if (iPermissionsNeeded == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED + ACCESS_FINE_LOCATION_PERMISSION_NEEDED + READ_CONTACTS_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.READ_CONTACTS, android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
//                        iPermissionsNeeded);
//            } else if (iPermissionsNeeded == ACCESS_FINE_LOCATION_PERMISSION_NEEDED + READ_CONTACTS_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.READ_CONTACTS, android.Manifest.permission.ACCESS_FINE_LOCATION},
//                        iPermissionsNeeded);
//            } else if (iPermissionsNeeded == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED + READ_CONTACTS_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.ACCESS_COARSE_LOCATION},
//                        iPermissionsNeeded);
//            } else if (iPermissionsNeeded == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED + ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
//                        iPermissionsNeeded);
//            } else if (iPermissionsNeeded == READ_CONTACTS_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.READ_CONTACTS},
//                        iPermissionsNeeded);
//            } else if (iPermissionsNeeded == ACCESS_FINE_LOCATION_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
//                        iPermissionsNeeded);
//            } else { //if (iPermissionsNeeded == ACCESS_COURSE_LOCATION_PERMISSION_NEEDED) {
//                ActivityCompat.requestPermissions(this,
//                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
//                        iPermissionsNeeded);
//            }
            iPermissionsNeeded = 0;
        }

        gkiMessagePort = Integer.parseInt(sharedPref.getString("message_port", "8080"));
        if (sharedPref.getBoolean("chkprefAllowMessages", false)) {
            if (ConnectivityHelper.isConnectedToNetwork(this)) {
                if (mbCanGetLocation) // if can't get location then can't get ssid - might not really care about ssid
                {
                    if (NetworkUtils.checkWifiOnAndConnected(this)) {
                        if (!dlm.bStarted) {
                            dlm.StartServer(this, notificationManager);
                        } else if (dlm.iCurrentPort != MainActivity.gkiMessagePort) {
                            dlm.StopServer();
                            dlm.StartServer(this, notificationManager);
                        }
                    }
                }
            }
        } else {
            if (dlm.bStarted) {
                dlm.StopServer();
            }
        }


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu) {
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
        if (ConnectivityHelper.isConnectedToNetwork(this)) {

            if (sharedPref.getBoolean("chkprefAllowMessages", false)) {
            } else {
                menu.getItem(MENU_ADD_MESSAGE_CONTACT_IDX).setVisible(false);
                menu.getItem(MENU_SHOW_MESSAGES_IDX).setVisible(false);
            }

            if (mbCanGetLocation) // if can't get location then can't get ssid - might not really care about ssid
            {
                if (NetworkUtils.checkWifiOnAndConnected(this)) {
                    menu.getItem(MENU_ADD_MESSAGE_CONTACT_IDX).setVisible(true);
                    menu.getItem(MENU_SHOW_MESSAGES_IDX).setVisible(true);
                } else {
                    menu.getItem(MENU_ADD_MESSAGE_CONTACT_IDX).setVisible(false);
                    menu.getItem(MENU_SHOW_MESSAGES_IDX).setVisible(false);
                }
            } else {
                menu.getItem(MENU_ADD_MESSAGE_CONTACT_IDX).setVisible(false);
                menu.getItem(MENU_SHOW_MESSAGES_IDX).setVisible(false);
            }

            if (mbCanUpdate)
            {
                menu.getItem(MENU_ADD_RECORD_IDX).setVisible(true);
                menu.getItem(MENU_LOAD_DB_IDX).setVisible(true);
                if (mbCanReadContacts) {
                    menu.getItem(MENU_ADD_CONTACTS_TO_DB_IDX).setVisible(true);
                } else {
                    menu.getItem(MENU_ADD_CONTACTS_TO_DB_IDX).setVisible(false);
                }
                menu.getItem(MENU_SYNC_IDX).setVisible(false);
                menu.getItem(MENU_UPDATE_USER_IDX).setVisible(true);
            }
            else
            {
                menu.getItem(MENU_ADD_RECORD_IDX).setVisible(false);
                menu.getItem(MENU_LOAD_DB_IDX).setVisible(false);
                menu.getItem(MENU_ADD_CONTACTS_TO_DB_IDX).setVisible(false);
                menu.getItem(MENU_SYNC_IDX).setVisible(false);
                menu.getItem(MENU_UPDATE_USER_IDX).setVisible(false);
            }
            if (msUserId.equals(""))
            {
                menu.getItem(MENU_LOGIN_IDX).setTitle("Logon");
                menu.getItem(MENU_ADD_USER_IDX).setVisible(true);
                menu.getItem(MENU_FIND_IDX).setVisible(false);
                menu.getItem(MENU_FIND_SPECIAL_IDX).setVisible(false);
                menu.getItem(MENU_FIND_DELETED_IDX).setVisible(false);
                menu.getItem(MENU_LOGOUT_IDX).setVisible(false);
            }
            else
            {
                menu.getItem(MENU_LOGIN_IDX).setTitle("Add/Remove Update Pwd");
                menu.getItem(MENU_ADD_USER_IDX).setVisible(false);
                menu.getItem(MENU_LOGOUT_IDX).setTitle("Logout - " + msUsername);
                menu.getItem(MENU_LOGOUT_IDX).setVisible(true);
                menu.getItem(MENU_FIND_IDX).setVisible(true);
                menu.getItem(MENU_FIND_SPECIAL_IDX).setVisible(true);
                menu.getItem(MENU_FIND_DELETED_IDX).setVisible(true);
            }
            if ((mbSpecialUser) && (mbCanUpdate))
            {
                menu.getItem(MENU_COPY_DB_TO_ALT_IDX).setVisible(true);
                menu.getItem(MENU_COPY_LOCAL_DB_TO_ALT_IDX).setVisible(true);
                menu.getItem(MENU_COPY_MEDITATIONDB_TO_ALT_IDX).setVisible(true);
                menu.getItem(MENU_COPY_MILEAGEDB_TO_ALT_IDX).setVisible(true);
                menu.getItem(MENU_COPY_SUPERBOWLDB_TO_ALT_IDX).setVisible(true);
                menu.getItem(MENU_CLEAN_DB_IDX).setVisible(true);
            }
            else
            {
                menu.getItem(MENU_COPY_DB_TO_ALT_IDX).setVisible(false);
                menu.getItem(MENU_COPY_LOCAL_DB_TO_ALT_IDX).setVisible(false);
                menu.getItem(MENU_COPY_MEDITATIONDB_TO_ALT_IDX).setVisible(false);
                menu.getItem(MENU_COPY_MILEAGEDB_TO_ALT_IDX).setVisible(false);
                menu.getItem(MENU_COPY_SUPERBOWLDB_TO_ALT_IDX).setVisible(false);
                menu.getItem(MENU_CLEAN_DB_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowTDApp", false)){
                menu.getItem(MENU_TDAPP_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_TDAPP_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowBloodPressureSite", false)){
                menu.getItem(MENU_SHOW_BLOODPRESSURESITE_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_BLOODPRESSURESITE_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowHomephonesSite", false)){
                menu.getItem(MENU_SHOW_HOMEPHONESSITE_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_HOMEPHONESSITE_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowMeditationSite", false)){
                menu.getItem(MENU_SHOW_MEDITATIONSITE_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_MEDITATIONSITE_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowMileageSite", false)){
                menu.getItem(MENU_SHOW_MILEAGESITE_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_MILEAGESITE_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowSuperbowlSite", false)){
                menu.getItem(MENU_SHOW_SUPERBOWLSITE_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_SUPERBOWLSITE_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowViewAgendas", false)){
                menu.getItem(MENU_SHOW_VIEWAGENDAS_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_VIEWAGENDAS_IDX).setVisible(false);
            }

            if (sharedPref.getBoolean("chkprefShowViewPictures", false)){
                menu.getItem(MENU_SHOW_VIEWPICTURES_IDX).setVisible(true);
            } else {
                menu.getItem(MENU_SHOW_VIEWPICTURES_IDX).setVisible(false);
            }

        } else {
            if (mbCanUpdate)
            {
                menu.getItem(MENU_ADD_RECORD_IDX).setVisible(true);
                menu.getItem(MENU_LOAD_DB_IDX).setVisible(false);
                if (mbCanReadContacts) {
                    menu.getItem(MENU_ADD_CONTACTS_TO_DB_IDX).setVisible(true);
                } else {
                    menu.getItem(MENU_ADD_CONTACTS_TO_DB_IDX).setVisible(false);
                }
                menu.getItem(MENU_SYNC_IDX).setVisible(false);
                menu.getItem(MENU_UPDATE_USER_IDX).setVisible(true);
            }
            else
            {
                menu.getItem(MENU_ADD_RECORD_IDX).setVisible(false);
                menu.getItem(MENU_LOAD_DB_IDX).setVisible(false);
                menu.getItem(MENU_ADD_CONTACTS_TO_DB_IDX).setVisible(false);
                menu.getItem(MENU_SYNC_IDX).setVisible(false);
                menu.getItem(MENU_UPDATE_USER_IDX).setVisible(false);
            }
            if (msUserId.equals(""))
            {
                menu.getItem(MENU_LOGIN_IDX).setTitle("Logon");
                menu.getItem(MENU_ADD_USER_IDX).setVisible(true);
                menu.getItem(MENU_FIND_IDX).setVisible(false);
                menu.getItem(MENU_FIND_SPECIAL_IDX).setVisible(false);
                menu.getItem(MENU_FIND_DELETED_IDX).setVisible(false);
                menu.getItem(MENU_LOGOUT_IDX).setVisible(false);
            }
            else
            {
                menu.getItem(MENU_LOGIN_IDX).setTitle("Add/Remove Update Pwd");
                menu.getItem(MENU_ADD_USER_IDX).setVisible(false);
                menu.getItem(MENU_LOGOUT_IDX).setTitle("Logout - " + msUsername);
                menu.getItem(MENU_LOGOUT_IDX).setVisible(true);
                menu.getItem(MENU_FIND_IDX).setVisible(true);
                menu.getItem(MENU_FIND_SPECIAL_IDX).setVisible(true);
                menu.getItem(MENU_FIND_DELETED_IDX).setVisible(true);
            }
            menu.getItem(MENU_COPY_DB_TO_ALT_IDX).setVisible(false);
            menu.getItem(MENU_COPY_LOCAL_DB_TO_ALT_IDX).setVisible(false);
            menu.getItem(MENU_COPY_MEDITATIONDB_TO_ALT_IDX).setVisible(false);
            menu.getItem(MENU_COPY_SUPERBOWLDB_TO_ALT_IDX).setVisible(false);
            menu.getItem(MENU_CLEAN_DB_IDX).setVisible(false);

            menu.getItem(MENU_SHOW_BLOODPRESSURESITE_IDX).setVisible(false);
            menu.getItem(MENU_SHOW_HOMEPHONESSITE_IDX).setVisible(false);
            menu.getItem(MENU_SHOW_MEDITATIONSITE_IDX).setVisible(false);
            menu.getItem(MENU_SHOW_MILEAGESITE_IDX).setVisible(false);
            menu.getItem(MENU_SHOW_SUPERBOWLSITE_IDX).setVisible(false);
            menu.getItem(MENU_SHOW_VIEWAGENDAS_IDX).setVisible(false);
            menu.getItem(MENU_SHOW_VIEWPICTURES_IDX).setVisible(false);

        }

//        if (sharedPref.getString("message_name", "").equals("")) {
//            menu.getItem(MENU_SHOW_MESSAGES_IDX).setVisible(false);
//            menu.getItem(MENU_START_MESSAGE_SERVER_IDX).setVisible(false);
//            menu.getItem(MENU_STOP_MESSAGE_SERVER_IDX).setVisible(false);
//            menu.getItem(MENU_ADD_MESSAGE_CONTACT_IDX).setVisible(false);
//        }

        menu.getItem(MENU_SETTINGS_IDX).setVisible(true);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == LOGON_REQUEST) {
            if (data.hasExtra("userid"))
            {
                msUserId = data.getExtras().getString("userid");
                msUsername = data.getExtras().getString("username");
                msPassword = data.getExtras().getString("password");
                mbCanUpdate = data.getExtras().getBoolean("updating");
                if (data.hasExtra("updatepassword"))
                {
                    msUpdatePassword = data.getExtras().getString("updatepassword");
                }
                else
                {
                    msUpdatePassword = "";
                }
                mbSpecialUser = data.getExtras().getBoolean("special");

                UpdateLastLogin(msUserId, mbCanUpdate);

                invalidateOptionsMenu();
                if (msLastSearchType.equals("1"))
                {
                    doFind();
                }
                else if (msLastSearchType.equals("2"))
                {
                    doFindSpecial();
                }
                this.setTitle("(" + msUsername + ")");
//                Toast.makeText(this, data.getExtras().getString("userid"),
//                        Toast.LENGTH_LONG).show();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == UPDATEUSER_REQUEST) {
            if (data.hasExtra("username"))
            {
                msUsername = data.getExtras().getString("username");
                msPassword = data.getExtras().getString("password");
                msUpdatePassword = data.getExtras().getString("updatepassword");
                if (msLastSearchType.equals("1"))
                {
                    doFind();
                }
                else if (msLastSearchType.equals("2"))
                {
                    doFindSpecial();
                }
//                Toast.makeText(this, data.getExtras().getString("userid"),
//                        Toast.LENGTH_LONG).show();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == UPDATE_REQUEST) {
            if (data.hasExtra("status"))
            {
                if (msLastSearchType.equals("1"))
                {
                    doFind();
                }
                else if (msLastSearchType.equals("2"))
                {
                    doFindSpecial();
                }
//                Toast.makeText(this, "status = " + data.getExtras().getString("status") +
//                                     ", Last Search Arg = " + msLastSearchArg +
//                                     ", Last Search Type = " + msLastSearchType,
//                        Toast.LENGTH_LONG).show();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == REINSTATE_REQUEST) {
            if (data.hasExtra("status"))
            {
                doFindDeleted();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == ADDUSER_REQUEST) {
            if (data.hasExtra("userid"))
            {
                clearList();
                msUserId = data.getExtras().getString("userid");
                msUsername = data.getExtras().getString("username");
                msPassword = data.getExtras().getString("password");
                mbCanUpdate = data.getExtras().getBoolean("updating");
                msUpdatePassword = data.getExtras().getString("updatepassword");
                this.setTitle("(" + msUsername + ")");

                UpdateLastLogin(msUserId, mbCanUpdate);
                invalidateOptionsMenu();
//                Toast.makeText(this, data.getExtras().getString("userid"),
//                        Toast.LENGTH_LONG).show();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == CLEANDB_REQUEST) {
            if (data.hasExtra("status"))
            {
                Toast.makeText(this, data.getExtras().getString("status"),
                        Toast.LENGTH_LONG).show();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == WEBVIEW_REQUEST) {
            if (msLastSearchType.equals("1"))
            {
                doFind();
            }
            else if (msLastSearchType.equals("2"))
            {
                doFindSpecial();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == MESSAGE_SELECT_FILE_TO_SEND) {
            if (data.hasExtra("currentDirectoryUri"))
            {
                mDirectoryEntry = new DirectoryEntry();

                mDirectoryEntry.fileName = data.getStringExtra("filename");
                mDirectoryEntry.mimeType = data.getStringExtra("mimeType");

                //currentDirectoryURI contains
                // /tree/primary:Download/Adobe Acrobat -- internal storage
                // /tree/67E3-6141:DCIM/Camera -- sd card

                String sDirParts [];
                if (!data.getStringExtra("currentDirectoryUri").equals("")) {
                    //  /storage/67E3-6141/Android/data/com.example.bhalprin.homephones/files/Download
                    sDirParts = data.getStringExtra("currentDirectoryUri").split(Pattern.quote(":"));
                    String sDir = "";
                    if (sDirParts.length > 1) {
                        sDir = File.separator + sDirParts[sDirParts.length - 1];
                    }
                    String sDevice [] = sDirParts[0].split(Pattern.quote("/"));
                    if (sDevice[sDevice.length - 1].toUpperCase().equals("PRIMARY")) {
                        //file in internal memory
                        mDirectoryEntry.directory = Environment.getExternalStorageDirectory().toString() + sDir;  // /storage/emulated/0
                    } else {
                        //file on sd card
                        mDirectoryEntry.directory = "/storage/" + sDevice[sDevice.length - 1] + sDir;
                    }
                } else {
                    //shouldn't get here
                }

                mContact = new MessageContact();
                mContact.setContactIP(data.getStringExtra("contactIP"));
                mContact.setContactName(data.getStringExtra("contactName"));

                String state = Environment.getExternalStorageState();

                if (!(state.equals(Environment.MEDIA_MOUNTED))) {
                    Toast.makeText(this, "There is not any sd card", Toast.LENGTH_LONG).show();


                } else {

                }

                BufferedReader reader = null;
                try {
                    Toast.makeText(this, "Sd card available", Toast.LENGTH_LONG).show();
                    File file = Environment.getExternalStorageDirectory();
                    File textFile = new File(mDirectoryEntry.directory + File.separator + mDirectoryEntry.fileName);

                    System.out.println("file name is   ::" + textFile.getName());
                    Long FileLength = textFile.length();
                    try {
                        String Extension = textFile.getName();
                        Log.d("Name of File-> ", "" + Extension);
                    } catch (Exception e) {
                        // TODO: handle exception
                        e.printStackTrace();
                    }

                    reader = new BufferedReader(new FileReader(textFile));
                    NotificationUtils.GenerateNotification("Can open file",
                            mDirectoryEntry.directory + File.separator + mDirectoryEntry.fileName,
                            1, null, false, this,
                            notificationManager, NotificationCompat.PRIORITY_HIGH);
//                        StringBuilder textBuilder = new StringBuilder();
//                        String line;
//                        while((line = reader.readLine()) != null) {
//                            textBuilder.append(line);
//                            textBuilder.append("\n");
//
//                        }
//                        String sTmp = textBuilder.toString();
//                        textView.setText(textBuilder);

                } catch (FileNotFoundException e) {
                    // TODO: handle exception
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                finally{
                    if(reader != null){
                        try {
                            reader.close();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }


            }
        }
        else if (resultCode == RESULT_OK && requestCode == MESSAGE_UPDATE_CONTACT_REQUEST) {
            if (data.hasExtra("status"))
            {
                doGetAllMessageContacts();
            }
        }
        else if (resultCode == RESULT_OK && requestCode == MESSAGE_SEND_REQUEST) {
            if (data.hasExtra("status"))
            {
                doGetAllMessageContacts();
            }
            if (ConnectivityHelper.isConnectedToNetwork(this)) {
                if (mbCanGetLocation) // if can't get location then can't get ssid - might not really care about ssid
                {
                    if (NetworkUtils.checkWifiOnAndConnected(this)) {
                        if (!dlm.bStarted) {
                            dlm.StartServer(this, notificationManager);
                        }
                    }
                }
            }
        }
        else if (resultCode == RESULT_OK && requestCode == MESSAGE_ADD_CONTACT_REQUEST) {
            doGetAllMessageContacts();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        RelativeLayout main_view = (RelativeLayout) findViewById(R.id.main_view);
        //final WebView webView = (WebView)findViewById(R.id.webView);
        switch (item.getItemId())
        {
            case R.id.menu_addcontacts:
            {
                if (!(ActivityCompat.checkSelfPermission(this, android.Manifest.permission.READ_CONTACTS)
                        == PackageManager.PERMISSION_GRANTED)) {
                    requestPermission();
                } else {
                    groups.clear();
                    groups = getAllContacts();
                    adapter = new MyExpandableListAdapter(this, groups, 1);
                    listView.setAdapter(adapter);
                    //mobileArray = getAllContacts();
                }
                return true;
            }
            case R.id.menu_cleandb:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    Intent i = new Intent(MainActivity.this, CleanDB.class);
                    startActivityForResult(i, CLEANDB_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_sync:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    //first determine if need to sync
                    MyDBHandler dbHandler = null;
                    dbHandler = new MyDBHandler(this, null, null, 1);
                    groupsNeedSync = dbHandler.GetSyncInfo();
                    if (groupsNeedSync.size() == 0)
                    {
                        DataGroup group = null;
                        group = new DataGroup();
                        group.string =  "Nothing changed. No need to sync.";
                        group.phone =  "";
                        group.children.add("");
                        groupsNeedSync.append(0, group);
                        adapter = new MyExpandableListAdapter(this, groupsNeedSync);
                        listView.setAdapter(adapter);
                    }
                    else
                    {
                        adapter = new MyExpandableListAdapter(this, groupsNeedSync);
                        listView.setAdapter(adapter);
                        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which){
                                    case DialogInterface.BUTTON_POSITIVE:
                                        //Yes button clicked
//------------------------------------------------------------------------------
                                        // Set the progress status zero on each button click
                                        progressStatus = 0;
                                        // Visible the progress bar and text view
                                        pbbar.setVisibility(View.VISIBLE);

                                        // Start the lengthy operation in a background thread
                                        new Thread(new Runnable() {
                                            @Override
                                            public void run() {
                                                while(progressStatus < 100){

                                                    // Try to sleep the thread for 20 milliseconds
                                                    try{
                                                        Thread.sleep(20);
                                                    }catch(InterruptedException e){
                                                        e.printStackTrace();
                                                    }

                                                    // Update the progress bar
                                                    handler.post(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            pbbar.setProgress(progressStatus);
                                                            // If task execution completed
                                                            if(progressStatus == 100){
                                                                // Hide the progress bar from layout after finishing task
                                                                pbbar.setVisibility(View.GONE);
                                                            }
                                                        }
                                                    });
                                                }
                                            }
                                        }).start(); // Start the operation

//------------------------------------------------------------------------------
                                        DoSync doSync = new DoSync();
                                        doSync.execute("");
                                        break;

                                    case DialogInterface.BUTTON_NEGATIVE:
                                        //No button clicked
                                        break;
                                }
                            }
                        };

                        AlertDialog.Builder builder = new AlertDialog.Builder(this);
                        builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                                .setNegativeButton("No", dialogClickListener).show();

                    }
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }

                return true;
            }
            case R.id.menu_loaddb:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Yes button clicked
//------------------------------------------------------------------------------
                                    // Set the progress status zero on each button click
                                    progressStatus = 0;
                                    // Visible the progress bar and text view
                                    pbbar.setVisibility(View.VISIBLE);

                                    // Start the lengthy operation in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            while(progressStatus < 100){

                                                // Try to sleep the thread for 20 milliseconds
                                                try{
                                                    Thread.sleep(20);
                                                }catch(InterruptedException e){
                                                    e.printStackTrace();
                                                }

                                                // Update the progress bar
                                                handler.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        pbbar.setProgress(progressStatus);
                                                        // If task execution completed
                                                        if(progressStatus == 100){
                                                            // Hide the progress bar from layout after finishing task
                                                            pbbar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }).start(); // Start the operation

//------------------------------------------------------------------------------
                                    DoLoad doLoad = new DoLoad();
                                    doLoad.execute("");
//                                DoLoad doLoad = new DoLoad();
//                                doLoad.execute("");
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_login:
            {
                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                i.putExtra("username", msUsername);
                i.putExtra("password", msPassword);
                i.putExtra("updatepassword", msUpdatePassword);
                startActivityForResult(i, LOGON_REQUEST);
                return true;
            }
            case R.id.menu_bloodpressuresite:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/bloodpressuresite";
                    i.putExtra("url", url);
                    i.putExtra("title", "Blood Pressure Site");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_homephonessite:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/homephones";
                    i.putExtra("url", url);
                    i.putExtra("title", "Homephones Site");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            case R.id.menu_show_messages:
            {
                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                if (sharedPref.getString("message_name", "").equals("")) {
                    Toast.makeText(this, getString(R.string.pref_title_message_id_missing),
                            Toast.LENGTH_SHORT).show();

                } else {
                    doGetAllMessageContacts();
                }
                return true;
            }

            case R.id.menu_add_message_contact:
            {
                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                if (sharedPref.getString("message_name", "").equals("")) {
                    Toast.makeText(this, getString(R.string.pref_title_message_id_missing),
                            Toast.LENGTH_SHORT).show();

                } else {
                    Intent i = new Intent(MainActivity.this, AddMessageContactActivity.class);
                    startActivityForResult(i, MESSAGE_ADD_CONTACT_REQUEST);
                }
                return true;
            }

            case R.id.menu_meditationsite:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {

                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

//                    if (mbCanGetLocation) {
//                        Toast.makeText(this, NetworkUtils.getLocalIpAddress(this) +
//                                        ", Connected to wifi = " + NetworkUtils.checkWifiOnAndConnected(this) +
//                                        ", SSID = " + NetworkUtils.getSSID(this),
//                                Toast.LENGTH_SHORT).show();
//
//                        ms.StartServer(this, notificationManager);
//
//                        Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
//                        String url = "http://" + sharedPref.getString("main_db_server_name", "") +
//                                ":" + sharedPref.getString("main_db_server_port", "81") + "/meditationsite";
//                        intent.putExtra("url", url);
//                        intent.putExtra("title", "Meditation Site");
//                        NotificationUtils.GenerateNotification("Homephones Message", "Test message.",
//                                1, intent, true, this, notificationManager);
//
//
//                    }

                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/meditationsite";
                    i.putExtra("url", url);
                    i.putExtra("title", "Meditation Site");

                    startActivityForResult(i, WEBVIEW_REQUEST);

                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_tdapp:
            {
                //https://auth.tdameritrade.com/auth?response_type=code&redirect_uri=https%3A%2F%2F127.0.0.1%3A8080&client_id=VTBLS2XWYV8HCIHN8JSTSHEZTFZXNI93%40AMER.OAUTHAP
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);

                    String url = null;
                    try {
                        url = "https://auth.tdameritrade.com/auth?response_type=code&redirect_uri=" + URLEncoder.encode(sharedPref.getString("redirect_url", DefaultRedirectUrl), "UTF-8") + "&client_id=" + APIKey + "%40AMER.OAUTHAP";
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
//                    String url = "https://auth.tdameritrade.com/auth?response_type=code&redirect_uri=https%3A%2F%2Flocalhost%3A8080&client_id=VTBLS2XWYV8HCIHN8JSTSHEZTFZXNI93%40AMER.OAUTHAP";
                    i.putExtra("url", url);
                    i.putExtra("title", "TD App");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_mileagesite:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/mileagesite";
                    i.putExtra("url", url);
                    i.putExtra("title", "Mileage Site");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_superbowlsite:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/superbowlsite";
                    i.putExtra("url", url);
                    i.putExtra("title", "Superbowl Site");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_viewagendas:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/viewagendas?$t=allagendas";
                    i.putExtra("url", url);
                    i.putExtra("title", "View Agendas");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_viewpictures:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);
                    Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                    String url = "http://" + sharedPref.getString("main_db_server_name", "") +
                            ":" + sharedPref.getString("main_db_server_port", "81") + "/viewpictures";
                    i.putExtra("url", url);
                    i.putExtra("title", "View Pictures");

                    startActivityForResult(i, WEBVIEW_REQUEST);
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_logout:
            {
//                msUsername = "";
//                msPassword = "";
//                msUpdatePassword = "";
//                mbCanUpdate = false;
//                msUserId = "";
//                msLastSearchType = "";
//                invalidateOptionsMenu();

                UpdateLastLogin("-1", false);
                this.setTitle("Homephones");

                clearList();
                return true;
            }
            case R.id.menu_adduser:
            {
                Intent i = new Intent(MainActivity.this, AddUser.class);
                startActivityForResult(i, ADDUSER_REQUEST);
                return true;
            }
            case R.id.menu_updateuser:
            {
                Intent i = new Intent(MainActivity.this, UpdateUser.class);
                i.putExtra("userid", msUserId);
                i.putExtra("username", msUsername);
                i.putExtra("browsepwd", msPassword);
                i.putExtra("updatepwd", msUpdatePassword);
                startActivityForResult(i, UPDATEUSER_REQUEST);
                return true;
            }
            case R.id.menu_find:
            {
                if (msUserId.equals(""))
                {
                    Toast.makeText(this, "Please Login",
                        Toast.LENGTH_SHORT).show();
                }
                else
                {
                    doFind();
                }
                return true;

            }
            case R.id.menu_find_deleted:
            {
                if (msUserId.equals(""))
                {
                    Toast.makeText(this, "Please Login",
                            Toast.LENGTH_SHORT).show();
                }
                else
                {
                    doFindDeleted();
                }
                return true;

            }
            case R.id.menu_find_special: {
                if (msUserId.equals("")) {
                    Toast.makeText(this, "Please Login",
                            Toast.LENGTH_SHORT).show();
                } else {
                    doFindSpecial();
                }
                return true;
            }
            case R.id.menu_add: {
                if (msUserId.equals("")) {
                    Toast.makeText(this, "Please Login",
                            Toast.LENGTH_SHORT).show();
                }
                else if (!mbCanUpdate) {
                        Toast.makeText(this, "Please Enter an Update Password",
                                Toast.LENGTH_SHORT).show();
                } else {
                    Intent i = new Intent(MainActivity.this, UpdateActivity.class);
                    i.putExtra("id", "");
                    i.putExtra("userid", msUserId);
                    i.putExtra("name", "");
                    i.putExtra("phone", "");
                    i.putExtra("misc", "");
                    i.putExtra("mapinfo", "");
                    startActivityForResult(i, UPDATE_REQUEST);
                }
                return true;
            }
            case R.id.menu_settings: {
//                SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
//                Toast.makeText(this, "DB Server = " + sharedPref.getString("main_db_server_name", ""),
//                       Toast.LENGTH_SHORT).show();

                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(i);
                return true;
            }
            case R.id.menu_copydbtoalt:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Yes button clicked
//------------------------------------------------------------------------------
                                    // Set the progress status zero on each button click
                                    progressStatus = 0;
                                    // Visible the progress bar and text view
                                    pbbar.setVisibility(View.VISIBLE);

                                    // Start the lengthy operation in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            while(progressStatus < 100){

                                                // Try to sleep the thread for 20 milliseconds
                                                try{
                                                    Thread.sleep(20);
                                                }catch(InterruptedException e){
                                                    e.printStackTrace();
                                                }

                                                // Update the progress bar
                                                handler.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        pbbar.setProgress(progressStatus);
                                                        // If task execution completed
                                                        if(progressStatus == 100){
                                                            // Hide the progress bar from layout after finishing task
                                                            pbbar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }).start(); // Start the operation

//------------------------------------------------------------------------------
                                    DoCopyDBToAlt doCopyDBTOAlt = new DoCopyDBToAlt();
                                    doCopyDBTOAlt.execute("");
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_copylocaldbtoalt:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Yes button clicked
//------------------------------------------------------------------------------
                                    // Set the progress status zero on each button click
                                    progressStatus = 0;
                                    // Visible the progress bar and text view
                                    pbbar.setVisibility(View.VISIBLE);

                                    // Start the lengthy operation in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            while(progressStatus < 100){

                                                // Try to sleep the thread for 20 milliseconds
                                                try{
                                                    Thread.sleep(20);
                                                }catch(InterruptedException e){
                                                    e.printStackTrace();
                                                }

                                                // Update the progress bar
                                                handler.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        pbbar.setProgress(progressStatus);
                                                        // If task execution completed
                                                        if(progressStatus == 100){
                                                            // Hide the progress bar from layout after finishing task
                                                            pbbar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }).start(); // Start the operation

//------------------------------------------------------------------------------
                                    DoCopyLocalDBToAlt doCopyLocalDBTOAlt = new DoCopyLocalDBToAlt();
                                    doCopyLocalDBTOAlt.execute("");
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            case R.id.menu_copymeditationdbtoalt:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Yes button clicked
//------------------------------------------------------------------------------
                                    // Set the progress status zero on each button click
                                    progressStatus = 0;
                                    // Visible the progress bar and text view
                                    pbbar.setVisibility(View.VISIBLE);

                                    // Start the lengthy operation in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            while(progressStatus < 100){

                                                // Try to sleep the thread for 20 milliseconds
                                                try{
                                                    Thread.sleep(20);
                                                }catch(InterruptedException e){
                                                    e.printStackTrace();
                                                }

                                                // Update the progress bar
                                                handler.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        pbbar.setProgress(progressStatus);
                                                        // If task execution completed
                                                        if(progressStatus == 100){
                                                            // Hide the progress bar from layout after finishing task
                                                            pbbar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }).start(); // Start the operation

//------------------------------------------------------------------------------
                                    DoCopyMeditationDBToAlt doCopyMeditationDBTOAlt = new DoCopyMeditationDBToAlt();
                                    doCopyMeditationDBTOAlt.execute("");
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            case R.id.menu_copymileagedbtoalt:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Yes button clicked
//------------------------------------------------------------------------------
                                    // Set the progress status zero on each button click
                                    progressStatus = 0;
                                    // Visible the progress bar and text view
                                    pbbar.setVisibility(View.VISIBLE);

                                    // Start the lengthy operation in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            while(progressStatus < 100){

                                                // Try to sleep the thread for 20 milliseconds
                                                try{
                                                    Thread.sleep(20);
                                                }catch(InterruptedException e){
                                                    e.printStackTrace();
                                                }

                                                // Update the progress bar
                                                handler.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        pbbar.setProgress(progressStatus);
                                                        // If task execution completed
                                                        if(progressStatus == 100){
                                                            // Hide the progress bar from layout after finishing task
                                                            pbbar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }).start(); // Start the operation

//------------------------------------------------------------------------------
                                    DoCopyMileageDBToAlt doCopyMileageDBTOAlt = new DoCopyMileageDBToAlt();
                                    doCopyMileageDBTOAlt.execute("");
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            case R.id.menu_copysuperbowldbtoalt:
            {
                if (ConnectivityHelper.isConnectedToNetwork(this)) {
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    //Yes button clicked
//------------------------------------------------------------------------------
                                    // Set the progress status zero on each button click
                                    progressStatus = 0;
                                    // Visible the progress bar and text view
                                    pbbar.setVisibility(View.VISIBLE);

                                    // Start the lengthy operation in a background thread
                                    new Thread(new Runnable() {
                                        @Override
                                        public void run() {
                                            while(progressStatus < 100){

                                                // Try to sleep the thread for 20 milliseconds
                                                try{
                                                    Thread.sleep(20);
                                                }catch(InterruptedException e){
                                                    e.printStackTrace();
                                                }

                                                // Update the progress bar
                                                handler.post(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        pbbar.setProgress(progressStatus);
                                                        // If task execution completed
                                                        if(progressStatus == 100){
                                                            // Hide the progress bar from layout after finishing task
                                                            pbbar.setVisibility(View.GONE);
                                                        }
                                                    }
                                                });
                                            }
                                        }
                                    }).start(); // Start the operation

//------------------------------------------------------------------------------
                                    DoCopySuperbowlDBToAlt doCopySuperbowlDBToAlt = new DoCopySuperbowlDBToAlt();
                                    doCopySuperbowlDBToAlt.execute("");
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();
                } else {
                    Toast.makeText(this, getString(R.string.not_connected_to_network),
                            Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void AddMessageToContact (MessageData mData)
    {
        //update the lastlogin table
        MyDBHandlerMessage dbHandler = new MyDBHandlerMessage(MainActivity.this, null, null, 1);
        dbHandler.addMessage(mData);
    }

    public Handler SMSReceivedHandler = new Handler() {
        public void handleMessage(Message msg) {
            NotificationUtils.GenerateNotification("Message Received from " + msg.getData().getString("message").split(Pattern.quote("|"))[0],
                    msg.getData().getString("message").split(Pattern.quote("|"))[1],
                    1, null, false, MainActivity.context,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);
        }
    };


    public void clearList () {
        clearList(false);
    }

    public void clearList (boolean bFromCloseSearch)
    {
        if (bFromCloseSearch) {
            groups.clear();
            adapter = new MyExpandableListAdapter(this, groups);
            listView.setAdapter(adapter);
            edtsearch.setQuery("", false);
        } else {
            msLastSearchType = "";
            msUserId = "";
            msUpdatePassword = "";
            msPassword = "";
            msUsername = "";
            mbCanUpdate = false;
            mbSpecialUser = false;
            groups.clear();
            adapter = new MyExpandableListAdapter(this, groups);
            listView.setAdapter(adapter);
            invalidateOptionsMenu();
            edtsearch.setQuery("", false);
//        edtsearch.setText("");
        }
    }

    public void createData() {
        MyDBHandler dbHandler = null;
        dbHandler = new MyDBHandler(this, null, null, 1);
//        msLastSearchArg = edtsearch.getText().toString();
        msLastSearchArg = edtsearch.getQuery().toString();
        msLastSearchType = "1";
        groups.clear();
        groups = dbHandler.findAllDisplay(msUserId, edtsearch.getQuery().toString());
//        groups = dbHandler.findAllDisplay(msUserId, edtsearch.getText().toString());
    }

    public void createDataDeleted() {
        MyDBHandler dbHandler = null;
        dbHandler = new MyDBHandler(this, null, null, 1);
        msLastSearchArg = edtsearch.getQuery().toString();
        msLastSearchType = "0";
        groups.clear();
        groups = dbHandler.findAllDisplayDeleted(msUserId);
    }

    public void createDataMessageContacts() {
        MyDBHandlerMessage dbHandler = null;
        dbHandler = new MyDBHandlerMessage(this, null, null, 1);
        msLastSearchArg = edtsearch.getQuery().toString();
//        msLastSearchArg = edtsearch.getText().toString();
        msLastSearchType = "0";
        groupsMessages.clear();
        groupsMessages = dbHandler.getAllMessageContacts();
    }

    public void createDataSpecial() {
        MyDBHandler dbHandler = null;
        dbHandler = new MyDBHandler(this, null, null, 1);
        msLastSearchArg = edtsearch.getQuery().toString();
//        msLastSearchArg = edtsearch.getText().toString();
        msLastSearchType = "2";
        groups.clear();
        groups = dbHandler.findAllDisplaySpecial(msUserId, edtsearch.getQuery().toString());
//        groups = dbHandler.findAllDisplaySpecial(msUserId, edtsearch.getText().toString());
    }

    public void debugClass (String sDebugInfo)
    {
        msDebugInfo = sDebugInfo;
    }

    private void doFind(){
        createData();
        if (groups.size() == 0)
        {
            DataGroup group = null;
            group = new DataGroup();
            group.string =  "No matching records found.";
            group.phone =  "";
            group.children.add("");
            groups.append(0, group);
        }
        adapter = new MyExpandableListAdapter(this, groups);
        listView.setAdapter(adapter);
    }

    private void doFindDeleted(){
        createDataDeleted();
        if (groups.size() == 0)
        {
            DataGroup group = null;
            group = new DataGroup();
            group.string =  "No deleted records found.";
            group.phone =  "";
            group.children.add("");
            groups.append(0, group);
        }
        adapter = new MyExpandableListAdapter(this, groups, 3);
        listView.setAdapter(adapter);
    }

    private void doFindSpecial (){
        createDataSpecial();
        if (groups.size() == 0)
        {
            DataGroup group = null;
            group = new DataGroup();
            group.string =  "No matching records found.";
            group.phone =  "";
            group.children.add("");
            groups.append(0, group);
        }
        adapter = new MyExpandableListAdapter(this, groups);
        listView.setAdapter(adapter);
    }

    public void doGetAllMessageContacts(){
        createDataMessageContacts();
        if (groupsMessages.size() == 0)
        {
            DataGroup group = null;
            group = new DataGroup();
            group.string =  "No contacts found.";
            group.phone =  "";
            group.children.add("");
            groupsMessages.append(0, group);
        }
        adapter = new MyExpandableListAdapter(this, groupsMessages, 2);
        listView.setAdapter(adapter);
    }

    private void doSendFile () {
        //------------------------------------------------------------------------------
        // Set the progress status zero on each button click
        progressStatus = 0;
        // Visible the progress bar and text view
        pbbar.setVisibility(View.VISIBLE);

        // Start the lengthy operation in a background thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(progressStatus < 100){

                    // Try to sleep the thread for 20 milliseconds
                    try{
                        Thread.sleep(20);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }

                    // Update the progress bar
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            pbbar.setProgress(progressStatus);
                            // If task execution completed
                            if(progressStatus == 100){
                                // Hide the progress bar from layout after finishing task
                                pbbar.setVisibility(View.GONE);
                            }
                        }
                    });
                }
            }
        }).start(); // Start the operation

//------------------------------------------------------------------------------
        DoSync doSync = new DoSync();
        doSync.execute("");

    }

    private SparseArray<DataGroup> getAllContacts() {
        int iCount = 0;
        SparseArray<DataGroup> groups = new SparseArray<DataGroup>();
        DataGroup group = null;

        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, ContactsContract.Contacts.DISPLAY_NAME + " ASC");
        if ((cur != null ? cur.getCount() : 0) > 0) {
            while (cur != null && cur.moveToNext()) {

                group = new DataGroup();
                group.id = -1; //-1 means that this is a contact
                group.userid  = Integer.valueOf(msUserId);

                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));
                group.string =  name;
                if (cur.getInt(cur.getColumnIndex( ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    String sSep = "";

                    String sPhones = "";
                    for (Integer idx = 0; idx < pCur.getCount(); idx++) {
                        pCur.moveToNext();
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER));
                        Integer iphoneType = pCur.getInt(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.TYPE));
                        switch (iphoneType) {
                            case 1: {
                                if (!(sPhones.contains(phoneNo + " - " + "Home"))) {
                                    sPhones = sPhones + sSep + phoneNo + " - " + "Home";
                                }
                                break;
                            }
                            case 2: {
                                if (!(sPhones.contains(phoneNo + " - " + "Cell"))) {
                                    sPhones = sPhones + sSep + phoneNo + " - " + "Cell";
                                }
                                break;
                            }
                            case 3: {
                                if (!(sPhones.contains(phoneNo + " - " + "Work"))) {
                                    sPhones = sPhones + sSep + phoneNo + " - " + "Work";
                                }
                                break;
                            }
                            case 4: {
                                if (!(sPhones.contains(phoneNo + " - " + "Fax"))) {
                                    sPhones = sPhones + sSep + phoneNo + " - " + "Fax";
                                }
                                break;
                            }
                            case 5: {
                                if (!(sPhones.contains(phoneNo + " - " + "Fax"))) {
                                    sPhones = sPhones + sSep + phoneNo + " - " + "Fax";
                                }
                                break;
                            }
                            default: {
                                if (!(sPhones.contains(phoneNo + " - " + "Other"))) {
                                    sPhones = sPhones + sSep + phoneNo + " - " + "Other";
                                }
                                break;
                            }
                        }
                        sSep = "\r\n";
                    }
                    pCur.close();
                    group.phone =  sPhones;
                    group.findPhoneNumbers();

                    String sEmails = "";
                    pCur = cr.query(
                            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    sSep = "";
                    if (pCur.getCount() > 0){
                        for (Integer idx = 0; idx < pCur.getCount(); idx++) {
                            pCur.moveToNext();
                            String email = pCur.getString(pCur.getColumnIndex(
                                    ContactsContract.CommonDataKinds.Email.ADDRESS));
                            if (!(sEmails.contains(email))) {
                                sEmails = sEmails + sSep + email;
                            }
                            sSep = "\r\n";
                        }
                    }
                    pCur.close();
                    group.children.add(sEmails);
                    group.misc = sEmails;

                    group.mapinfo = "";
                    groups.append(iCount, group);
                    iCount++;
                }
            }
        }
        if (cur != null) {
            cur.close();
        }

        return groups;

    }

//    private ArrayList getAllContacts() {
//        ArrayList<String> nameList = new ArrayList<>();
//        ContentResolver cr = getContentResolver();
//        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
//                null, null, null, ContactsContract.Contacts.DISPLAY_NAME + " ASC");
//        if ((cur != null ? cur.getCount() : 0) > 0) {
//            while (cur != null && cur.moveToNext()) {
//                String id = cur.getString(
//                        cur.getColumnIndex(ContactsContract.Contacts._ID));
//                String name = cur.getString(cur.getColumnIndex(
//                        ContactsContract.Contacts.DISPLAY_NAME));
//                if (cur.getInt(cur.getColumnIndex( ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
//                    Cursor pCur = cr.query(
//                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
//                            null,
//                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
//                            new String[]{id}, null);
//                    String sSep = ">";
//
//                    for (Integer idx = 0; idx < pCur.getCount(); idx++) {
//                        pCur.moveToNext();
//                        String phoneNo = pCur.getString(pCur.getColumnIndex(
//                                ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER));
//                        Integer iphoneType = pCur.getInt(pCur.getColumnIndex(
//                                ContactsContract.CommonDataKinds.Phone.TYPE));
//                        switch (iphoneType) {
//                            case 1: {
//                                if (!(name.contains(phoneNo + "<" + "Home"))) {
//                                    name = name + sSep + phoneNo + "<" + "Home";
//                                }
//                                break;
//                            }
//                            case 2: {
//                                if (!(name.contains(phoneNo + "<" + "Cell"))) {
//                                    name = name + sSep + phoneNo + "<" + "Cell";
//                                }
//                                break;
//                            }
//                            case 3: {
//                                if (!(name.contains(phoneNo + "<" + "Work"))) {
//                                    name = name + sSep + phoneNo + "<" + "Work";
//                                }
//                                break;
//                            }
//                            case 4: {
//                                if (!(name.contains(phoneNo + "<" + "Fax"))) {
//                                    name = name + sSep + phoneNo + "<" + "Fax";
//                                }
//                                break;
//                            }
//                            case 5: {
//                                if (!(name.contains(phoneNo + "<" + "Fax"))) {
//                                    name = name + sSep + phoneNo + "<" + "Fax";
//                                }
//                                break;
//                            }
//                            default: {
//                                if (!(name.contains(phoneNo + "<" + "Other"))) {
//                                    name = name + sSep + phoneNo + "<" + "Other";
//                                }
//                                break;
//                            }
//                        }
//                        sSep = "|";
//                    }
//
////                    while (pCur.moveToNext()) {
////                        String phoneNo = pCur.getString(pCur.getColumnIndex(
////                                ContactsContract.CommonDataKinds.Phone.NORMALIZED_NUMBER));
////                        Integer iphoneType = pCur.getInt(pCur.getColumnIndex(
////                                ContactsContract.CommonDataKinds.Phone.TYPE));
////                        switch (iphoneType) {
////                            case 1: {
////                                name = name + sSep + phoneNo + "<" + "Home";
////                                break;
////                            }
////                            case 2: {
////                                name = name + sSep + phoneNo + "<" + "Cell";
////                                break;
////                            }
////                            case 3: {
////                                name = name + sSep + phoneNo + "<" + "Work";
////                                break;
////                            }
////                            case 4: {
////                                name = name + sSep + phoneNo + "<" + "Fax";
////                                break;
////                            }
////                            case 5: {
////                                name = name + sSep + phoneNo + "<" + "Fax";
////                                break;
////                            }
////                            default: {
////                                name = name + sSep + phoneNo + "<" + "Other";
////                                break;
////                            }
////                        }
////                        sSep = "|";
////                    }
//                    pCur.close();
//
//                    pCur = cr.query(
//                            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
//                            null,
//                            ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = ?",
//                            new String[]{id}, null);
//                    sSep = ">";
//                    if (pCur.getCount() > 0){
//                        for (Integer idx = 0; idx < pCur.getCount(); idx++) {
//                            pCur.moveToNext();
//                            String email = pCur.getString(pCur.getColumnIndex(
//                                    ContactsContract.CommonDataKinds.Email.ADDRESS));
//                            if (!(name.contains(email))) {
//                                name = name + sSep + email;
//                            }
//                            sSep = "|";
//                        }
//                    }
////                    while (pCur.moveToNext()) {
////                        String email = pCur.getString(pCur.getColumnIndex(
////                                ContactsContract.CommonDataKinds.Email.ADDRESS));
////                        name = name + sSep + email;
////                        sSep = "|";
////                    }
//                    pCur.close();
//
//                    nameList.add(name);
//                }
//            }
//        }
//        if (cur != null) {
//            cur.close();
//        }
//        return nameList;
//    }

    private UpdateStatus getAltDBUpdateStatus () {
        UpdateStatus us = null;

        String s = "<?xml version=\"1.0\"?>" + "\r\n";
        s = s + "<command><commandtext>";
        s = s + "GetUpdateStatus";
        s = s + "</commandtext>";
        s = s + "<returnsdata>true</returnsdata>";
        s = s + "</command>";

        NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
        {
            @Override
            public void getResult(String result)
            {
                String sRecords[];
                String sFields[];
                String sField[];
                String sValue = "";
                String sLastInserted = "";
                String sLastDeleted = "";
                if (!result.isEmpty())
                {
                    //do what you need with the result...
//                                Log.d("Response", result);
                    sFields = result.split("<<");
                    int idx = 0;
                    int idxRecords = 0;
                    sRecords = result.split(">>");
                    for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                    {
                        sFields = sRecords[idxRecords].split("<<");
                        for (idx = 0; idx < sFields.length; idx++)
                        {
                            sField = sFields[idx].split(Pattern.quote("||"));
                            if (sField.length > 1)
                            {
                                sValue = sField[1];
                            }
                            else
                            {
                                sValue = "";
                            }
                            switch (sField[0].toUpperCase())
                            {
                                case "LASTINSERTED":
                                {
                                    sLastInserted = sValue;
                                    break;
                                }
                                case "LASTDELETED":
                                {
                                    sLastDeleted = sValue;
                                    break;
                                }
                            }
                        }
                        UpdateStatus us =
                                new UpdateStatus(sLastInserted, sLastDeleted, sLastInserted, sLastDeleted);
                    }

                }
            }
        });

        return us;
    }

    public void getLastLoginInfo () {
        MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
        LastLogin lastlogin = dbHandler.findLastLogin();
        if (lastlogin != null)
        {
            Userid userid = dbHandler.findUseridByUserId(lastlogin.getUserId());
            if (userid != null)
            {
                msUserId = String.valueOf(userid.getUserId());
                msUsername = userid.getUserName();
                msPassword = "";
                mbCanUpdate = (lastlogin.getUpdating() == 1);
                msUpdatePassword = "";
                mbSpecialUser = userid.getSpecial();
                this.setTitle("(" + msUsername + ")");

            } else {
                this.setTitle(NetworkUtils.getLocalIpAddress(this));
            }
        } else {
            this.setTitle(NetworkUtils.getLocalIpAddress(this));
        }

    }

    private UpdateStatus getLocalUpdateStatus () {
        MyDBHandler dbHandler = null;
        dbHandler = new MyDBHandler(this, null, null, 1);
        UpdateStatus us = dbHandler.findUpdateStatus();

        return us;
    }

    private UpdateStatus getMainDBUpdateStatus () {
        UpdateStatus us = null;

        String s = "<?xml version=\"1.0\"?>" + "\r\n";
        s = s + "<command><commandtext>";
        s = s + "GetUpdateStatus";
        s = s + "</commandtext>";
        s = s + "<returnsdata>true</returnsdata>";
        s = s + "</command>";

        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
        {
            @Override
            public void getResult(String result)
            {
                String sRecords[];
                String sFields[];
                String sField[];
                String sValue = "";
                String sLastInserted = "";
                String sLastDeleted = "";
                if (!result.isEmpty())
                {
                    //do what you need with the result...
//                                Log.d("Response", result);
                    sFields = result.split("<<");
                    int idx = 0;
                    int idxRecords = 0;
                    sRecords = result.split(">>");
                    for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                    {
                        sFields = sRecords[idxRecords].split("<<");
                        for (idx = 0; idx < sFields.length; idx++)
                        {
                            sField = sFields[idx].split(Pattern.quote("||"));
                            if (sField.length > 1)
                            {
                                sValue = sField[1];
                            }
                            else
                            {
                                sValue = "";
                            }
                            switch (sField[0].toUpperCase())
                            {
                                case "LASTINSERTED":
                                {
                                    sLastInserted = sValue;
                                    break;
                                }
                                case "LASTDELETED":
                                {
                                    sLastDeleted = sValue;
                                    break;
                                }
                            }
                        }
                        UpdateStatus us =
                                new UpdateStatus(sLastInserted, sLastDeleted, sLastInserted, sLastDeleted);
                    }

                }
            }
        });

        return us;
    }

    private String Replace_XMLChar(String strInput)
    {
        //used to convert from internal program format to main db format
        String strOutput = "";

        strOutput = strInput;

        if (!strOutput.equals(""))
        {
            strOutput = strOutput.replace("&",gsCodeOutAmpersand);
            strOutput = strOutput.replace("<",gsCodeOutLt);
            strOutput = strOutput.replace(">",gsCodeOutGt);
            strOutput = strOutput.replace("\"",gsCodeOutQuote);
            strOutput = strOutput.replace("'",gsCodeOutApos);
            strOutput = strOutput.replace("|",gsCodeOutBar);
            strOutput = strOutput.replace("%",gsCodeOutPercent);
            strOutput = strOutput.replace("\n", gsCodeCRLF);

        }
        return strOutput;
    }

    private void SetupSearchButtons () {
        Button btn_a = (Button) findViewById(R.id.search_a);
        btn_a.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("a", false);
//                    edtsearch.setText("a");
                    doFind();
                }
            }
        });

        Button btn_b = (Button) findViewById(R.id.search_b);
        btn_b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("b", false);
//                    edtsearch.setText("b");
                    doFind();
                }
            }
        });
        Button btn_c = (Button) findViewById(R.id.search_c);
        btn_c.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("c", false);
//                    edtsearch.setText("c");
                    doFind();
                }
            }
        });
        Button btn_d = (Button) findViewById(R.id.search_d);
        btn_d.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("d", false);
//                    edtsearch.setText("d");
                    doFind();
                }
            }
        });
        Button btn_e = (Button) findViewById(R.id.search_e);
        btn_e.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("e", false);
//                    edtsearch.setText("e");
                    doFind();
                }
            }
        });
        Button btn_f = (Button) findViewById(R.id.search_f);
        btn_f.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("f", false);
//                    edtsearch.setText("f");
                    doFind();
                }
            }
        });
        Button btn_g = (Button) findViewById(R.id.search_g);
        btn_g.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("g", false);
//                    edtsearch.setText("g");
                    doFind();
                }
            }
        });
        Button btn_h = (Button) findViewById(R.id.search_h);
        btn_h.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("h", false);
//                    edtsearch.setText("h");
                    doFind();
                }
            }
        });
        Button btn_i = (Button) findViewById(R.id.search_i);
        btn_i.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("i", false);
//                    edtsearch.setText("i");
                    doFind();
                }
            }
        });
        Button btn_j = (Button) findViewById(R.id.search_j);
        btn_j.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("j", false);
//                    edtsearch.setText("j");
                    doFind();
                }
            }
        });
        Button btn_k = (Button) findViewById(R.id.search_k);
        btn_k.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("k", false);
//                    edtsearch.setText("k");
                    doFind();
                }
            }
        });
        Button btn_l = (Button) findViewById(R.id.search_l);
        btn_l.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("l", false);
//                    edtsearch.setText("l");
                    doFind();
                }
            }
        });
        Button btn_m = (Button) findViewById(R.id.search_m);
        btn_m.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("m", false);
//                    edtsearch.setText("m");
                    doFind();
                }
            }
        });
        Button btn_n = (Button) findViewById(R.id.search_n);
        btn_n.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("n", false);
//                    edtsearch.setText("n");
                    doFind();
                }
            }
        });
        Button btn_o = (Button) findViewById(R.id.search_o);
        btn_o.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("o", false);
//                    edtsearch.setText("o");
                    doFind();
                }
            }
        });
        Button btn_p = (Button) findViewById(R.id.search_p);
        btn_p.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("p", false);
//                    edtsearch.setText("p");
                    doFind();
                }
            }
        });
        Button btn_q = (Button) findViewById(R.id.search_q);
        btn_q.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("q", false);
//                    edtsearch.setText("q");
                    doFind();
                }
            }
        });
        Button btn_r = (Button) findViewById(R.id.search_r);
        btn_r.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("r", false);
//                    edtsearch.setText("r");
                    doFind();
                }
            }
        });
        Button btn_s = (Button) findViewById(R.id.search_s);
        btn_s.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("s", false);
//                    edtsearch.setText("s");
                    doFind();
                }
            }
        });
        Button btn_t = (Button) findViewById(R.id.search_t);
        btn_t.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("t", false);
//                    edtsearch.setText("t");
                    doFind();
                }
            }
        });
        Button btn_u = (Button) findViewById(R.id.search_u);
        btn_u.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("u", false);
//                    edtsearch.setText("u");
                    doFind();
                }
            }
        });
        Button btn_v = (Button) findViewById(R.id.search_v);
        btn_v.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("v", false);
//                    edtsearch.setText("v");
                    doFind();
                }
            }
        });
        Button btn_w = (Button) findViewById(R.id.search_w);
        btn_w.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("w", false);
//                    edtsearch.setText("w");
                    doFind();
                }
            }
        });
        Button btn_x = (Button) findViewById(R.id.search_x);
        btn_x.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("x", false);
//                    edtsearch.setText("x");
                    doFind();
                }
            }
        });
        Button btn_y = (Button) findViewById(R.id.search_y);
        btn_y.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("y", false);
//                    edtsearch.setText("y");
                    doFind();
                }
            }
        });
        Button btn_z = (Button) findViewById(R.id.search_z);
        btn_z.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!(msUserId.equals("")))
                {
                    edtsearch.setQuery("z", false);
//                    edtsearch.setText("z");
                    doFind();
                }
            }
        });
    }

    public Handler StartProgressBar = new Handler() {
        public void handleMessage(Message msg) {
            // Set the progress status zero on each button click
            progressStatus = 0;
            // Visible the progress bar and text view
            pbbar.setVisibility(View.VISIBLE);

            // Start the lengthy operation in a background thread
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while(progressStatus < 100){

                        // Try to sleep the thread for 20 milliseconds
                        try{
                            Thread.sleep(20);
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }

                        // Update the progress bar
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                pbbar.setProgress(progressStatus);
                                // If task execution completed
                                if(progressStatus == 100){
                                    // Hide the progress bar from layout after finishing task
                                    pbbar.setVisibility(View.GONE);
                                }
                            }
                        });
                    }
                }
            }).start(); // Start the operation
        }
    };

    public void StopListeningForMessages () {
        dlm.StopServer();
    }

    private void UpdateLastLogin (String sUserId, Boolean bCanUpdate)
    {
        //update the lastlogin table
        LastLogin lastlogin = new LastLogin();
        lastlogin.setUserId(Integer.parseInt(sUserId));
        if (bCanUpdate)
        {
            lastlogin.setUpdating(1);
        }
        else
        {
            lastlogin.setUpdating(0);
        }
        MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
        boolean bOk = dbHandler.updateLastLogin(lastlogin);

    }


    public class DoLoad extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private String sMaxID = "";
        private int iID = 0;
        private int iTotalRecords = 0;
        private int iTotalUserRecords = 0;
        private String sLastInserted = "";
        private String sLastDeleted = "";

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
//            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();

            NotificationUtils.GenerateNotification("DB Load Finished", r,
                    1, null, false, MainActivity.this,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);


            if(isSuccess)
            {
                UpdateLastLogin("-1", false);
                MainActivity.this.clearList();
                MainActivity.this.setTitle("Homephones");
//                if (MainActivity.this.msLastSearchType.equals("1"))
//                {
//                    MainActivity.this.doFind();
//                }
//                else if (MainActivity.this.msLastSearchType.equals("2"))
//                {
//                    MainActivity.this.doFindSpecial();
//                }
            }

        }

        @Override
        protected String doInBackground(String... params) {
            final MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
            try
            {

                dbHandler.forceCreate();

                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUpdateStatus";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            sFields = result.split("<<");
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "LASTINSERTED":
                                        {
                                            sLastInserted = sValue;
                                            break;
                                        }
                                        case "LASTDELETED":
                                        {
                                            sLastDeleted = sValue;
                                            break;
                                        }
                                    }
                                }
                                UpdateStatus us =
                                        new UpdateStatus(sLastInserted, sLastDeleted, sLastInserted, sLastDeleted);


                                dbHandler.addUpdateStatus(us);
                            }

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUsers";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserId = "";
                        String sUserName = "";
                        String sUserBrowsePwd = "";
                        String sUserUpdatePwd = "";
                        String sInserted = "";
                        String sDeleted = "";
                        String sValue = "";
                        boolean bSpecial = false;
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalUserRecords++;
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserId = sValue;
                                            break;
                                        }
                                        case "USERNAME":
                                        {
                                            sUserName = sValue;
                                            break;
                                        }
                                        case "USERBROWSEPWD":
                                        {
                                            sUserBrowsePwd = sValue;
                                            break;
                                        }
                                        case "USERUPDATEPWD":
                                        {
                                            sUserUpdatePwd = sValue;
                                            break;
                                        }
                                        case "SPECIAL":
                                        {
                                            bSpecial = sValue.equals("1");
                                            break;
                                        }
                                        case "INSERTED":
                                        {
                                            sInserted = sValue;
                                            break;
                                        }
                                        case "DELETED":
                                        {
                                            sDeleted = sValue;
                                            break;
                                        }
                                    }
                                }
                                Userid userid =
                                        new Userid(Integer.parseInt(sUserId), Integer.parseInt(sUserId), sUserName, sUserBrowsePwd, sUserUpdatePwd, sInserted, sDeleted, bSpecial);

                                dbHandler.addUserid(userid);
                            }

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetLastIDFromDisplayAbsolute";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sFields[];
                        String sField[];
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                            Log.d("Response", result);
                            sFields = result.split("<<");
                            sField = sFields[0].split(Pattern.quote("||"));
                            sMaxID = sField[1];
                        }
                    }
                });

                if (!sMaxID.equals(""))
                {
                    while (iID < Integer.parseInt(sMaxID))
                    {
                        progressStatus = Integer.parseInt( Long.toString( Math.round((Float.parseFloat(String.valueOf(iID)) / Float.parseFloat(sMaxID)) * 100.0 )));
                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "Get10NamesByID '" + String.valueOf(iID) + "'";
                        s = s + "</commandtext>";
                        s = s + "<returnsdata>true</returnsdata>";
                        s = s + "</command>";

                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    String sRecords[];
                                    String sFields[];
                                    String sField[];
                                    String replacedNameString = "";
                                    String replacedPhoneString = "";
                                    String replacedMiscString = "";
                                    String sID = "";
                                    String sUserID = "";
                                    String sMapInfo = "";
                                    String sInserted = "";
                                    String sDeleted = "";
                                    String sValue = "";
                                    int idx = 0;
                                    int idxRecords = 0;
                                    sRecords = result.split(">>");
                                    for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                    {
                                        replacedNameString = "";
                                        replacedPhoneString = "";
                                        replacedMiscString = "";
                                        sID = "";
                                        sUserID = "";
                                        sMapInfo = "";
                                        sInserted = "";
                                        sDeleted = "";
                                        sFields = sRecords[idxRecords].split("<<");
                                        for (idx = 0; idx < sFields.length; idx++)
                                        {
                                            sField = sFields[idx].split(Pattern.quote("||"));
                                            if (sField.length > 1)
                                            {
                                                sValue = sField[1];
                                            }
                                            else
                                            {
                                                sValue = "";
                                            }
                                            switch (sField[0].toUpperCase())
                                            {
                                                case "ID":
                                                {
                                                    sID = sValue;
                                                    iID = Integer.parseInt(sID);
                                                    break;
                                                }
                                                case "USERID":
                                                {
                                                    sUserID = sValue;
                                                    break;
                                                }
                                                case "NAME":
                                                {
                                                    replacedNameString = sValue.replace("xxbrxx", "\r\n");
                                                    replacedNameString = replacedNameString.replace("<br>", "\r\n");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutLt, "<");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutGt, ">");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutBar, "|");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutAmpersand, "&");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutApos, "'");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutPercent, "%");
                                                    replacedNameString = replacedNameString.replace(gsCodeOutQuote, "\"");
                                                    break;
                                                }
                                                case "PHONE":
                                                {
                                                    replacedPhoneString = sValue.replace("xxbrxx", "\r\n");
                                                    replacedPhoneString = replacedPhoneString.replace("<br>", "\r\n");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutLt, "<");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutGt, ">");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutBar, "|");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutAmpersand, "&");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutApos, "'");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutPercent, "%");
                                                    replacedPhoneString = replacedPhoneString.replace(gsCodeOutQuote, "\"");
                                                    break;
                                                }
                                                case "MISC":
                                                {
                                                    replacedMiscString = sValue.replace("xxbrxx", "\r\n");
                                                    replacedMiscString = replacedMiscString.replace("<br>", "\r\n");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutLt, "<");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutGt, ">");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutBar, "|");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutAmpersand, "&");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutApos, "'");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutPercent, "%");
                                                    replacedMiscString = replacedMiscString.replace(gsCodeOutQuote, "\"");
                                                    break;
                                                }
                                                case "MAPINFO":
                                                {
                                                    sMapInfo = sValue.replace("xxbrxx", "\r\n");
                                                    sMapInfo = sMapInfo.replace("<br>", "\r\n");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutLt, "<");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutGt, ">");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutBar, "|");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutAmpersand, "&");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutApos, "'");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutPercent, "%");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutQuote, "\"");
                                                    break;
                                                }
                                                case "INSERTED":
                                                {
                                                    sInserted = sValue;
                                                    break;
                                                }
                                                case "DELETED":
                                                {
                                                    sDeleted = sValue;
                                                    break;
                                                }
                                            }
                                        }

                                        Display display =
                                                new Display(Integer.parseInt(sID), Integer.parseInt(sUserID), replacedNameString, replacedPhoneString, replacedMiscString, sMapInfo, sInserted, sDeleted);

                                        dbHandler.addDisplay(display);
                                        iTotalRecords++;

//                                        if (sDeleted.equals("")) {
//                                            Display display =
//                                                    new Display(Integer.parseInt(sID), Integer.parseInt(sUserID), replacedNameString, replacedPhoneString, replacedMiscString, sMapInfo, sInserted, null);
//                                            dbHandler.addDisplay(display);
//                                            iTotalRecords++;
//                                        }
                                    }
                                }
                            }
                        });
                    }



                    z = "Successfully loaded " + String.valueOf(iTotalRecords) + " data records and " + String.valueOf(iTotalUserRecords) + " user records.";
                }
                else
                {
                    z = "No records found to copy.";
                }
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }

    public class DoAutoSync extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private String sMaxID = "";
        private int iID = 0;
        private int iTotalRecords = 0;
        private int iTotalUserRecords = 0;
        private int iTotalErrors = 0;
        private String sLastInsertedLocal = "";
        private String sLastDeletedLocal = "";
        private String sLastInsertedMain = "";
        private String sLastDeletedMain = "";
        private Boolean bInsertsLocal = false;
        private Boolean bInsertsMain = false;
        private Boolean bDeletesLocal = false;
        private Boolean bDeletesMain = false;
        private Boolean bDone = false;
        private String s = "";
        private UpdateStatus usLocal = null;
        private UpdateStatus usMain = null;
        private DataGroup dg = null;
        private int iMaxID = 0;
        private int iMaxUserID = 0;
        private Boolean bOKToUpdate = false;
        private String sFinalLastInserted = "";
        private String sFinalLastDeleted = "";
        private Boolean bAddUserError = false;

        SparseArray <String> sNewUserid = new SparseArray<String>();
        SparseArray <String> sOldUserid = new SparseArray<String>();

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
            if (!(r.equals(""))) {
//                Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();

                NotificationUtils.GenerateNotification("Auto Sync Updates", r,
                        1, null, false, MainActivity.this,
                        notificationManager, NotificationCompat.PRIORITY_HIGH);

            }
            MainActivity.this.getLastLoginInfo();

            if(isSuccess)
            {
                MainActivity.this.debugClass("r = " + r);
            }

        }

        @Override
        protected String doInBackground(String... params) {
            final MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
            try
            {

                iTotalRecords = 0;
                iTotalUserRecords = 0;

                groupsNeedSyncLocal = new SparseArray<DataGroup>();
                groupsNeedSyncMain = new SparseArray<DataGroup>();
                groupsTemp = new SparseArray<DataGroup>();

                //get update status from local, main, and alt dbs
                usLocal = dbHandler.findUpdateStatus();
                sLastInsertedLocal = usLocal.getLastInserted();
                sLastDeletedLocal = usLocal.getLastDeleted();
                if (sLastInsertedLocal.equals("")) {
                    // not ready to sync yet, need to load the db first
                    z = "Not ready for auto sync. \r\nLoad the database.";
                    isSuccess = true;
                } else {
                    s = "<?xml version=\"1.0\"?>" + "\r\n";
                    s = s + "<command><commandtext>";
                    s = s + "GetUpdateStatus";
                    s = s + "</commandtext>";
                    s = s + "<returnsdata>true</returnsdata>";
                    s = s + "</command>";

                    NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                    {
                        @Override
                        public void getResult(String result)
                        {
                            String [] sRecords;
                            String [] sFields;
                            String [] sField;
                            String sValue = "";
                            String sLastInserted = "";
                            String sLastDeleted = "";
                            if (!result.isEmpty())
                            {
                                //do what you need with the result...
//                                Log.d("Response", result);
                                sFields = result.split("<<");
                                int idx = 0;
                                int idxRecords = 0;
                                sRecords = result.split(">>");
                                for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                {
                                    sFields = sRecords[idxRecords].split("<<");
                                    for (idx = 0; idx < sFields.length; idx++)
                                    {
                                        sField = sFields[idx].split(Pattern.quote("||"));
                                        if (sField.length > 1)
                                        {
                                            sValue = sField[1];
                                        }
                                        else
                                        {
                                            sValue = "";
                                        }
                                        switch (sField[0].toUpperCase())
                                        {
                                            case "LASTINSERTED":
                                            {
                                                sLastInserted = sValue;
                                                break;
                                            }
                                            case "LASTDELETED":
                                            {
                                                sLastDeleted = sValue;
                                                break;
                                            }
                                        }
                                    }
                                    usMain = new UpdateStatus(sLastInserted, sLastDeleted, sLastInserted, sLastDeleted);
                                    sLastInsertedMain = sLastInserted;
                                    sLastDeletedMain = sLastDeleted;
                                }

                            }
                        }
                    });


                    Log.d("DoAutoSync", "sLastInsertedLocal = " + sLastInsertedLocal);
                    Log.d("DoAutoSync", "sLastDeletedLocal = " + sLastDeletedLocal);
                    Log.d("DoAutoSync", "sLastInsertedMain = " + sLastInsertedMain);
                    Log.d("DoAutoSync", "sLastDeletedMain = " + sLastDeletedMain);
                    Log.d("DoAutoSync", "usLocal.getOrigLastInserted() = " + usLocal.getOrigLastInserted());
                    Log.d("DoAutoSync", "usLocal.getOrigLastDeleted() = " + usLocal.getOrigLastDeleted());
                    progressStatus = 10;

                    z = "";
                    if (!(sLastInsertedMain.equals(""))) {
                        if (!(sLastInsertedLocal.equals(sLastInsertedMain))) {
                            if (usLocal.getOrigLastInserted().equals(sLastInsertedMain)) {
                                //something inserted local
                                z = z + "something inserted in local\r\n";
                                bInsertsLocal = true;
                            } else if (sLastInsertedLocal.equals(usLocal.getOrigLastInserted())) {
                                //something inserted in main
                                z = z + "something inserted in main\r\n";
                                bInsertsMain = true;
                            } else {
                                //something inserted in both local and main
                                z = z + "something inserted in both local and main\r\n";
                                bInsertsLocal = true;
                                bInsertsMain = true;
                            }
                        }
                        if (!(sLastDeletedLocal.equals(sLastDeletedMain))) {
                            if (usLocal.getOrigLastDeleted().equals(sLastDeletedMain)) {
                                //something deleted from local
                                z = z + "something deleted from local\r\n";
                                bDeletesLocal = true;
                            } else if (sLastDeletedLocal.equals(usLocal.getOrigLastDeleted())) {
                                //something deleted from main
                                z = z + "something deleted from main\r\n";
                                bDeletesMain = true;
                            } else {
                                //something deleted from both local and main
                                z = z + "something deleted from both local and main\r\n";
                                bDeletesLocal = true;
                                bDeletesMain = true;
                            }
                        }
                        if (z.equals("")) {
                            progressStatus = 80;
                            //z = "No need to auto sync.";
                        } else {
                            Log.d("DoAutoSync", "z = " + z);
                            z = "";
                            //process changes
                            progressStatus = 20;
                            if (bInsertsLocal || bDeletesLocal) {
                                groupsNeedSyncLocal = dbHandler.GetSyncInfo();
                                if (groupsNeedSyncLocal.size() != 0) {
                                    Log.d("DoAutoSync", "groupsNeedSyncLocal.size() = " + String.valueOf(groupsNeedSyncLocal.size()));
                                }
                            } else {
                                Log.d("DoAutoSync", "groupsNeedSyncLocal.size() = " + String.valueOf(groupsNeedSyncLocal.size()));
                            }
                            progressStatus = 40;
                            if (bInsertsMain) {
                                //check userinfo updates
                                s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "Get10UsersByInsertedDate '" + usLocal.getOrigLastInserted() + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>true</returnsdata>";
                                s = s + "</command>";

                                bDone = false;
                                while (!bDone) {
                                    NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>(){
                                        @Override
                                        public void getResult(String result) {
                                            if (!result.isEmpty())
                                            {
                                                String sRecords[];
                                                String sFields[];
                                                String sField[];
                                                String replacedNameString = "";
                                                String replacedPhoneString = "";
                                                String replacedMiscString = "";
                                                String sID = "";
                                                String sUserId = "";
                                                String sUserName = "";
                                                String sUserBrowsePwd = "";
                                                String sUserUpdatePwd = "";
                                                String sInserted = "";
                                                String sDeleted = "";
                                                String sSpecial = "";
                                                String sValue = "";
                                                int idx = 0;
                                                int idxRecords = 0;
                                                sRecords = result.split(">>");
                                                Log.d("DoAutoSync", "sRecords.length = " + String.valueOf(sRecords.length));
                                                for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                                {
                                                    replacedNameString = "";
                                                    replacedPhoneString = "";
                                                    replacedMiscString = "";
                                                    sID = "";
                                                    sUserId = "";
                                                    sUserName = "";
                                                    sUserBrowsePwd = "";
                                                    sUserUpdatePwd = "";
                                                    sSpecial = "";
                                                    sInserted = "";
                                                    sFields = sRecords[idxRecords].split("<<");
                                                    for (idx = 0; idx < sFields.length; idx++)
                                                    {
                                                        sField = sFields[idx].split(Pattern.quote("||"));
                                                        if (sField.length > 1)
                                                        {
                                                            sValue = sField[1];
                                                        }
                                                        else
                                                        {
                                                            sValue = "";
                                                        }
                                                        switch (sField[0].toUpperCase())
                                                        {
//                                                            case "ID":
//                                                            {
//                                                                sID = sValue;
//                                                                iID = Integer.parseInt(sID);
//                                                                break;
//                                                            }
                                                            case "USERID":
                                                            {
                                                                sUserId = sValue;
                                                                break;
                                                            }
                                                            case "USERNAME":
                                                            {
                                                                sUserName = sValue;
                                                                break;
                                                            }
                                                            case "USERBROWSEPWD":
                                                            {
                                                                sUserBrowsePwd = sValue;
                                                                break;
                                                            }
                                                            case "USERUPDATEPWD":
                                                            {
                                                                sUserUpdatePwd = sValue;
                                                                break;
                                                            }
                                                            case "SPECIAL":
                                                            {
                                                                sSpecial = sValue;
                                                                break;
                                                            }
                                                            case "INSERTED":
                                                            {
                                                                sInserted = sValue;
                                                                break;
                                                            }
                                                        }
                                                    }

                                                    DataGroup group = new DataGroup();
                                                    group.id = Integer.parseInt(sUserId);
                                                    group.iMainDBId = Integer.parseInt(sUserId);
                                                    group.userid  = Integer.parseInt(sUserId);
                                                    group.string =  sUserName;
                                                    group.phone =  sUserBrowsePwd;
                                                    group.misc = sUserUpdatePwd;
                                                    group.mapinfo = sSpecial;
                                                    group.sInserted = sInserted;

                                                    groupsTemp = dbHandler.findAllUsersByMainID(group.id);
                                                    if (groupsTemp.size() > 0) {
                                                        if (groupsTemp.valueAt(0).iMainDBId > -1) {
                                                            group.sStatus = "UpdatedUser";
                                                            Log.d("DoAutoSync", "Main Updated User = " + String.valueOf(groupsTemp.valueAt(0).iMainDBId));
                                                        } else {
                                                            group.sStatus = "InsertedUser";
                                                            Log.d("DoAutoSync", "Main Inserted User 1 ID = " + String.valueOf(groupsTemp.valueAt(0).iMainDBId));
                                                        }

                                                    } else {
                                                        group.sStatus = "InsertedUser";
                                                        Log.d("DoAutoSync", "Main Inserted User 2 ID = " + String.valueOf(group.iMainDBId));
                                                    }

                                                    groupsNeedSyncMain.append(groupsNeedSyncMain.size(), group);


                                                }
                                                if (sRecords.length == 10) {
                                                    s = "<?xml version=\"1.0\"?>" + "\r\n";
                                                    s = s + "<command><commandtext>";
                                                    s = s + "Get10UsersByInsertedDate '" + sInserted + "'";
                                                    s = s + "</commandtext>";
                                                    s = s + "<returnsdata>true</returnsdata>";
                                                    s = s + "</command>";
                                                } else {
                                                    bDone = true;
                                                }

                                            }
                                            else {
                                                bDone = true;
                                            }
                                        }
                                    });

                                }

                                //check for display record updates
                                s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "Get10NamesByInsertedDate '" + usLocal.getOrigLastInserted() + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>true</returnsdata>";
                                s = s + "</command>";

                                bDone = false;
                                while (!bDone) {
                                    NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>(){
                                        @Override
                                        public void getResult(String result) {
                                            if (!result.isEmpty())
                                            {
                                                String sRecords[];
                                                String sFields[];
                                                String sField[];
                                                String replacedNameString = "";
                                                String replacedPhoneString = "";
                                                String replacedMiscString = "";
                                                String sID = "";
                                                String sUserID = "";
                                                String sMapInfo = "";
                                                String sInserted = "";
                                                String sValue = "";
                                                int idx = 0;
                                                int idxRecords = 0;
                                                sRecords = result.split(">>");
                                                Log.d("DoAutoSync", "sRecords.length = " + String.valueOf(sRecords.length));
                                                for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                                {
                                                    replacedNameString = "";
                                                    replacedPhoneString = "";
                                                    replacedMiscString = "";
                                                    sID = "";
                                                    sUserID = "";
                                                    sMapInfo = "";
                                                    sInserted = "";
                                                    sFields = sRecords[idxRecords].split("<<");
                                                    for (idx = 0; idx < sFields.length; idx++)
                                                    {
                                                        sField = sFields[idx].split(Pattern.quote("||"));
                                                        if (sField.length > 1)
                                                        {
                                                            sValue = sField[1];
                                                        }
                                                        else
                                                        {
                                                            sValue = "";
                                                        }
                                                        switch (sField[0].toUpperCase())
                                                        {
                                                            case "ID":
                                                            {
                                                                sID = sValue;
                                                                iID = Integer.parseInt(sID);
                                                                break;
                                                            }
                                                            case "USERID":
                                                            {
                                                                sUserID = sValue;
                                                                break;
                                                            }
                                                            case "NAME":
                                                            {
                                                                replacedNameString = sValue.replace("xxbrxx", "\r\n");
                                                                replacedNameString = replacedNameString.replace("<br>", "\r\n");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutLt, "<");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutGt, ">");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutBar, "|");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutAmpersand, "&");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutApos, "'");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutPercent, "%");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "PHONE":
                                                            {
                                                                replacedPhoneString = sValue.replace("xxbrxx", "\r\n");
                                                                replacedPhoneString = replacedPhoneString.replace("<br>", "\r\n");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutLt, "<");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutGt, ">");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutBar, "|");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutAmpersand, "&");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutApos, "'");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutPercent, "%");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "MISC":
                                                            {
                                                                replacedMiscString = sValue.replace("xxbrxx", "\r\n");
                                                                replacedMiscString = replacedMiscString.replace("<br>", "\r\n");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutLt, "<");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutGt, ">");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutBar, "|");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutAmpersand, "&");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutApos, "'");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutPercent, "%");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "MAPINFO":
                                                            {
                                                                sMapInfo = sValue.replace("xxbrxx", "\r\n");
                                                                sMapInfo = sMapInfo.replace("<br>", "\r\n");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutLt, "<");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutGt, ">");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutBar, "|");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutAmpersand, "&");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutApos, "'");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutPercent, "%");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "INSERTED":
                                                            {
                                                                sInserted = sValue;
                                                                break;
                                                            }
                                                        }
                                                    }

                                                    DataGroup group = new DataGroup();
                                                    group.id = Integer.parseInt(sID);
                                                    group.iMainDBId = Integer.parseInt(sID);
                                                    group.userid  = Integer.parseInt(sUserID);
                                                    group.string =  replacedNameString;
                                                    group.phone =  replacedPhoneString;
                                                    group.findPhoneNumbers();
                                                    group.children.add(replacedMiscString);
                                                    group.misc = replacedMiscString;
                                                    group.mapinfo = sMapInfo;
                                                    group.sInserted = sInserted;

                                                    groupsTemp = dbHandler.findAllDisplayByMainID(group.id);
                                                    if (groupsTemp.size() > 0) {
                                                        if (groupsTemp.valueAt(0).iMainDBId > -1) {
                                                            group.sStatus = "Updated";
                                                            Log.d("DoAutoSync", "Main Updated ID = " + String.valueOf(groupsTemp.valueAt(0).iMainDBId));
                                                        } else {
                                                            group.sStatus = "Inserted";
                                                            Log.d("DoAutoSync", "Main Inserted 1 ID = " + String.valueOf(groupsTemp.valueAt(0).iMainDBId));
                                                        }

                                                    } else {
                                                        group.sStatus = "Inserted";
                                                        Log.d("DoAutoSync", "Main Inserted 2 ID = " + String.valueOf(group.iMainDBId));
                                                    }

                                                    groupsNeedSyncMain.append(groupsNeedSyncMain.size(), group);


                                                }
                                                if (sRecords.length == 10) {
                                                    s = "<?xml version=\"1.0\"?>" + "\r\n";
                                                    s = s + "<command><commandtext>";
                                                    s = s + "Get10NamesByInsertedDate '" + sInserted + "'";
                                                    s = s + "</commandtext>";
                                                    s = s + "<returnsdata>true</returnsdata>";
                                                    s = s + "</command>";
                                                } else {
                                                    bDone = true;
                                                }

                                            }
                                            else {
                                                bDone = true;
                                            }
                                        }
                                    });

                                }
                                if (groupsNeedSyncMain.size() != 0) {
                                    Log.d("DoAutoSync", "groupsNeedSyncMain.size() after Inserts = " + String.valueOf(groupsNeedSyncMain.size()));
                                }

                            }
                            progressStatus = 60;
                            if (bDeletesMain) {

                                //check userinfo deletes
                                s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "Get10UsersByDeletedDate '" + usLocal.getOrigLastDeleted() + "', '" + usLocal.getOrigLastInserted() + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>true</returnsdata>";
                                s = s + "</command>";

                                bDone = false;
                                while (!bDone) {
                                    NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>(){
                                        @Override
                                        public void getResult(String result) {
                                            if (!result.isEmpty())
                                            {
                                                String sRecords[];
                                                String sFields[];
                                                String sField[];
                                                String sID = "";
                                                String sUserId = "";
                                                String sUserName = "";
                                                String sUserBrowsePwd = "";
                                                String sUserUpdatePwd = "";
                                                String sInserted = "";
                                                String sDeleted = "";
                                                String sSpecial = "";
                                                String sValue = "";
                                                int idx = 0;
                                                int idxRecords = 0;
                                                sRecords = result.split(">>");
                                                Log.d("DoAutoSync", "sRecords.length = " + String.valueOf(sRecords.length));
                                                for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                                {
                                                    sID = "";
                                                    sUserId = "";
                                                    sUserName = "";
                                                    sUserBrowsePwd = "";
                                                    sUserUpdatePwd = "";
                                                    sSpecial = "";
                                                    sInserted = "";
                                                    sFields = sRecords[idxRecords].split("<<");
                                                    for (idx = 0; idx < sFields.length; idx++)
                                                    {
                                                        sField = sFields[idx].split(Pattern.quote("||"));
                                                        if (sField.length > 1)
                                                        {
                                                            sValue = sField[1];
                                                        }
                                                        else
                                                        {
                                                            sValue = "";
                                                        }
                                                        switch (sField[0].toUpperCase())
                                                        {
                                                            case "ID":
                                                            {
                                                                sID = sValue;
                                                                iID = Integer.parseInt(sID);
                                                                break;
                                                            }
                                                            case "USERID":
                                                            {
                                                                sUserId = sValue;
                                                                break;
                                                            }
                                                            case "USERNAME":
                                                            {
                                                                sUserName = sValue;
                                                                break;
                                                            }
                                                            case "USERBROWSEPWD":
                                                            {
                                                                sUserBrowsePwd = sValue;
                                                                break;
                                                            }
                                                            case "USERUPDATEPWD":
                                                            {
                                                                sUserUpdatePwd = sValue;
                                                                break;
                                                            }
                                                            case "SPECIAL":
                                                            {
                                                                sSpecial = sValue;
                                                                break;
                                                            }
                                                            case "INSERTED":
                                                            {
                                                                sInserted = sValue;
                                                                break;
                                                            }
                                                            case "DELETED":
                                                            {
                                                                sDeleted = sValue;
                                                                break;
                                                            }
                                                        }
                                                    }

                                                    DataGroup group = new DataGroup();
                                                    group.id = Integer.parseInt(sID);
                                                    group.iMainDBId = Integer.parseInt(sID);
                                                    group.userid  = Integer.parseInt(sUserId);
                                                    group.string =  sUserName;
                                                    group.phone =  sUserBrowsePwd;
                                                    group.misc = sUserUpdatePwd;
                                                    group.mapinfo = sSpecial;
                                                    group.sInserted = sInserted;
                                                    group.sDeleted = sDeleted;
                                                    group.sStatus = "DeletedUser";
                                                    groupsNeedSyncMain.append(groupsNeedSyncMain.size(), group);

                                                }
                                                if (sRecords.length == 10) {
                                                    s = "<?xml version=\"1.0\"?>" + "\r\n";
                                                    s = s + "<command><commandtext>";
                                                    s = s + "Get10UsersByDeletedDate '" + sDeleted + "', '" + usLocal.getOrigLastInserted() + "'";
                                                    s = s + "</commandtext>";
                                                    s = s + "<returnsdata>true</returnsdata>";
                                                    s = s + "</command>";
                                                } else {
                                                    bDone = true;
                                                }

                                            }
                                            else {
                                                bDone = true;
                                            }
                                        }
                                    });

                                }

                                //check for display record deletes
                                s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "Get10NamesByDeletedDate '" + usLocal.getOrigLastDeleted() + "', '" + usLocal.getOrigLastInserted() + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>true</returnsdata>";
                                s = s + "</command>";

                                Log.d("DoAutoSync", "Get10NamesByDeletedDate '" + usLocal.getOrigLastDeleted() + "', '" + usLocal.getOrigLastInserted() + "'");

                                bDone = false;
                                while (!bDone) {
                                    NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                                    {
                                        @Override
                                        public void getResult(String result)
                                        {
                                            if (!result.isEmpty())
                                            {
                                                String sRecords[];
                                                String sFields[];
                                                String sField[];
                                                String replacedNameString = "";
                                                String replacedPhoneString = "";
                                                String replacedMiscString = "";
                                                String sID = "";
                                                String sUserID = "";
                                                String sMapInfo = "";
                                                String sInserted = "";
                                                String sDeleted = "";
                                                String sValue = "";
                                                int idx = 0;
                                                int idxRecords = 0;
                                                sRecords = result.split(">>");
                                                for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                                {
                                                    replacedNameString = "";
                                                    replacedPhoneString = "";
                                                    replacedMiscString = "";
                                                    sID = "";
                                                    sUserID = "";
                                                    sMapInfo = "";
                                                    sInserted = "";
                                                    sDeleted = "";
                                                    sFields = sRecords[idxRecords].split("<<");
                                                    for (idx = 0; idx < sFields.length; idx++)
                                                    {
                                                        sField = sFields[idx].split(Pattern.quote("||"));
                                                        if (sField.length > 1)
                                                        {
                                                            sValue = sField[1];
                                                        }
                                                        else
                                                        {
                                                            sValue = "";
                                                        }
                                                        switch (sField[0].toUpperCase())
                                                        {
                                                            case "ID":
                                                            {
                                                                sID = sValue;
                                                                iID = Integer.parseInt(sID);
                                                                break;
                                                            }
                                                            case "USERID":
                                                            {
                                                                sUserID = sValue;
                                                                break;
                                                            }
                                                            case "NAME":
                                                            {
                                                                replacedNameString = sValue.replace("xxbrxx", "\r\n");
                                                                replacedNameString = replacedNameString.replace("<br>", "\r\n");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutLt, "<");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutGt, ">");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutBar, "|");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutAmpersand, "&");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutApos, "'");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutPercent, "%");
                                                                replacedNameString = replacedNameString.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "PHONE":
                                                            {
                                                                replacedPhoneString = sValue.replace("xxbrxx", "\r\n");
                                                                replacedPhoneString = replacedPhoneString.replace("<br>", "\r\n");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutLt, "<");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutGt, ">");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutBar, "|");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutAmpersand, "&");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutApos, "'");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutPercent, "%");
                                                                replacedPhoneString = replacedPhoneString.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "MISC":
                                                            {
                                                                replacedMiscString = sValue.replace("xxbrxx", "\r\n");
                                                                replacedMiscString = replacedMiscString.replace("<br>", "\r\n");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutLt, "<");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutGt, ">");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutBar, "|");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutAmpersand, "&");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutApos, "'");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutPercent, "%");
                                                                replacedMiscString = replacedMiscString.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "MAPINFO":
                                                            {
                                                                sMapInfo = sValue.replace("xxbrxx", "\r\n");
                                                                sMapInfo = sMapInfo.replace("<br>", "\r\n");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutLt, "<");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutGt, ">");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutBar, "|");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutAmpersand, "&");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutApos, "'");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutPercent, "%");
                                                                sMapInfo = sMapInfo.replace(gsCodeOutQuote, "\"");
                                                                break;
                                                            }
                                                            case "INSERTED":
                                                            {
                                                                sInserted = sValue;
                                                                break;
                                                            }
                                                            case "DELETED":
                                                            {
                                                                sDeleted = sValue;
                                                                break;
                                                            }
                                                        }
                                                    }

                                                    DataGroup group = new DataGroup();
                                                    group.id = Integer.parseInt(sID);
                                                    group.iMainDBId = Integer.parseInt(sID);
                                                    group.userid  = Integer.parseInt(sUserID);
                                                    group.string =  replacedNameString;
                                                    group.phone =  replacedPhoneString;
                                                    group.findPhoneNumbers();
                                                    group.children.add(replacedMiscString);
                                                    group.misc = replacedMiscString;
                                                    group.mapinfo = sMapInfo;
                                                    group.sInserted = sInserted;
                                                    group.sDeleted = sDeleted;
                                                    group.sStatus = "Deleted";
                                                    groupsNeedSyncMain.append(groupsNeedSyncMain.size(), group);


                                                }
                                                if (sRecords.length == 10) {
                                                    s = "<?xml version=\"1.0\"?>" + "\r\n";
                                                    s = s + "<command><commandtext>";
                                                    s = s + "Get10NamesByDeletedDate '" + sDeleted + "', '" + usLocal.getOrigLastInserted() + "'";
                                                    s = s + "</commandtext>";
                                                    s = s + "<returnsdata>true</returnsdata>";
                                                    s = s + "</command>";
                                                } else {
                                                    bDone = true;
                                                }


                                            }
                                            else {
                                                bDone = true;
                                            }
                                        }
                                    });
                                }
                                if (groupsNeedSyncMain.size() != 0) {
                                    Log.d("DoAutoSync", "groupsNeedSyncMain.size() after Deletes = " + String.valueOf(groupsNeedSyncMain.size()));
                                }

                            }

                            //get the last id used in the main db - to be used to insert new records from local to main

                            progressStatus = 70;
                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                            s = s + "<command><commandtext>";
                            s = s + "GetLastIDFromDisplayAbsolute";
                            s = s + "</commandtext>";
                            s = s + "<returnsdata>true</returnsdata>";
                            s = s + "</command>";

                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                @Override
                                public void getResult(String result) {
                                    String sFields[];
                                    String sField[];
                                    if (!result.isEmpty())
                                    {
                                        //do what you need with the result...
//                            Log.d("Response", result);
                                        sFields = result.split("<<");
                                        sField = sFields[0].split(Pattern.quote("||"));
                                        sMaxID = sField[1];
                                    }
                                }
                            });

                            Log.d("DoAutoSync", "sMaxID = " + sMaxID);
                            iMaxID = Integer.valueOf(sMaxID);

                            //get the last userid used in the main db - to be used to insert new userid records from local to main

                            progressStatus = 75;
                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                            s = s + "<command><commandtext>";
                            s = s + "GetLastIDFromUserIdAbsolute";
                            s = s + "</commandtext>";
                            s = s + "<returnsdata>true</returnsdata>";
                            s = s + "</command>";

                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                @Override
                                public void getResult(String result) {
                                    String sFields[];
                                    String sField[];
                                    if (!result.isEmpty())
                                    {
                                        //do what you need with the result...
//                            Log.d("Response", result);
                                        sFields = result.split("<<");
                                        sField = sFields[0].split(Pattern.quote("||"));
                                        sMaxID = sField[1];
                                    }
                                }
                            });

                            Log.d("DoAutoSync", "sMaxUserID = " + sMaxID);
                            iMaxUserID = Integer.valueOf(sMaxID);

                            //ready to apply changes
                            progressStatus = 80;
                            if (groupsNeedSyncMain.size() > 0) {
                                int idxGroupsMain = 0;
                                for (idxGroupsMain = 0; idxGroupsMain < groupsNeedSyncMain.size(); idxGroupsMain++) {
                                    dg = groupsNeedSyncMain.valueAt(idxGroupsMain);
                                    Log.d("DoAutoSync", "Main groups idx = " + String.valueOf(idxGroupsMain) + ", status = " + dg.sStatus +
                                            ", id = " + String.valueOf(dg.id) + ", MainId = " + String.valueOf(dg.iMainDBId) +
                                            ", Name = " + dg.string);
                                    if (dg.sStatus.equals("Updated")) {
                                        //need to update if not deleted locally
                                        groupsTemp = dbHandler.findAllDisplayByMainID(dg.id);
                                        if (groupsTemp.size() > 0) {
                                            if (groupsTemp.valueAt(0).sDeleted.equals("")) {
                                                //ok to update
                                                Boolean bOK = dbHandler.updateDisplayNoStatusUpdate(String.valueOf(groupsTemp.valueAt(0).id), dg.string,
                                                        dg.phone, dg.misc, dg.mapinfo, dg.sInserted);
                                                if (sFinalLastInserted.equals("")) {
                                                    sFinalLastInserted = dg.sInserted;
                                                } else {
                                                    if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                        sFinalLastInserted = dg.sInserted;
                                                    }
                                                }
                                                z = z + "\r\n" + "Main to Local Update for Name = " + dg.string;
                                                Log.d("DoAutoSync", "Main to Local Update for Name = " + dg.string + " -- " + String.valueOf(bOK));
                                            } else {
                                                // deleted locally - so apply update and report discrepancy
                                                Boolean bOK = dbHandler.updateDisplayNoStatusUpdate(String.valueOf(groupsTemp.valueAt(0).id), dg.string,
                                                        dg.phone, dg.misc, dg.mapinfo, dg.sInserted);
                                                if (sFinalLastInserted.equals("")) {
                                                    sFinalLastInserted = dg.sInserted;
                                                } else {
                                                    if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                        sFinalLastInserted = dg.sInserted;
                                                    }
                                                }
                                                z = z + "\r\n" + "Main to Local Update Forced for Name = " + dg.string;
                                                Log.d("DoAutoSync", "Main to Local Update Forced for Name = " + dg.string + " -- " + String.valueOf(bOK));
                                            }
                                        } else {
                                            //could not find the record to update
                                            z = z + "\r\n" + "Main to Local Update not found locally for Name = " + dg.string;
                                            Log.d("DoAutoSync", "Main to Local Update not found locally for Name = " + dg.string);
                                        }
                                    } else if (dg.sStatus.equals("UpdatedUser")) {
                                        //need to update if not deleted locally
                                        groupsTemp = dbHandler.findAllUsersByMainID(dg.id);
                                        if (groupsTemp.size() > 0) {
                                            if (groupsTemp.valueAt(0).sDeleted.equals("")) {
                                                //ok to update
                                                Boolean bOK = dbHandler.updateUserIDNoStatusUpdate(String.valueOf(groupsTemp.valueAt(0).id), dg.string,
                                                        dg.phone, dg.misc, dg.mapinfo,  dg.sInserted);
                                                if (sFinalLastInserted.equals("")) {
                                                    sFinalLastInserted = dg.sInserted;
                                                } else {
                                                    if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                        sFinalLastInserted = dg.sInserted;
                                                    }
                                                }
                                                z = z + "\r\n" + "Main to Local Update for UserName = " + dg.string;
                                                Log.d("DoAutoSync", "Main to Local Update for UserName = " + dg.string + " -- " + String.valueOf(bOK));
                                            } else {
                                                // deleted locally - so apply update and report discrepancy
                                                Boolean bOK = dbHandler.updateUserIDNoStatusUpdate(String.valueOf(groupsTemp.valueAt(0).id), dg.string,
                                                        dg.phone, dg.misc, dg.mapinfo,  dg.sInserted);
                                                if (sFinalLastInserted.equals("")) {
                                                    sFinalLastInserted = dg.sInserted;
                                                } else {
                                                    if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                        sFinalLastInserted = dg.sInserted;
                                                    }
                                                }
                                                z = z + "\r\n" + "Main to Local UserUpdate Forced for UserName = " + dg.string;
                                                Log.d("DoAutoSync", "Main to Local Update Forced for UserName = " + dg.string + " -- " + String.valueOf(bOK));
                                            }
                                        } else {
                                            //could not find the record to update
                                            z = z + "\r\n" + "Main to Local Update not found locally for UserName = " + dg.string;
                                            Log.d("DoAutoSync", "Main to Local Update not found locally for UserName = " + dg.string);
                                        }
                                    } else if (dg.sStatus.equals("Inserted")) {
                                        //need to insert
                                        dbHandler.addDisplayAutoSync (String.valueOf(dg.id) , String.valueOf(dg.userid),  dg.string,
                                                dg.phone, dg.misc, dg.mapinfo, dg.sInserted);
                                        if (sFinalLastInserted.equals("")) {
                                            sFinalLastInserted = dg.sInserted;
                                        } else {
                                            if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                sFinalLastInserted = dg.sInserted;
                                            }
                                        }
                                        z = z + "\r\n" + "Main to Local Inserted Name = " + dg.string;
                                        Log.d("DoAutoSync", "Main to Local Inserted Name = " + dg.string);
                                    } else if (dg.sStatus.equals("InsertedUser")) {
                                        //need to insert

                                        //first need to change all of the userids in local records , userid, display and lastlogin, that match the new one to be inserted
                                        Integer iNewUserid = dbHandler.GetNextUserid();
                                        if (iNewUserid != 0) {
                                            if (iNewUserid <= dg.userid) {
                                                iNewUserid = dg.userid + 1;
                                            }
                                            Boolean bOK = dbHandler.updateUseridEverywhere(dg.userid, iNewUserid);

                                            //new change all of the local groups containing the new userid
                                            if (groupsNeedSyncLocal.size() > 0) {
                                                Integer idxGroupLocal = 0;
                                                for (idxGroupLocal = 0; idxGroupLocal < groupsNeedSyncLocal.size(); idxGroupLocal++) {
                                                    DataGroup dgLocal  = groupsNeedSyncLocal.valueAt(idxGroupLocal);
                                                    if (dgLocal.userid == dg.userid) {
                                                        dgLocal.userid = iNewUserid;
                                                    }
                                                }
                                            }
                                        }


                                        dbHandler.addUserIdAutoSync (String.valueOf(dg.id) , String.valueOf(dg.userid),  dg.string,
                                                dg.phone, dg.misc, dg.mapinfo, dg.sInserted);
                                        if (sFinalLastInserted.equals("")) {
                                            sFinalLastInserted = dg.sInserted;
                                        } else {
                                            if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                sFinalLastInserted = dg.sInserted;
                                            }
                                        }
                                        z = z + "\r\n" + "Main to Local Inserted UserName = " + dg.string;
                                        Log.d("DoAutoSync", "Main to Local Inserted UserName = " + dg.string);
                                    } else if (dg.sStatus.equals("Deleted")) {
                                        //need to update if not deleted locally
                                        groupsTemp = dbHandler.findAllDisplayByMainID(dg.id);
                                        Log.d("DoAutoSync", "groupsTemp.size() = " + String.valueOf(groupsTemp.size()) +
                                                ", id = " + String.valueOf(groupsTemp.valueAt(0).id) +
                                                ", dg.sDeleted = " + dg.sDeleted);
                                        if (groupsTemp.size() > 0) {
                                            if (groupsTemp.valueAt(0).sDeleted.equals("")) {
                                                //ok to delete
                                                Boolean bOK = dbHandler.deleteDisplayNoStatusUpdate(String.valueOf(groupsTemp.valueAt(0).id) , dg.sDeleted);
                                                z = z + "\r\n" + "Main to Local Deleted Name = " + dg.string;
                                                Log.d("DoAutoSync", "Main to Local Deleted Name = " + dg.string + " -- " + String.valueOf(bOK));
                                            } else {
                                                // deleted locally - so just change the deleted date and report discrepancy
                                                Boolean bOK = dbHandler.deleteDisplayNoStatusUpdate(String.valueOf(groupsTemp.valueAt(0).id) , dg.sDeleted);
                                                z = z + "\r\n" + "Main to Local Delete Forced for Name = " + dg.string;
                                                Log.d("DoAutoSync", "Main to Local Delete Forced for Name = " + dg.string + " -- " + String.valueOf(bOK));
                                            }
                                        } else {
                                            //could not find the record to delete
                                            z = z + "\r\n" + "Main to Local Delete not found locally for Name = " + dg.string;
                                            Log.d("DoAutoSync", "Main to Local Delete not found locally for Name = " + dg.string);
                                        }
                                        if (sFinalLastDeleted.equals("")) {
                                            sFinalLastDeleted = dg.sDeleted;
                                        } else {
                                            if (dg.sDeleted.compareTo(sFinalLastDeleted) > 0) {
                                                sFinalLastDeleted = dg.sDeleted;
                                            }
                                        }
                                    }
                                }
                            }

                            progressStatus = 90;
                            if (groupsNeedSyncLocal.size() > 0) {
                                int idxGroupsLocal = 0;
                                for (idxGroupsLocal = 0; idxGroupsLocal < groupsNeedSyncLocal.size(); idxGroupsLocal++) {
                                    dg = groupsNeedSyncLocal.valueAt(idxGroupsLocal);
                                    Log.d("DoAutoSync", "Local groups idx = " + String.valueOf(idxGroupsLocal) + ", status = " + dg.sStatus +
                                            ", id = " + String.valueOf(dg.id) + ", MainId = " + String.valueOf(dg.iMainDBId) +
                                            ", Name = " + dg.string);
                                    if (dg.sStatus.equals("Updated")) {
                                        //need to update if not deleted in main
                                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "Get1NameByID '" + String.valueOf(dg.iMainDBId - 1)  + "'"; //need to use MainDBId - 1 because the sp looks for the first record greater than this value
                                        s = s + "</commandtext>";
                                        s = s + "<returnsdata>true</returnsdata>";
                                        s = s + "</command>";

                                        bOKToUpdate = false;
                                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                            @Override
                                            public void getResult(String result) {
                                                if (!result.isEmpty())
                                                {
                                                    //found make sure it is the correct record, if so it so ok to update

                                                    String sRecords[];
                                                    String sFields[];
                                                    String sField[];
                                                    String sValue = "";
                                                    int idx = 0;
                                                    int idxRecords = 0;
                                                    sRecords = result.split(">>");
                                                    for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                                    {
                                                        sFields = sRecords[idxRecords].split("<<");
                                                        for (idx = 0; idx < sFields.length; idx++)
                                                        {
                                                            sField = sFields[idx].split(Pattern.quote("||"));
                                                            if (sField.length > 1)
                                                            {
                                                                sValue = sField[1];
                                                            }
                                                            else
                                                            {
                                                                sValue = "";
                                                            }
                                                            switch (sField[0].toUpperCase())
                                                            {
                                                                case "ID":
                                                                {
                                                                    if (!(sValue.equals(""))) {
                                                                        if (dg.iMainDBId == Integer.parseInt(sValue)){
                                                                            bOKToUpdate = true;
                                                                        }
                                                                    }
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                else {
                                                    //didn't find it so cannot update
                                                }
                                            }
                                        });

                                        if (bOKToUpdate) {
                                            String sInsertDate = dg.sInserted;
                                            String sID = String.valueOf(dg.iMainDBId);
                                            String sName = dg.string.replace("\r\n", "xxbrxx");
                                            sName = Replace_XMLChar(sName);

                                            String sPhone = dg.phone.replace("\r\n", "xxbrxx");
                                            sPhone = Replace_XMLChar(sPhone);
                                            if (sPhone.length() == 0)
                                            {
                                                sPhone = " ";
                                            }

                                            String sMisc = dg.misc.replace("\r\n", "xxbrxx");
                                            sMisc = Replace_XMLChar(sMisc);
                                            if (sMisc.length() == 0)
                                            {
                                                sMisc = " ";
                                            }

                                            String sMapInfo = dg.mapinfo.replace("\r\n", "xxbrxx");
                                            sMapInfo = Replace_XMLChar(sMapInfo);
                                            if (sMapInfo.length() == 0)
                                            {
                                                sMapInfo = " ";
                                            }

                                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                                            s = s + "<command><commandtext>";
                                            s = s + "ModifyDisplayNoStatusUpdate";
                                            s = s + "</commandtext>";
                                            s = s + "<returnsvalues>False</returnsvalues>";

                                            s = s + "<param>";
                                            s = s + "<name>InID</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sID.length() + "</size>";
                                            s = s + "<value>" + sID + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InName</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sName.length() + "</size>";
                                            s = s + "<value>" + sName + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InPhone</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sPhone.length() + "</size>";
                                            s = s + "<value>" + sPhone + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InMisc</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sMisc.length() + "</size>";
                                            s = s + "<value>" + sMisc + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InDate</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sInsertDate.length() + "</size>";
                                            s = s + "<value>" + sInsertDate + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InMapInfo</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sMapInfo.length() + "</size>";
                                            s = s + "<value>" + sMapInfo + "</value>";
                                            s = s + "</param>";

                                            s = s + "</command>";

                                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                                @Override
                                                public void getResult(String result) {
                                                    if (!result.isEmpty()) {
                                                        //could not update  main from local
                                                        z = z + "\r\n" + "Local to Main Failed to update in Main for Name = " + dg.string;
                                                        Log.d("DoAutoSync", "Local to Main Failed to update in Main for Name = " + dg.string + " -- result = " + result);

                                                    } else {
                                                        z = z + "\r\n" + "Local to Main updated in Main for Name = " + dg.string;
                                                        Log.d("DoAutoSync", "Local to Main updated in Main for Name = " + dg.string);
                                                        if (sFinalLastInserted.equals("")) {
                                                            sFinalLastInserted = dg.sInserted;
                                                        } else {
                                                            if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                                sFinalLastInserted = dg.sInserted;
                                                            }
                                                        }

                                                    }
                                                }
                                            });
                                        } else {
                                            //could not find the record to update in main from local
                                            z = z + "\r\n" + "Local to Main could not find record to update for Name = " + dg.string;
                                            Log.d("DoAutoSync", "Local to Main could not find record to update for Name = " + dg.string);
                                        }

                                    } else if (dg.sStatus.equals("UpdatedUser")) {
                                        //need to update if not deleted in main
                                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "GetUserByUserId '" + String.valueOf(dg.userid)  + "'";
                                        s = s + "</commandtext>";
                                        s = s + "<returnsdata>true</returnsdata>";
                                        s = s + "</command>";

                                        bOKToUpdate = false;
                                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                            @Override
                                            public void getResult(String result) {
                                                if (!result.isEmpty())
                                                {
                                                    //found so ok to update
                                                    bOKToUpdate = true;
                                                }
                                                else {
                                                    //didn't find it so cannot update
                                                }
                                            }
                                        });

                                        if (bOKToUpdate) {
                                            String sInsertDate = dg.sInserted;
                                            String sID = String.valueOf(dg.userid);
                                            String sName = dg.string;

                                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                                            s = s + "<command><commandtext>";
                                            s = s + "UpdateUserNoStatusUpdate";
                                            s = s + "</commandtext>";
                                            s = s + "<returnsvalues>False</returnsvalues>";

                                            s = s + "<param>";
                                            s = s + "<name>InID</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + sID.length() + "</size>";
                                            s = s + "<value>" + sID + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InName</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + dg.string.length() + "</size>";
                                            s = s + "<value>" + dg.string + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InBrowsePwd</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + dg.phone.length() + "</size>";
                                            s = s + "<value>" + dg.phone + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InUpdatePwd</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + dg.misc.length() + "</size>";
                                            s = s + "<value>" + dg.misc + "</value>";
                                            s = s + "</param>";

                                            s = s + "<param>";
                                            s = s + "<name>InDate</name>";
                                            s = s + "<type>130</type>";
                                            s = s + "<direction>1</direction>";
                                            s = s + "<size>" + dg.sInserted.length() + "</size>";
                                            s = s + "<value>" + dg.sInserted + "</value>";
                                            s = s + "</param>";

                                            s = s + "</command>";

                                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                                @Override
                                                public void getResult(String result) {
                                                    if (!result.isEmpty()) {
                                                        //could not update  main from local
                                                        z = z + "\r\n" + "Local to Main Failed to update in Main for UserName = " + dg.string;
                                                        Log.d("DoAutoSync", "Local to Main Failed to update in Main for UserName = " + dg.string + " -- result = " + result);

                                                    } else {
                                                        z = z + "\r\n" + "Local to Main updated in Main for UserName = " + dg.string;
                                                        Log.d("DoAutoSync", "Local to Main updated in Main for UserName = " + dg.string);
                                                        if (sFinalLastInserted.equals("")) {
                                                            sFinalLastInserted = dg.sInserted;
                                                        } else {
                                                            if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                                sFinalLastInserted = dg.sInserted;
                                                            }
                                                        }

                                                    }
                                                }
                                            });
                                        } else {
                                            //could not find the record to update in main from local
                                            z = z + "\r\n" + "Local to Main could not find record to update for UserName = " + dg.string;
                                            Log.d("DoAutoSync", "Local to Main could not find record to update for UserName = " + dg.string);
                                        }

                                    } else if (dg.sStatus.equals("Inserted")) {
                                        Log.d("DoAutoSync", "Local to Main To Insert Name = " + dg.string + ", dg.iMainDBId = " + String.valueOf(dg.iMainDBId));
                                        //need to insert in main
                                        String sName = dg.string.replace("\r\n", "xxbrxx");
                                        String sUserId = String.valueOf(dg.userid);
                                        sName = Replace_XMLChar(sName);

                                        String sPhone = dg.phone.replace("\r\n", "xxbrxx");
                                        sPhone = Replace_XMLChar(sPhone);
                                        if (sPhone.length() == 0)
                                        {
                                            sPhone = " ";
                                        }

                                        String sMisc = dg.misc.replace("\r\n", "xxbrxx");
                                        sMisc = Replace_XMLChar(sMisc);
                                        sMisc = sMisc.trim();
                                        if (sMisc.length() == 0)
                                        {
                                            sMisc = " ";
                                        }

                                        String sMapInfo = dg.mapinfo.replace("\r\n", "xxbrxx");
                                        sMapInfo = Replace_XMLChar(sMapInfo);
                                        sMapInfo = sMapInfo.trim();
                                        if (sMapInfo.length() == 0)
                                        {
                                            sMapInfo = " ";
                                        }

                                        iMaxID++;

                                        //now determine if the userid needs to be changed to match the newly inserted record in main
                                        if (sOldUserid.size() > 0) {
                                            int idxUserIdLocal = 0;
                                            for (idxUserIdLocal = 0; idxUserIdLocal < sOldUserid.size(); idxUserIdLocal++) {
                                                if (sOldUserid.get(idxUserIdLocal).equals(String.valueOf(dg.userid))) {
                                                    sUserId = sNewUserid.get(idxUserIdLocal);
                                                    break;
                                                }
                                            }
                                        }


                                        String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "AddToDisplayWithIdentity";

                                        /*
                                        s = s + " '" + sID + "'";
                                        s = s + ", '" + sUserID + "'";
                                        s = s + ", '" + sName + "'";
                                        s = s + ", '" + sPhone + "'";
                                        s = s + ", '" + sMisc + "'";
                                        s = s + ", '" + sInserted + "'";
                                        s = s + ", '" + sMapInfo + "'";
                                        */

                                        s = s + "</commandtext>";
                                        s = s + "<returnsdata>false</returnsdata>";

                                        s = s + "<param>";
                                        s = s + "<name>InID</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + String.valueOf(iMaxID).length() + "</size>";
                                        s = s + "<value>" + String.valueOf(iMaxID) + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InUserID</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sUserId.length() + "</size>";
                                        s = s + "<value>" + sUserId + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InName</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sName.length() + "</size>";
                                        s = s + "<value>" + sName + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InPhone</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sPhone.length() + "</size>";
                                        s = s + "<value>" + sPhone + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InMisc</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMisc.length() + "</size>";
                                        s = s + "<value>" + sMisc + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + dg.sInserted.length() + "</size>";
                                        s = s + "<value>" + dg.sInserted + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>IndeleteDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>1</size>";
                                        s = s + "<value> </value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InMapInfo</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMapInfo.length() + "</size>";
                                        s = s + "<value>" + sMapInfo + "</value>";
                                        s = s + "</param>";

                                        s = s + "</command>";
                                        Log.d("DoAutoSync", "Local to Main Insert s = " + s);

                                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                            @Override
                                            public void getResult(String result) {
                                                if (!result.isEmpty()) {
                                                    //could not find the record to update
                                                    z = z + "\r\n" + "Local to Main Failed to insert in Main for Name = " + dg.string;
                                                    Log.d("DoAutoSync", "Local to Main Failed to insert in Main for Name = " + dg.string + ", result = " + result);

                                                } else {
                                                    //need to update the MainDBId in the local record to match the main
                                                    z = z + "\r\n" + "Local to Main Inserted Name = " + dg.string;
                                                    groupsTemp = dbHandler.findAllDisplayByID(dg.id);
                                                    if (groupsTemp.size() > 0) {
                                                        //ok to update the delete date
                                                        Boolean bOK = dbHandler.updateDisplayMainDBId(String.valueOf(groupsTemp.valueAt(0).id) , String.valueOf(iMaxID) );
                                                        if (bOK == false) {
                                                            z = z + "\r\n" + "Local to Main Failed to Update MainDBID for Name = " + dg.string;
                                                            Log.d("DoAutoSync", "Local to Main Failed to Update MainDBID for Name = " + dg.string);
                                                        }
                                                        if (sFinalLastInserted.equals("")) {
                                                            sFinalLastInserted = dg.sInserted;
                                                        } else {
                                                            if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                                sFinalLastInserted = dg.sInserted;
                                                            }
                                                        }
                                                    } else {
                                                        //could not find the record to update
                                                        z = z + "\r\n" + "Local to Main Cannot Update MainDBID for Name = " + dg.string;
                                                        Log.d("DoAutoSync", "Local to Main Cannot Update MainDBID for Name = " + dg.string);
                                                    }
                                                }
                                            }
                                        });

                                    } else if (dg.sStatus.equals("InsertedUser")) {
                                        Log.d("DoAutoSync", "Local to Main To Insert UserName = " + dg.string + ", dg. = " + String.valueOf(dg.userid));
                                        //need to insert user in main
                                        String sNewUserUserid = String.valueOf(dg.userid); //temporary new userid

                                        Userid us = dbHandler.findUserid(dg.string);

                                        if (us.getSpecial()) {
                                            dg.mapinfo = "1";
                                        } else {
                                            dg.mapinfo = "0";
                                        }

                                        iMaxUserID++;

                                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "AddUserWithIdentity";
                                        s = s + "</commandtext>";
                                        s = s + "<returnsvalues>False</returnsvalues>"; //will return the new userid

                                        s = s + "<param>";
                                        s = s + "<name>InUserID</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + String.valueOf(iMaxUserID).length() + "</size>";
                                        s = s + "<value>" + String.valueOf(iMaxUserID) + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InName</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + dg.string.length() + "</size>";
                                        s = s + "<value>" + dg.string.toUpperCase() + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InBrowsePwd</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + dg.phone.length() + "</size>";
                                        s = s + "<value>" + dg.phone + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InUpdatePwd</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + dg.misc.length() + "</size>";
                                        s = s + "<value>" + dg.misc + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InSpecial</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + dg.mapinfo.length() + "</size>";
                                        s = s + "<value>" + dg.mapinfo + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InInsertDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + dg.sInserted.length() + "</size>";
                                        s = s + "<value>" + dg.sInserted + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InDeleteDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>1</size>";
                                        s = s + "<value> </value>";
                                        s = s + "</param>";


                                        s = s + "</command>";
                                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                                        {
                                            @Override
                                            public void getResult(String result)
                                            {
                                                if (!result.isEmpty())
                                                {
                                                    bAddUserError = true;
                                                    //could not find the record to update
                                                    z = z + "\r\n" + "Local to Main Failed to insert in Main for UserName = " + dg.string;
                                                    Log.d("DoAutoSync", "Local to Main Failed to insert in Main for UserName = " + dg.string + ", result = " + result);
                                                } else {
                                                    sNewUserid.append(sNewUserid.size(), String.valueOf(iMaxUserID));
                                                    sOldUserid.append(sOldUserid.size(), String.valueOf(dg.userid));
                                                }
                                            }
                                        });
                                        if (!bAddUserError) {
                                            //need to update the MainDBId in the local record to match the main
                                            z = z + "\r\n" + "Local to Main Inserted UserName = " + dg.string;
                                            groupsTemp = dbHandler.findAllUsersByID(dg.userid);
                                            if (groupsTemp.size() > 0) {
                                                //ok to update the delete date
                                                Boolean bOK = dbHandler.updateUserIdMainDBId(String.valueOf(groupsTemp.valueAt(0).id) , String.valueOf(iMaxUserID) );
                                                if (bOK == false) {
                                                    z = z + "\r\n" + "Local to Main Failed to Update MainDBID for UserName = " + dg.string;
                                                    Log.d("DoAutoSync", "Local to Main Failed to Update MainDBID for UserName = " + dg.string);
                                                }
                                                if (sFinalLastInserted.equals("")) {
                                                    sFinalLastInserted = dg.sInserted;
                                                } else {
                                                    if (dg.sInserted.compareTo(sFinalLastInserted) > 0) {
                                                        sFinalLastInserted = dg.sInserted;
                                                    }
                                                }
                                            } else {
                                                //could not find the record to update
                                                z = z + "\r\n" + "Local to Main Cannot Update MainDBID for UserName = " + dg.string;
                                                Log.d("DoAutoSync", "Local to Main Cannot Update MainDBID for UserName = " + dg.string);
                                            }
                                        }
                                        s = "";
                                    } else if (dg.sStatus.equals("Deleted")) {
                                        Log.d("DoAutoSync", "Local to Main To Delete Name = " + dg.string + ", dg.iMainDBId = " + String.valueOf(dg.iMainDBId));
                                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "UpdateDeleteDate '" + String.valueOf(dg.iMainDBId)  + "', '" + dg.sDeleted + "'";
                                        s = s + "</commandtext>";
                                        s = s + "<returnsdata>false</returnsdata>";
                                        s = s + "</command>";

                                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>() {
                                            @Override
                                            public void getResult(String result) {
                                                if (!result.isEmpty()) {
                                                    z = z + "\r\n" + "Local to Main Delete Failed for Name = " + dg.string;
                                                    Log.d("DoAutoSync", "Local to Main Delete Failed for Name = " + dg.string + " -- result = " + result);
                                                }
                                                else {
                                                    z = z + "\r\n" + "Local to Main Deleted Name = " + dg.string;
                                                    Log.d("DoAutoSync", "Local to Main Deleted Name = " + dg.string);
                                                }
                                                if (sFinalLastDeleted.equals("")) {
                                                    sFinalLastDeleted = dg.sDeleted;
                                                } else {
                                                    if (dg.sDeleted.compareTo(sFinalLastDeleted) > 0) {
                                                        sFinalLastDeleted = dg.sDeleted;
                                                    }
                                                }
                                            }
                                        });
                                    }
                                }
                            }

                            //need to update the last inserted and deleted dates in UpdateStatus
                            if (sFinalLastDeleted.equals("")) {
                                sFinalLastDeleted = usMain.getLastDeleted();
                            } else {
                                if (usMain.getLastDeleted().compareTo(sFinalLastDeleted) > 0) {
                                    sFinalLastDeleted = usMain.getLastDeleted();
                                }
                            }
                            if (sFinalLastInserted.equals("")) {
                                sFinalLastInserted = usMain.getLastInserted();
                            } else {
                                if (usMain.getLastInserted().compareTo(sFinalLastInserted) > 0) {
                                    sFinalLastInserted = usMain.getLastInserted();
                                }
                            }
                            Boolean bOK = dbHandler.updateStatus(sFinalLastInserted , sFinalLastDeleted);

                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                            s = s + "<command><commandtext>";
                            s = s + "UpdateDeleteStatus '" + sFinalLastDeleted + "'";
                            s = s + "</commandtext>";
                            s = s + "<returnsdata>false</returnsdata>";
                            s = s + "</command>";

                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                            {
                                @Override
                                public void getResult(String result)
                                {
                                    if (!result.isEmpty())
                                    {
                                        //do what you need with the result...
                                        //                                Log.d("Response", result);

                                    } else {
                                        Log.d("DoAutoSync", "Last deleted set to " + sFinalLastDeleted);
                                    }
                                }
                            });

                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                            s = s + "<command><commandtext>";
                            s = s + "UpdateInsertStatus '" + sFinalLastInserted + "'";
                            s = s + "</commandtext>";
                            s = s + "<returnsdata>false</returnsdata>";
                            s = s + "</command>";

                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                            {
                                @Override
                                public void getResult(String result)
                                {
                                    if (!result.isEmpty())
                                    {
                                        //do what you need with the result...
                                        //                                Log.d("Response", result);

                                    } else {
                                        Log.d("DoAutoSync", "Last inserted set to " + sFinalLastInserted);
                                    }
                                }
                            });

                        }


                    } else {
                        z = "Cannot auto sync";
                    }
                    //done to here

                    isSuccess = true;

                }

            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = z + "\r\nExceptions - " + ex.getMessage();
                Log.d("DoAutoSync", "Exceptions = " + z + " -- " + ex.getMessage());
            }
            return z;
        }
    }

    public class DoSync extends AsyncTask<String,String,String>
    {
        String z = "";
        Boolean isSuccess = false;
        String sID = "";
        boolean bContinue = false;
        boolean bDoAdd = false;
        TimeUtil tu = new TimeUtil();
        int idx = 0;
        String sNewUserUserid = "";
        SparseArray <String> sNewUserid = new SparseArray<String>();
        SparseArray <String> sOldUserid = new SparseArray<String>();
        boolean bAddUserError = false;
        String sAddUserError = "";

        @Override
        protected void onPreExecute() {
//            pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
//            pbbar.setVisibility(View.GONE);
            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();

            if(isSuccess) {
                DoLoad doLoad = new DoLoad();
                doLoad.execute("");
            }

        }

        @Override
        protected String doInBackground(String... params) {
            MyDBHandler dbHandler = null;
            int iUpdateCount = 0;
            String s = "";
            String sID = "";
            String sInsertDate = "";
            String sUserID = "";
            String sName = "";
            String sPhone = "";
            String sMisc = "";
            String sMapInfo = "";
            String sStoredProcName = "";
            try {
                for (idx = 0; idx < MainActivity.this.groupsNeedSync.size(); idx++)
                {
                    s = "";

                    sAddUserError = "Add User Error";
                    if (MainActivity.this.groupsNeedSync.get(idx).sStatus.equals("InsertedUser"))
                    {
                        sNewUserUserid = String.valueOf(MainActivity.this.groupsNeedSync.get(idx).userid); //temporary new userid
                        sName = MainActivity.this.groupsNeedSync.get(idx).string; //this is the user name

                        dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
                        Userid us = dbHandler.findUserid(sName);

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "AddUser";
                        s = s + "</commandtext>";
                        s = s + "<returnsvalues>False</returnsvalues>"; //will return the new userid

                        s = s + "<param>";
                        s = s + "<name>InName</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sName.length() + "</size>";
                        s = s + "<value>" + sName.toUpperCase() + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InBrowsePwd</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + us.getUserBrowsePwd().length() + "</size>";
                        s = s + "<value>" + us.getUserBrowsePwd() + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InUpdatePwd</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + us.getUserUpdatePwd().length() + "</size>";
                        s = s + "<value>" + us.getUserUpdatePwd() + "</value>";
                        s = s + "</param>";

                        s = s + "</command>";
                        bAddUserError = false;
                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    sAddUserError = "Add User Error -- " + result;
                                    bAddUserError = true;
                                }
                            }
                        });
                        if (!bAddUserError)
                        {
                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                            s = s + "<command><commandtext>";
                            s = s + "GetUserIDUsingUsername '" + sName + "'";
                            s = s + "</commandtext>";
                            s = s + "<returnsdata>true</returnsdata>";
                            s = s + "</command>";

                            NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                            {
                                @Override
                                public void getResult(String result)
                                {
                                    String sRecords[];
                                    String sFields[];
                                    String sField[];
                                    String sUserId = "";
                                    String sUserName = "";
                                    String sUserBrowsePwd = "";
                                    String sUserUpdatePwd = "";
                                    String sValue = "";
                                    if (!result.isEmpty())
                                    {
                                        //do what you need with the result...
//                                Log.d("Response", result);
                                        int idx = 0;
                                        int idxRecords = 0;
                                        sRecords = result.split(">>");
                                        for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                        {
                                            sFields = sRecords[idxRecords].split("<<");
                                            for (idx = 0; idx < sFields.length; idx++)
                                            {
                                                sField = sFields[idx].split(Pattern.quote("||"));
                                                if (sField.length > 1)
                                                {
                                                    sValue = sField[1];
                                                }
                                                else
                                                {
                                                    sValue = "";
                                                }
                                                switch (sField[0].toUpperCase())
                                                {
                                                    case "USERID":
                                                    {
                                                        sNewUserid.append(sNewUserid.size(), sValue);
                                                        sOldUserid.append(sOldUserid.size(), sNewUserUserid);
                                                        break;
                                                    }
                                                }
                                            }
                                        }

                                    }
                                }
                            });
                        }
                        s = "";
                    }
                    else if (MainActivity.this.groupsNeedSync.get(idx).sStatus.equals("UpdatedUser"))
                    {
                        sNewUserUserid = String.valueOf(MainActivity.this.groupsNeedSync.get(idx).userid); //temporary new userid
                        sName = MainActivity.this.groupsNeedSync.get(idx).string; //this is the user name

                        dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
                        Userid us = dbHandler.findUserid(sName);

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "UpdateUser";
                        s = s + "</commandtext>";
                        s = s + "<returnsvalues>False</returnsvalues>"; //will return the new userid

                        s = s + "<param>";
                        s = s + "<name>InID</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sNewUserUserid.length() + "</size>";
                        s = s + "<value>" + sNewUserUserid + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InName</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sName.length() + "</size>";
                        s = s + "<value>" + sName.toUpperCase() + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InBrowsePwd</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + us.getUserBrowsePwd().length() + "</size>";
                        s = s + "<value>" + us.getUserBrowsePwd() + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InUpdatePwd</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + us.getUserUpdatePwd().length() + "</size>";
                        s = s + "<value>" + us.getUserUpdatePwd() + "</value>";
                        s = s + "</param>";

                        s = s + "</command>";
                        bAddUserError = false;
                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    sAddUserError = "Update User Error -- " + result;
                                    bAddUserError = true;
                                }
                            }
                        });
                        s = "";
                    }
                    else if (MainActivity.this.groupsNeedSync.get(idx).sStatus.equals("Inserted"))
                    {
                        sInsertDate = tu.CurrentUTCDateTime();
                        sUserID = String.valueOf(MainActivity.this.groupsNeedSync.get(idx).userid);
                        if (sNewUserid.size() > 0)
                        {
                            for (int idxUsers = 0; idxUsers < sNewUserid.size(); idxUsers++)
                            {
                                if (sUserID.equals(sOldUserid.get(idxUsers)))
                                {
                                    sUserID = sNewUserid.get(idxUsers);
                                }
                            }
                        }
                        sName = MainActivity.this.groupsNeedSync.get(idx).string.replace("\r\n", "xxbrxx");
                        sName = Replace_XMLChar(sName);

                        sPhone = MainActivity.this.groupsNeedSync.get(idx).phone.replace("\r\n", "xxbrxx");
                        sPhone = Replace_XMLChar(sPhone);
                        if (sPhone.length() == 0)
                        {
                            sPhone = " ";
                        }

                        sMisc = MainActivity.this.groupsNeedSync.get(idx).misc.replace("\r\n", "xxbrxx");
                        sMisc = Replace_XMLChar(sMisc);
                        if (sMisc.length() == 0)
                        {
                            sMisc = " ";
                        }

                        sMapInfo = MainActivity.this.groupsNeedSync.get(idx).mapinfo.replace("\r\n", "xxbrxx");
                        sMapInfo = Replace_XMLChar(sMapInfo);
                        if (sMapInfo.length() == 0)
                        {
                            sMapInfo = " ";
                        }

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "AddToDisplay";
                        s = s + "</commandtext>";
                        s = s + "<returnsvalues>False</returnsvalues>";

                        s = s + "<param>";
                        s = s + "<name>InUserID</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sUserID.length() + "</size>";
                        s = s + "<value>" + sUserID + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InName</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sName.length() + "</size>";
                        s = s + "<value>" + sName + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InPhone</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sPhone.length() + "</size>";
                        s = s + "<value>" + sPhone + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InMisc</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sMisc.length() + "</size>";
                        s = s + "<value>" + sMisc + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InDate</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sInsertDate.length() + "</size>";
                        s = s + "<value>" + sInsertDate + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InMapInfo</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sMapInfo.length() + "</size>";
                        s = s + "<value>" + sMapInfo + "</value>";
                        s = s + "</param>";

                        s = s + "</command>";
                    }
                    else if (MainActivity.this.groupsNeedSync.get(idx).sStatus.equals("Deleted"))
                    {

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "GetNameByID '" + String.valueOf(MainActivity.this.groupsNeedSync.get(idx).iMainDBId) + "'";
                        s = s + "</commandtext>";
                        s = s + "<returnsdata>true</returnsdata>";
                        s = s + "</command>";

                        bContinue = false;
                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    bContinue = true;
                                }
                            }
                        });
                        if (bContinue)
                        {
                            sInsertDate = tu.CurrentUTCDateTime();
                            sID = String.valueOf(MainActivity.this.groupsNeedSync.get(idx).iMainDBId);
                            s = "<?xml version=\"1.0\"?>" + "\r\n";
                            s = s + "<command><commandtext>";
                            s = s + "DeleteFromDisplay";
                            s = s + "</commandtext>";
                            s = s + "<returnsvalues>False</returnsvalues>";

                            s = s + "<param>";
                            s = s + "<name>InID</name>";
                            s = s + "<type>130</type>";
                            s = s + "<direction>1</direction>";
                            s = s + "<size>" + sID.length() + "</size>";
                            s = s + "<value>" + sID + "</value>";
                            s = s + "</param>";

                            s = s + "<param>";
                            s = s + "<name>InDate</name>";
                            s = s + "<type>130</type>";
                            s = s + "<direction>1</direction>";
                            s = s + "<size>" + sInsertDate.length() + "</size>";
                            s = s + "<value>" + sInsertDate + "</value>";
                            s = s + "</param>";

                            s = s + "</command>";

                        }

                    }
                    else if (MainActivity.this.groupsNeedSync.get(idx).sStatus.equals("Updated"))
                    {
                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "GetNameByIDAndDate '" + String.valueOf(MainActivity.this.groupsNeedSync.get(idx).iMainDBId) + "', '"
                                                       + MainActivity.this.groupsNeedSync.get(idx).sInserted + "'";
                        s = s + "</commandtext>";
                        s = s + "<returnsdata>true</returnsdata>";
                        s = s + "</command>";

                        bDoAdd = false;
                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (result.isEmpty())
                                {
                                    bDoAdd = false;
                                }
                            }
                        });
                        if (bDoAdd)
                        {
                            sStoredProcName = "AddToDisplay";
                        }
                        else
                        {
                            sStoredProcName = "ModifyDisplay";
                        }

                        sInsertDate = tu.CurrentUTCDateTime();
                        sID = String.valueOf(MainActivity.this.groupsNeedSync.get(idx).iMainDBId);
                        sUserID = String.valueOf(MainActivity.this.groupsNeedSync.get(idx).userid);
                        sName = MainActivity.this.groupsNeedSync.get(idx).string.replace("\r\n", "xxbrxx");
                        sName = Replace_XMLChar(sName);

                        sPhone = MainActivity.this.groupsNeedSync.get(idx).phone.replace("\r\n", "xxbrxx");
                        sPhone = Replace_XMLChar(sPhone);
                        if (sPhone.length() == 0)
                        {
                            sPhone = " ";
                        }

                        sMisc = MainActivity.this.groupsNeedSync.get(idx).misc.replace("\r\n", "xxbrxx");
                        sMisc = Replace_XMLChar(sMisc);
                        if (sMisc.length() == 0)
                        {
                            sMisc = " ";
                        }

                        sMapInfo = MainActivity.this.groupsNeedSync.get(idx).mapinfo.replace("\r\n", "xxbrxx");
                        sMapInfo = Replace_XMLChar(sMapInfo);
                        if (sMapInfo.length() == 0)
                        {
                            sMapInfo = " ";
                        }

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + sStoredProcName;
                        s = s + "</commandtext>";
                        s = s + "<returnsvalues>False</returnsvalues>";

                        if (bDoAdd)
                        {
                            s = s + "<param>";
                            s = s + "<name>InUserID</name>";
                            s = s + "<type>130</type>";
                            s = s + "<direction>1</direction>";
                            s = s + "<size>" + sUserID.length() + "</size>";
                            s = s + "<value>" + sUserID + "</value>";
                            s = s + "</param>";
                        }
                        else
                        {
                            s = s + "<param>";
                            s = s + "<name>InID</name>";
                            s = s + "<type>130</type>";
                            s = s + "<direction>1</direction>";
                            s = s + "<size>" + sID.length() + "</size>";
                            s = s + "<value>" + sID + "</value>";
                            s = s + "</param>";
                        }
                        s = s + "<param>";
                        s = s + "<name>InName</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sName.length() + "</size>";
                        s = s + "<value>" + sName + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InPhone</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sPhone.length() + "</size>";
                        s = s + "<value>" + sPhone + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InMisc</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sMisc.length() + "</size>";
                        s = s + "<value>" + sMisc + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InDate</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sInsertDate.length() + "</size>";
                        s = s + "<value>" + sInsertDate + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InMapInfo</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sMapInfo.length() + "</size>";
                        s = s + "<value>" + sMapInfo + "</value>";
                        s = s + "</param>";

                        s = s + "</command>";

                    }
                    if (!s.equals(""))
                    {
                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                z = result;
                            }
                        });
                        iUpdateCount++;
                    }
                    if (bAddUserError)
                    {
                        z = sAddUserError;
                        break;
                    }
                }
                if (!bAddUserError)
                {
                    if (z.equals(""))
                    {
                        z = String.valueOf(iUpdateCount) + " records synced. Starting DB Reload.";
                    }
                    else
                    {
                        z = z + ", " + String.valueOf(iUpdateCount) + " records synced. Starting DB Reload.";
                    }
                    isSuccess = true;
                }
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }

    public class DoCopyDBToAlt extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private String sMaxID = "";
        private int iID = 0;
        private int iTotalRecords = 0;
        private int iTotalUserRecords = 0;
        private int iTotalErrors = 0;
        private String sLastInserted = "";
        private String sLastDeleted = "";

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
//            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();
            NotificationUtils.GenerateNotification("Copy DB to Alt Finished", r,
                    1, null, false, MainActivity.this,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);

            if(isSuccess)
            {
                //UpdateLastLogin("-1", false);
                //MainActivity.this.clearList();


//                if (MainActivity.this.msLastSearchType.equals("1"))
//                {
//                    MainActivity.this.doFind();
//                }
//                else if (MainActivity.this.msLastSearchType.equals("2"))
//                {
//                    MainActivity.this.doFindSpecial();
//                }
            }

        }

        @Override
        protected String doInBackground(String... params) {
            try
            {

                iTotalRecords = 0;
                iTotalUserRecords = 0;

                //clear all tables in the alt db
                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "TruncateAllTables";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUpdateStatus";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            sFields = result.split("<<");
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "LASTINSERTED":
                                        {
                                            sLastInserted = sValue;
                                            break;
                                        }
                                        case "LASTDELETED":
                                        {
                                            sLastDeleted = sValue;
                                            break;
                                        }
                                    }
                                }
                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "UpdateInsertStatus '" + sLastInserted + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                Log.d("DoCopyDBToAlt", "Last inserted = " + sLastInserted);
                                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        Log.d("DoCopyDBToAlt", "Finished UpdateStatusLastInserted");
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                        }
                                    }
                                });
                                s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "UpdateDeleteStatus '" + sLastDeleted + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                Log.d("DoCopyDBToAlt", "Last deleted = " + sLastDeleted);
                                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        Log.d("DoCopyDBToAlt", "Finished UpdateStatusLastDeleted");
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                        }
                                    }
                                });
                            }

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUsers";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserId = "";
                        String sUserName = "";
                        String sUserBrowsePwd = "";
                        String sUserUpdatePwd = "";
                        String sValue = "";
                        String sSpecial = "";
                        String sInserted = "";
                        String sDeleted = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalUserRecords++;
                                sFields = sRecords[idxRecords].split("<<");
                                sSpecial = "";
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserId = sValue;
                                            break;
                                        }
                                        case "USERNAME":
                                        {
                                            sUserName = sValue;
                                            break;
                                        }
                                        case "USERBROWSEPWD":
                                        {
                                            sUserBrowsePwd = sValue;
                                            break;
                                        }
                                        case "USERUPDATEPWD":
                                        {
                                            sUserUpdatePwd = sValue;
                                            break;
                                        }
                                        case "SPECIAL":
                                        {
                                            sSpecial = sValue;
                                            break;
                                        }
                                        case "INSERTED":
                                        {
                                            sInserted = sValue;
                                            break;
                                        }
                                        case "DELETED":
                                        {
                                            sDeleted = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddUserWithIdentity '" + sUserId + "', '" + sUserName.toUpperCase() + "', '" + sUserBrowsePwd
                                        + "', '" + sUserUpdatePwd + "', '" + sSpecial
                                        + "', '" + sInserted + "', '" + sDeleted + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                        }
                                    }
                                });
                            }

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetLastIDFromDisplayAbsolute";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sFields[];
                        String sField[];
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                            Log.d("Response", result);
                            sFields = result.split("<<");
                            sField = sFields[0].split(Pattern.quote("||"));
                            sMaxID = sField[1];
                        }
                    }
                });

                if (!sMaxID.equals(""))
                {
                    while (iID < Integer.parseInt(sMaxID))
                    {
                        progressStatus = Integer.parseInt( Long.toString( Math.round((Float.parseFloat(String.valueOf(iID)) / Float.parseFloat(sMaxID)) * 100.0 )));
                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "Get10NamesByID '" + String.valueOf(iID) + "'";
                        s = s + "</commandtext>";
                        s = s + "<returnsdata>true</returnsdata>";
                        s = s + "</command>";

                        NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    String sRecords[];
                                    String sFields[];
                                    String sField[];
                                    String sName = "";
                                    String sPhone = "";
                                    String sMisc = "";
                                    String sID = "";
                                    String sUserID = "";
                                    String sMapInfo = "";
                                    String sInserted = "";
                                    String sDeleted = "";
                                    String sValue = "";
                                    int idx = 0;
                                    int idxRecords = 0;
                                    sRecords = result.split(">>");
                                    for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                    {
                                        sName = "";
                                        sPhone = "";
                                        sMisc = "";
                                        sID = "";
                                        sUserID = "";
                                        sMapInfo = "";
                                        sInserted = "";
                                        sDeleted = "";
                                        sValue = "";

                                        sFields = sRecords[idxRecords].split("<<");
                                        for (idx = 0; idx < sFields.length; idx++)
                                        {
                                            sField = sFields[idx].split(Pattern.quote("||"));
                                            if (sField.length > 1)
                                            {
                                                sValue = sField[1];
                                            }
                                            else
                                            {
                                                sValue = "";
                                            }
                                            switch (sField[0].toUpperCase())
                                            {
                                                case "ID":
                                                {
                                                    sID = sValue;
                                                    iID = Integer.parseInt(sID);
                                                    break;
                                                }
                                                case "USERID":
                                                {
                                                    sUserID = sValue;
                                                    break;
                                                }
                                                case "NAME":
                                                {
                                                    sName = sValue.replace("xxbrxx", "\r\n");
                                                    sName = sName.replace("<br>", "\r\n");
                                                    sName = sName.replace(gsCodeOutLt, "<");
                                                    sName = sName.replace(gsCodeOutGt, ">");
                                                    sName = sName.replace(gsCodeOutBar, "|");
                                                    sName = sName.replace(gsCodeOutAmpersand, "&");
                                                    sName = sName.replace(gsCodeOutApos, "'");
                                                    sName = sName.replace(gsCodeOutPercent, "%");
                                                    sName = sName.replace(gsCodeOutQuote, "\"");
                                                    break;
                                                }
                                                case "PHONE":
                                                {
                                                    sPhone = sValue.replace("xxbrxx", "\r\n");
                                                    sPhone = sPhone.replace("<br>", "\r\n");
                                                    sPhone = sPhone.replace(gsCodeOutLt, "<");
                                                    sPhone = sPhone.replace(gsCodeOutGt, ">");
                                                    sPhone = sPhone.replace(gsCodeOutBar, "|");
                                                    sPhone = sPhone.replace(gsCodeOutAmpersand, "&");
                                                    sPhone = sPhone.replace(gsCodeOutApos, "'");
                                                    sPhone = sPhone.replace(gsCodeOutPercent, "%");
                                                    sPhone = sPhone.replace(gsCodeOutQuote, "\"");
                                                    break;
                                                }
                                                case "MISC":
                                                {
                                                    sMisc = sValue.replace("xxbrxx", "\r\n");
                                                    sMisc = sMisc.replace("<br>", "\r\n");
                                                    sMisc = sMisc.replace(gsCodeOutLt, "<");
                                                    sMisc = sMisc.replace(gsCodeOutGt, ">");
                                                    sMisc = sMisc.replace(gsCodeOutBar, "|");
                                                    sMisc = sMisc.replace(gsCodeOutAmpersand, "&");
                                                    sMisc = sMisc.replace(gsCodeOutApos, "'");
                                                    sMisc = sMisc.replace(gsCodeOutPercent, "%");
                                                    sMisc = sMisc.replace(gsCodeOutQuote, "\"");
                                                    sMisc = sMisc.trim();
                                                    break;
                                                }
                                                case "MAPINFO":
                                                {
                                                    sMapInfo = sValue.replace("xxbrxx", "\r\n");
                                                    sMapInfo = sMapInfo.replace("<br>", "\r\n");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutLt, "<");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutGt, ">");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutBar, "|");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutAmpersand, "&");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutApos, "'");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutPercent, "%");
                                                    sMapInfo = sMapInfo.replace(gsCodeOutQuote, "\"");
                                                    sMapInfo = sMapInfo.trim();
                                                    break;
                                                }
                                                case "INSERTED":
                                                {
                                                    sInserted = sValue;
                                                    break;
                                                }
                                                case "DELETED":
                                                {
                                                    sDeleted = sValue;
                                                    break;
                                                }
                                            }
                                        }

                                        sName = sName.replace("\r\n", "xxbrxx");
                                        sName = Replace_XMLChar(sName);

                                        sPhone = sPhone.replace("\r\n", "xxbrxx");
                                        sPhone = Replace_XMLChar(sPhone);
                                        if (sPhone.length() == 0)
                                        {
                                            sPhone = " ";
                                        }

                                        sMisc = sMisc.replace("\r\n", "xxbrxx");
                                        sMisc = Replace_XMLChar(sMisc);
                                        sMisc = sMisc.trim();
                                        if (sMisc.length() == 0)
                                        {
                                            sMisc = " ";
                                        }

                                        sMapInfo = sMapInfo.replace("\r\n", "xxbrxx");
                                        sMapInfo = Replace_XMLChar(sMapInfo);
                                        sMapInfo = sMapInfo.trim();
                                        if (sMapInfo.length() == 0)
                                        {
                                            sMapInfo = " ";
                                        }

                                        if (sDeleted.equals("")) {
                                            sDeleted = " ";
                                        } else {
                                            Log.d("DoCopyDBToAlt", "sDeleted = " + sDeleted);
                                        }

                                        String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "AddToDisplayWithIdentity";

                                        /*
                                        s = s + " '" + sID + "'";
                                        s = s + ", '" + sUserID + "'";
                                        s = s + ", '" + sName + "'";
                                        s = s + ", '" + sPhone + "'";
                                        s = s + ", '" + sMisc + "'";
                                        s = s + ", '" + sInserted + "'";
                                        s = s + ", '" + sMapInfo + "'";
                                        */

                                        s = s + "</commandtext>";
                                        s = s + "<returnsdata>false</returnsdata>";

                                        s = s + "<param>";
                                        s = s + "<name>InID</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sID.length() + "</size>";
                                        s = s + "<value>" + sID + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InUserID</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sUserID.length() + "</size>";
                                        s = s + "<value>" + sUserID + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InName</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sName.length() + "</size>";
                                        s = s + "<value>" + sName + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InPhone</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sPhone.length() + "</size>";
                                        s = s + "<value>" + sPhone + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InMisc</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMisc.length() + "</size>";
                                        s = s + "<value>" + sMisc + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InInsertDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sInserted.length() + "</size>";
                                        s = s + "<value>" + sInserted + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>IndeleteDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sDeleted.length() + "</size>";
                                        s = s + "<value>" + sDeleted + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InMapInfo</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMapInfo.length() + "</size>";
                                        s = s + "<value>" + sMapInfo + "</value>";
                                        s = s + "</param>";

                                        s = s + "</command>";

                                        NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                                        {
                                            @Override
                                            public void getResult(String result)
                                            {
                                                if (!result.isEmpty())
                                                {
                                                    iTotalErrors++;
                                                    //do what you need with the result...
                                                    //                                Log.d("Response", result);

                                                }
                                            }
                                        });
                                        iTotalRecords++;
                                    }
                                }
                            }
                        });
                    }



                    z = "Successfully copied " + String.valueOf(iTotalRecords) + " data records and " + String.valueOf(iTotalUserRecords) + " user records with " + String.valueOf(iTotalErrors) + " errors.";
                }
                else
                {
                    z = "No records found to copy.";
                }
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }

    public class DoCopyLocalDBToAlt extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private int iTotalErrors = 0;

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
//            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();
            NotificationUtils.GenerateNotification("Copy Local DB to Alt Finished", r,
                    1, null, false, MainActivity.this,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);

//            if(isSuccess)
//            {
//            }

        }

        @Override
        protected String doInBackground(String... params) {
            final MyDBHandler dbHandler = new MyDBHandler(MainActivity.this, null, null, 1);
            try
            {

                int iTotalRecords = 0;
                int iTotalUserRecords = 0;

                //clear all tables in the alt db
                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "TruncateAllTables";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);

                        }
                    }
                });

                //copy UpdateStatus table
                UpdateStatus us = dbHandler.findUpdateStatus();
                String sLastDeleted = us.getLastDeleted();
                String sLastInserted = us.getLastInserted();

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "UpdateInsertStatus '" + sLastInserted + "'";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                Log.d("DoLocalCopyDBToAlt", "Last inserted = " + sLastInserted);
                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        Log.d("DoLocalCopyDBToAlt", "Finished UpdateStatusLastInserted");
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
                            //                                Log.d("Response", result);

                        }
                    }
                });
                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "UpdateDeleteStatus '" + sLastDeleted + "'";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                Log.d("DoLocalCopyDBToAlt", "Last deleted = " + sLastDeleted);
                NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        Log.d("DoLocalCopyDBToAlt", "Finished UpdateStatusLastDeleted");
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
                            //                                Log.d("Response", result);

                        }
                    }
                });
                //now set the ORIGLASTINSERTED and ORIGLASTDELETED in the local db
                dbHandler.updateStatus(sLastInserted, sLastDeleted);

                //copy UserId table
                SparseArray<Userid> Users = dbHandler.findAllUsers();

                String sUserId = "";
                String sOrigUserId = "";
                String sUserName = "";
                String sUserBrowsePwd = "";
                String sUserUpdatePwd = "";
                String sSpecial = "";
                String sInserted = "";
                String sDeleted = "";

                if (Users.size() > 0) {
                    for (int idx = 0; idx < Users.size(); idx++) {
                        Userid uid = Users.valueAt(idx);
                        sUserId = String.valueOf (uid.getUserId());
                        sUserName = uid.getUserName();
                        sUserBrowsePwd = uid.getUserBrowsePwd();
                        sUserUpdatePwd = uid.getUserUpdatePwd();
                        if (uid.getSpecial()) {
                            sSpecial = "1";
                        } else {
                            sSpecial = "0";
                        }
                        sInserted = uid.getUserInserted();
                        sDeleted = uid.getUserDeleted();

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "AddUserWithIdentity '" + sUserId + "', '" + sUserName.toUpperCase() + "', '" + sUserBrowsePwd
                                + "', '" + sUserUpdatePwd + "', '" + sSpecial
                                + "', '" + sInserted + "', '" + sDeleted + "'";
                        s = s + "</commandtext>";
                        s = s + "<returnsdata>false</returnsdata>";
                        s = s + "</command>";

                        NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    //do what you need with the result...
                                    //                                Log.d("Response", result);

                                }
                            }
                        });
                        iTotalUserRecords++;
                    }
                    //update OrigUserId if it is currently -1
                    for (int idx = 0; idx < Users.size(); idx++) {
                        Userid uid = Users.valueAt(idx);
                        sUserId = String.valueOf(uid.getUserId());
                        dbHandler.updateUserIdMainDBId(sUserId,sUserId);
                    }
                }

                //copy Display table
                SparseArray<Display> DispRecs = dbHandler.findAllDisplayRecords();
                if (DispRecs.size() > 0) {
                    for (int idxRec = 0; idxRec < DispRecs.size(); idxRec++) {
                        progressStatus = Integer.parseInt( Long.toString( Math.round(((float) idxRec / (float) DispRecs.size()) *100)));
                        Display disp = DispRecs.valueAt(idxRec);
                        String sUserID = String.valueOf(disp.getDisplayUserId());
                        String sInsertDate = disp.getDisplayInserted();
                        String sDeleteDate = disp.getDisplayDeleted();
                        String sID = String.valueOf(disp.getId());
                        String sMainDBID = String.valueOf(disp.getDisplayMainDBId());

                        String sName = disp.getDisplayName();
                        if (sName == null) {
                            sName = "No Name";
                        } else {
                            sName = disp.getDisplayName().replace("\r\n", "xxbrxx");
                            sName = Replace_XMLChar(sName);
                        }

                        String sPhone = disp.getDisplayPhone().replace("\r\n", "xxbrxx");
                        if (sPhone == null) {
                            sPhone = " ";
                        } else {
                            sPhone = disp.getDisplayPhone().replace("\r\n", "xxbrxx");
                            sPhone = Replace_XMLChar(sPhone);
                            if (sPhone.length() == 0)
                            {
                                sPhone = " ";
                            }
                        }

                        String sMisc = disp.getDisplayMisc();
                        if (sMisc == null) {
                            sMisc = " ";
                        } else {
                            sMisc = disp.getDisplayMisc().replace("\r\n", "xxbrxx");
                            sMisc = Replace_XMLChar(sMisc);
                            if (sMisc.length() == 0)
                            {
                                sMisc = " ";
                            }
                        }

                        String sMapInfo = disp.getDisplayMapInfo();
                        if (sMapInfo == null) {
                            sMapInfo = " ";
                        } else {
                            sMapInfo = disp.getDisplayMapInfo().replace("\r\n", "xxbrxx");
                            sMapInfo = Replace_XMLChar(sMapInfo);
                            if (sMapInfo.length() == 0)
                            {
                                sMapInfo = " ";
                            }
                        }

                        if (sInsertDate == null) {
                            sInsertDate = " ";
                        } else if (sInsertDate.equals("")) {
                            sInsertDate = " ";
                        }

                        if (sDeleteDate == null) {
                            sDeleteDate = " ";
                        } else if (sDeleteDate.equals("")) {
                            sDeleteDate = " ";
                        }

                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "AddToDisplayWithIdentity";

                                        /*
                                        s = s + " '" + sID + "'";
                                        s = s + ", '" + sUserID + "'";
                                        s = s + ", '" + sName + "'";
                                        s = s + ", '" + sPhone + "'";
                                        s = s + ", '" + sMisc + "'";
                                        s = s + ", '" + sInserted + "'";
                                        s = s + ", '" + sMapInfo + "'";
                                        */

                        s = s + "</commandtext>";
                        s = s + "<returnsdata>false</returnsdata>";

                        s = s + "<param>";
                        s = s + "<name>InID</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sID.length() + "</size>";
                        s = s + "<value>" + sID + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InUserID</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sUserID.length() + "</size>";
                        s = s + "<value>" + sUserID + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InName</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sName.length() + "</size>";
                        s = s + "<value>" + sName + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InPhone</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sPhone.length() + "</size>";
                        s = s + "<value>" + sPhone + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InMisc</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sMisc.length() + "</size>";
                        s = s + "<value>" + sMisc + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InInsertDate</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sInsertDate.length() + "</size>";
                        s = s + "<value>" + sInsertDate + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>IndeleteDate</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sDeleteDate.length() + "</size>";
                        s = s + "<value>" + sDeleteDate + "</value>";
                        s = s + "</param>";

                        s = s + "<param>";
                        s = s + "<name>InMapInfo</name>";
                        s = s + "<type>130</type>";
                        s = s + "<direction>1</direction>";
                        s = s + "<size>" + sMapInfo.length() + "</size>";
                        s = s + "<value>" + sMapInfo + "</value>";
                        s = s + "</param>";

                        s = s + "</command>";

                        NetworkManagerAlt.getInstance().MyPostRequestReturningStringAlt(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    iTotalErrors++;
                                    //do what you need with the result...
                                    //                                Log.d("Response", result);

                                }
                            }
                        });
                        iTotalRecords++;
                    }
                    //now set the MainDBID to the ID in the local DB
                    for (int idxRec = 0; idxRec < DispRecs.size(); idxRec++) {
                        Display disp = DispRecs.valueAt(idxRec);
                        String sID = String.valueOf(disp.getId());
                        dbHandler.updateDisplayMainDBId(sID,sID);
                    }
                    z = "Successfully copied " + String.valueOf(iTotalRecords) + " data records and " + String.valueOf(iTotalUserRecords) + " user records with " + String.valueOf(iTotalErrors) + " errors.";
                } else {
                    z = "No records found to copy.";
                }
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }

    public class DoCopyMeditationDBToAlt extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private String sMaxID = "";
        private int iID = 0;
        private int iTotalRecords = 0;
        private int iTotalUserRecords = 0;
        private int iTotalErrors = 0;
        private String sLastInserted = "";
        private String sLastDeleted = "";
        private String [] sUserIdYear = new String[1];
        private String Tag = "DoCopyMeditationDBToAlt";

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
//            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();
            NotificationUtils.GenerateNotification("Copy Meditation to Alt Finished", r,
                    1, null, false, MainActivity.this,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);

            if(isSuccess)
            {
//                UpdateLastLogin("-1", false);
//                MainActivity.this.clearList();
            }

        }

        @Override
        protected String doInBackground(String... params) {
            try
            {

                iTotalRecords = 0;
                iTotalUserRecords = 0;

                //clear all tables in the alt db
                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "TruncateAllTables";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                NetworkManagerAltMeditation.getInstance().MyPostRequestReturningStringAltMeditation(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUpdateStatus";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerMeditation.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            sFields = result.split("<<");
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "LASTINSERTED":
                                        {
                                            sLastInserted = sValue;
                                            break;
                                        }
                                        case "LASTDELETED":
                                        {
                                            sLastDeleted = sValue;
                                            break;
                                        }
                                    }
                                }
                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "UpdateInsertStatus '" + sLastInserted + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                Log.d("Tag", "Last inserted = " + sLastInserted);
                                NetworkManagerAltMeditation.getInstance().MyPostRequestReturningStringAltMeditation(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        Log.d(Tag, "Finished UpdateStatusLastInserted");
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                        }
                                    }
                                });
                                s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "UpdateDeleteStatus '" + sLastDeleted + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                Log.d("Tag", "Last deleted = " + sLastDeleted);
                                NetworkManagerAltMeditation.getInstance().MyPostRequestReturningStringAltMeditation(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        Log.d("DoCopyDBToAlt", "Finished UpdateStatusLastDeleted");
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                        }
                                    }
                                });
                            }

                        }
                    }
                });


                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUsers";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerMeditation.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserId = "";
                        String sUserName = "";
                        String sUserBrowsePwd = "";
                        String sUserUpdatePwd = "";
                        String sValue = "";
                        String sBirthyear = "";
                        String sInserted = "";
                        String sDeleted = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalUserRecords++;
                                sFields = sRecords[idxRecords].split("<<");
                                sBirthyear = "";
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserId = sValue;
                                            break;
                                        }
                                        case "USERNAME":
                                        {
                                            sUserName = sValue;
                                            break;
                                        }
                                        case "USERBROWSEPWD":
                                        {
                                            sUserBrowsePwd = sValue;
                                            break;
                                        }
                                        case "USERUPDATEPWD":
                                        {
                                            sUserUpdatePwd = sValue;
                                            break;
                                        }
                                        case "BIRTHYEAR":
                                        {
                                            sBirthyear = sValue;
                                            break;
                                        }
                                        case "INSERTED":
                                        {
                                            sInserted = sValue;
                                            break;
                                        }
                                        case "DELETED":
                                        {
                                            sDeleted = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddUserWithIdentity '" + sUserId + "', '" + sUserName.toUpperCase() + "', '" + sUserBrowsePwd
                                        + "', '" + sUserUpdatePwd + "', '" + sBirthyear
                                        + "', '" + sInserted + "', '" + sDeleted + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltMeditation.getInstance().MyPostRequestReturningStringAltMeditation(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                        }
                                    }
                                });
                            }

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllYearsForEachUser";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerMeditation.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserID = "";
                        String sYear = "";
                        int idx = 0;
                        int idxRecords = 0;
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            sRecords = result.split(">>");

                            sUserIdYear = new String[sRecords.length];
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sUserID = "";
                                sYear = "";
                                sValue = "";
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserID = sValue;
                                            break;
                                        }
                                        case "YEAR":
                                        {
                                            sYear = sValue;
                                            break;
                                        }
                                    }
                                }
                                sUserIdYear[idxRecords] = sUserID + "," + sYear;
                            }
                        }
                    }
                });

                if (!(sUserIdYear[0] == ""))
                {
                    String sUserIDYearFields[];
                    int idx = 0;
                    int idxUserIDYearRecords = 0;
                    for (idxUserIDYearRecords = 0; idxUserIDYearRecords < sUserIdYear.length; idxUserIDYearRecords++)
                    {
                        progressStatus = Integer.parseInt( Long.toString( Math.round((Float.parseFloat(String.valueOf(idxUserIDYearRecords)) / Float.parseFloat(String.valueOf(sUserIdYear.length))) * 100.0 )));
                        sUserIDYearFields = sUserIdYear[idxUserIDYearRecords].split(Pattern.quote(",")); // sUserIdYear should contain UserID, Year
                        s = "<?xml version=\"1.0\"?>" + "\r\n";
                        s = s + "<command><commandtext>";
                        s = s + "GetAllHoursMinutesByUserIDYear '" + sUserIDYearFields[0] + "', '" + sUserIDYearFields[1] + "'";
                        s = s + "</commandtext>";
                        s = s + "<returnsdata>true</returnsdata>";
                        s = s + "</command>";

                        NetworkManagerMeditation.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                        {
                            @Override
                            public void getResult(String result)
                            {
                                if (!result.isEmpty())
                                {
                                    String sRecords[];
                                    String sFields[];
                                    String sField[];
                                    String sDateFields[];
                                    String sUserID = "";
                                    String sMeditationDate = "";
                                    String sMeditationHours = "";
                                    String sMeditationMinutes = "";
                                    String sExerciseHours = "";
                                    String sExerciseMinutes = "";
                                    String sInserted = "";
                                    String sDeleted = "";
                                    String sValue = "";
                                    int idx = 0;
                                    int idxRecords = 0;
                                    sRecords = result.split(">>");
                                    for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                                    {
                                        sUserID = "";
                                        sMeditationDate = "";
                                        sMeditationHours = "";
                                        sMeditationMinutes = "";
                                        sExerciseHours = "";
                                        sExerciseMinutes = "";
                                        sValue = "";

                                        sFields = sRecords[idxRecords].split("<<");
                                        for (idx = 0; idx < sFields.length; idx++)
                                        {
                                            sField = sFields[idx].split(Pattern.quote("||"));
                                            if (sField.length > 1)
                                            {
                                                sValue = sField[1];
                                            }
                                            else
                                            {
                                                sValue = "";
                                            }
                                            switch (sField[0].toUpperCase())
                                            {
                                                case "USERID":
                                                {
                                                    sUserID = sValue;
                                                    break;
                                                }
                                                case "MEDITATIONDATE":
                                                {
                                                    sDateFields = sValue.split(Pattern.quote("/"));
                                                    sMeditationDate = sDateFields[2] + "-" + sDateFields[0] + "-" + sDateFields[1];
                                                    break;
                                                }
                                                case "MEDITATIONHOURS":
                                                {
                                                    sMeditationHours = sValue;
                                                    break;
                                                }
                                                case "MEDITATIONMINUTES":
                                                {
                                                    sMeditationMinutes = sValue;
                                                    break;
                                                }
                                                case "EXERCISEHOURS":
                                                {
                                                    sExerciseHours = sValue;
                                                    break;
                                                }
                                                case "EXERCISEMINUTES":
                                                {
                                                    sExerciseMinutes = sValue;
                                                    break;
                                                }
                                                case "INSERTED":
                                                {
                                                    sInserted = sValue;
                                                    break;
                                                }
                                                case "DELETED":
                                                {
                                                    sDeleted = sValue;
                                                    break;
                                                }
                                            }
                                        }

                                        if (sDeleted.equals("")) {
                                            sDeleted = " ";
                                        } else {
                                            Log.d(Tag, "sDeleted = " + sDeleted);
                                        }


                                        String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                        s = s + "<command><commandtext>";
                                        s = s + "AddHoursMinutes";
                                        s = s + "</commandtext>";
                                        s = s + "<returnsdata>false</returnsdata>";

                                        s = s + "<param>";
                                        s = s + "<name>InID</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sUserID.length() + "</size>";
                                        s = s + "<value>" + sUserID + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMeditationDate.length() + "</size>";
                                        s = s + "<value>" + sMeditationDate + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InMeditationHours</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMeditationHours.length() + "</size>";
                                        s = s + "<value>" + sMeditationHours + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InMeditationMinutes</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sMeditationMinutes.length() + "</size>";
                                        s = s + "<value>" + sMeditationMinutes + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InExerciseHours</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sExerciseHours.length() + "</size>";
                                        s = s + "<value>" + sExerciseHours + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InExerciseMinutes</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sExerciseMinutes.length() + "</size>";
                                        s = s + "<value>" + sExerciseMinutes + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>InInsertDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sInserted.length() + "</size>";
                                        s = s + "<value>" + sInserted + "</value>";
                                        s = s + "</param>";

                                        s = s + "<param>";
                                        s = s + "<name>IndeleteDate</name>";
                                        s = s + "<type>130</type>";
                                        s = s + "<direction>1</direction>";
                                        s = s + "<size>" + sDeleted.length() + "</size>";
                                        s = s + "<value>" + sDeleted + "</value>";
                                        s = s + "</param>";

                                        s = s + "</command>";

                                        NetworkManagerAltMeditation.getInstance().MyPostRequestReturningStringAltMeditation(s, new MyListener<String>()
                                        {
                                            @Override
                                            public void getResult(String result)
                                            {
                                                if (!result.isEmpty())
                                                {
                                                    iTotalErrors++;
                                                    //do what you need with the result...
                                                    //                                Log.d("Response", result);

                                                }
                                            }
                                        });
                                        iTotalRecords++;
                                    }
                                }
                            }
                        });
                    }

                    z = "Successfully copied " + String.valueOf(iTotalRecords) + " data records and " + String.valueOf(iTotalUserRecords) + " user records with " + String.valueOf(iTotalErrors) + " errors.";
                }
                else
                {
                    z = "No records found to copy.";
                }
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }


    public class DoCopyMileageDBToAlt extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private int iTotalRecords = 0;
        private int iTotalUserRecords = 0;
        private int iTotalErrors = 0;
        private String [] sUserIdYear = new String[1];

        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();
            NotificationUtils.GenerateNotification("Copy Mileage to Alt Finished", r,
                    1, null, false, MainActivity.this,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);

            if(isSuccess)
            {
//                UpdateLastLogin("-1", false);
//                MainActivity.this.clearList();
            }

        }

        @Override
        protected String doInBackground(String... params) {
            try
            {

                iTotalRecords = 0;
                iTotalUserRecords = 0;

                progressStatus = 10;
                //clear all tables in the alt db
                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "TruncateAllTables";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                NetworkManagerAltMileage.getInstance().MyPostRequestReturningStringAltMileage(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);

                        }
                    }
                });

                progressStatus = 20;
                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetUsers";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerMileage.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserId = "";
                        String sUserName = "";
                        String sUserBrowsePwd = "";
                        String sUserUpdatePwd = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalUserRecords++;
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserId = sValue;
                                            break;
                                        }
                                        case "USERNAME":
                                        {
                                            sUserName = sValue;
                                            break;
                                        }
                                        case "USERBROWSEPWD":
                                        {
                                            sUserBrowsePwd = sValue;
                                            break;
                                        }
                                        case "USERUPDATEPWD":
                                        {
                                            sUserUpdatePwd = sValue;
                                            break;
                                        }
                                        case "BIRTHYEAR":
                                        {
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddUserWithIdentity '" + sUserId + "', '" + sUserName.toUpperCase() + "', '" + sUserBrowsePwd + "', '" + sUserUpdatePwd + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltMileage.getInstance().MyPostRequestReturningStringAltMileage(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            iTotalErrors++;
                                        }
                                    }
                                });
                            }

                        }
                    }
                });


                progressStatus = 40;
                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllMileageData";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerMileage.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserId = "";
                        String sStartDate = "";
                        String sStopDate = "";
                        String sStartMileage = "";
                        String sStopMileage = "";
                        String sRides = "";
                        String sEarnings = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserId = sValue;
                                            break;
                                        }
                                        case "STARTDATE":
                                        {
                                            sStartDate = sValue;

                                            SimpleDateFormat formatterIn = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
                                            SimpleDateFormat formatterOut = new SimpleDateFormat("yyyy-MM-dd HH:mm");

                                            try {

                                                Date date = formatterIn.parse(sStartDate);
                                                sStartDate = formatterOut.format(date);

                                            } catch (ParseException e) {
                                                iTotalErrors++;
                                                //e.printStackTrace();
                                            }

                                            break;
                                        }
                                        case "STOPDATE":
                                        {
                                            sStopDate = sValue;

                                            SimpleDateFormat formatterIn = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
                                            SimpleDateFormat formatterOut = new SimpleDateFormat("yyyy-MM-dd HH:mm");

                                            try {

                                                Date date = formatterIn.parse(sStopDate);
                                                sStopDate = formatterOut.format(date);

                                            } catch (ParseException e) {
                                                iTotalErrors++;
                                                //e.printStackTrace();
                                            }
                                            break;
                                        }
                                        case "STARTMILEAGE":
                                        {
                                            sStartMileage = sValue;
                                            break;
                                        }
                                        case "STOPMILEAGE":
                                        {
                                            sStopMileage = sValue;
                                            break;
                                        }
                                        case "RIDES":
                                        {
                                            sRides = sValue;
                                            break;
                                        }
                                        case "EARNINGS":
                                        {
                                            sEarnings = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddMileageData '" + sUserId
                                        + "', '" + sStartDate
                                        + "', '" + sStopDate
                                        + "', '" + sStartMileage
                                        + "', '" + sStopMileage
                                        + "', '" + sRides
                                        + "', '" + sEarnings + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltMileage.getInstance().MyPostRequestReturningStringAltMileage(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            iTotalErrors++;
                                        }
                                    }
                                });
                                iTotalRecords++;
                            }
                            z = "Successfully copied " + String.valueOf(iTotalRecords) + " data records and " + String.valueOf(iTotalUserRecords) + " user records with " + String.valueOf(iTotalErrors) + " errors.";

                        } else {
                            z = "No records found to copy.";
                        }
                    }
                });
                progressStatus = 100;
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }

    public class DoCopySuperbowlDBToAlt extends AsyncTask<String,String,String>
    {
        private String z = "";
        private Boolean isSuccess = false;
        private String sMaxID = "";
        private int iID = 0;
        private int iTotalBonus = 0;
        private int iTotalCurrentQuarter = 0;
        private int iTotalRecords = 0;
        private int iTotalScores = 0;
        private int iTotalUserRecords = 0;
        private int iTotalErrors = 0;
        private String sLastInserted = "";
        private String sLastDeleted = "";
        private String [] sUserIdYear = new String[1];
        private String Tag = "DoCopySuperbowlDBToAlt";

        private String ksRecInd = "<<>>";
        private String ksFieldInd = "<>";
        private String ksDataInd = "~";

        private boolean bCanIncrement = false;


        @Override
        protected void onPreExecute() {
            //pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
            //pbbar.setVisibility(View.GONE);
            progressStatus = 100;
            Toast.makeText(MainActivity.this,r,Toast.LENGTH_LONG).show();
            NotificationUtils.GenerateNotification("Superbowl DB to Alt Finished", r,
                    1, null, false, MainActivity.this,
                    notificationManager, NotificationCompat.PRIORITY_HIGH);

            if(isSuccess)
            {
//                UpdateLastLogin("-1", false);
//                MainActivity.this.clearList();
            }

        }

        @Override
        protected String doInBackground(String... params) {
            try
            {

                iTotalRecords = 0;
                iTotalUserRecords = 0;

                //clear all tables in the alt db
                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "ResetReservation";
                s = s + "</commandtext>";
                s = s + "<returnsdata>false</returnsdata>";
                s = s + "</command>";

                NetworkManagerAltSuperbowl.getInstance().MyPostRequestReturningStringAltSuperbowl(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            iTotalErrors++;

                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllUserID";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerSuperbowl.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserId = "";
                        String sUserName = "";
                        String sUserPwd = "";
                        String sSpecial = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(ksRecInd);
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalUserRecords++;
                                sFields = sRecords[idxRecords].split(ksFieldInd);
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote(ksDataInd));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "USERID":
                                        {
                                            sUserId = sValue;
                                            break;
                                        }
                                        case "USERNAME":
                                        {
                                            sUserName = sValue;
                                            break;
                                        }
                                        case "USERPWD":
                                        {
                                            sUserPwd = sValue;
                                            break;
                                        }
                                        case "SPECIAL":
                                        {
                                            sSpecial = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddUserWithIdentity " + sUserId + ", '" + sUserName.toUpperCase() + "', '" + sUserPwd
                                        + "', '" + sSpecial + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltSuperbowl.getInstance().MyPostRequestReturningStringAltSuperbowl(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);
                                            iTotalErrors++;

                                        }
                                    }
                                });
                            }

                        }
                    }
                });
                progressStatus = 10;

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllScores";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerSuperbowl.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sTeamId = "";
                        String sQuarter = "";
                        String sScore = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(ksRecInd);
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalScores++;
                                sFields = sRecords[idxRecords].split(ksFieldInd);
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote(ksDataInd));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "STEAMID":
                                        {
                                            sTeamId = sValue;
                                            break;
                                        }
                                        case "SQUARTER":
                                        {
                                            sQuarter = sValue;
                                            break;
                                        }
                                        case "SSCORE":
                                        {
                                            sScore = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddScore '" + sTeamId + "', '" + sQuarter + "', '" + sScore + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltSuperbowl.getInstance().MyPostRequestReturningStringAltSuperbowl(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);
                                            iTotalErrors++;

                                        }
                                    }
                                });
                            }

                        }
                    }
                });
                progressStatus = 20;

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllCurrentQuarter";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerSuperbowl.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sCurrentQuarter = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(ksRecInd);
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalCurrentQuarter++;
                                sFields = sRecords[idxRecords].split(ksFieldInd);
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote(ksDataInd));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "CURRENTQUARTER":
                                        {
                                            sCurrentQuarter = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddCurrentQuarter '" + sCurrentQuarter + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltSuperbowl.getInstance().MyPostRequestReturningStringAltSuperbowl(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);
                                            iTotalErrors++;

                                        }
                                    }
                                });
                            }

                        }
                    }
                });
                progressStatus = 30;

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllBonus";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerSuperbowl.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sBonusID = "";
                        String sBoxID = "";
                        String sUserID = "";
                        String sAniBoxes = "";
                        String sBonusValue = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(ksRecInd);
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                iTotalBonus++;
                                sFields = sRecords[idxRecords].split(ksFieldInd);
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote(ksDataInd));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "BONUSID":
                                        {
                                            sBonusID = sValue;
                                            break;
                                        }
                                        case "BOXID":
                                        {
                                            sBoxID = sValue;
                                            break;
                                        }
                                        case "USERID":
                                        {
                                            sUserID = sValue;
                                            break;
                                        }
                                        case "ANIBOXES":
                                        {
                                            sAniBoxes = sValue;
                                            break;
                                        }
                                        case "BONUSVALUE":
                                        {
                                            sBonusValue = sValue;
                                            break;
                                        }
                                    }
                                }

//                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
//                                s = s + "<command><commandtext>";
//                                s = s + "AddBonus '" + sBonusID + "', '" + sBoxID + "', '" + sUserID + "', '" + sAniBoxes + "', " + sBonusValue;
//                                s = s + "</commandtext>";
//                                s = s + "<returnsdata>false</returnsdata>";
//                                s = s + "</command>";

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddBonus";
                                s = s + "</commandtext>";
                                s = s + "<returnsvalues>False</returnsvalues>";

                                s = s + "<param>";
                                s = s + "<name>InBoxID</name>";
                                s = s + "<type>130</type>";
                                s = s + "<direction>1</direction>";
                                s = s + "<size>" + String.valueOf(sBoxID.length())  + "</size>";
                                s = s + "<value>" + sBoxID + "</value>";
                                s = s + "</param>";

                                s = s + "<param>";
                                s = s + "<name>InUserID</name>";
                                s = s + "<type>130</type>";
                                s = s + "<direction>1</direction>";
                                s = s + "<size>" + String.valueOf(sUserID.length()) + "</size>";
                                s = s + "<value>" + sUserID + "</value>";
                                s = s + "</param>";

                                s = s + "<param>";
                                s = s + "<name>InAniBoxes</name>";
                                s = s + "<type>130</type>";
                                s = s + "<direction>1</direction>";
                                s = s + "<size>" + String.valueOf(sAniBoxes.length()) + "</size>";
                                s = s + "<value>" + sAniBoxes + "</value>";
                                s = s + "</param>";

                                s = s + "<param>";
                                s = s + "<name>InValue</name>";
                                s = s + "<type>6</type>";
                                s = s + "<direction>1</direction>";
                                s = s + "<size>8</size>";
                                s = s + "<value>" + sBonusValue + "</value>";
                                s = s + "</param>";

                                s = s + "</command>";


                                NetworkManagerAltSuperbowl.getInstance().MyPostRequestReturningStringAltSuperbowl(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);
                                            iTotalErrors++;

                                        }
                                    }
                                });
                            }

                        }
                    }
                });
                progressStatus = 40;

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetAllDisplay";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManagerSuperbowl.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        final String sRecords[];
                        String sFields[];
                        String sField[];
                        String sUserID = "";
                        String sBoxID = "";
                        String sValue = "";

                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(ksRecInd);
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split(ksFieldInd);
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote(ksDataInd));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "BOXID":
                                        {
                                            sBoxID = sValue;
                                            break;
                                        }
                                        case "USERID":
                                        {
                                            sUserID = sValue;
                                            break;
                                        }
                                    }
                                }

                                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                                s = s + "<command><commandtext>";
                                s = s + "AddToDisplayNoOutput '" + sUserID + "', '" + sBoxID + "'";
                                s = s + "</commandtext>";
                                s = s + "<returnsdata>false</returnsdata>";
                                s = s + "</command>";

                                NetworkManagerAltSuperbowl.getInstance().MyPostRequestReturningStringAltSuperbowl(s, new MyListener<String>()
                                {
                                    @Override
                                    public void getResult(String result)
                                    {
                                        String sRecordsAddDisplay[];
                                        String sFields[];
                                        String sField[];
                                        String sReturnStatus = "";
                                        String sValue = "";

                                        if (!result.isEmpty())
                                        {
                                            //do what you need with the result...
                                            //                                Log.d("Response", result);

                                            iTotalErrors++;
                                        }
                                        else
                                        {
                                            iTotalRecords++;
                                            if (bCanIncrement)
                                            {
                                                bCanIncrement = false;
                                                progressStatus = progressStatus + 1;
                                            }
                                            else
                                            {
                                                bCanIncrement = true;
                                            }
                                            if (progressStatus > 100)
                                            {
                                                progressStatus = 100;
                                            }
                                        }
                                    }
                                });
                            }

                        }
                    }
                });
                progressStatus = 100;

                z = "Successfully copied " + String.valueOf(iTotalRecords) + " display records and \r\n" +
                                                String.valueOf(iTotalUserRecords) + " user records and \r\n" +
                                                String.valueOf(iTotalBonus) + " bonus records and \r\n" +
                                                String.valueOf(iTotalCurrentQuarter) + " current quarter records and \r\n" +
                                                String.valueOf(iTotalScores) + " scores records \r\n" +
                                                "with " + String.valueOf(iTotalErrors) + " errors.";
                isSuccess = true;
            }
            catch (Exception ex)
            {
                isSuccess = false;
                z = "Exceptions";
            }
            return z;
        }
    }

    public static class DoSendSMSMessage
    {
        boolean bCanSendSMS = false;
        void sendMessage (String sPhone, String sMessage) {

            boolean bCanSend = false;
            SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MainActivity.context);
            String sSendFrom = sharedPref.getString("forward_messages_from", "");
            String sSendTo = sharedPref.getString("forward_messages_to", "");
            if ((sharedPref.getBoolean("chkprefAllowForwardMessages", false)) && bCanSendSMS) {
                if (sSendFrom != "") {
                    if (("+" + sSendFrom).equals(sPhone)) {
                        if (sSendTo != "") {
                            bCanSend = true;
                        }
                    }
                } else {
                    if (sSendTo != "") {
                        bCanSend = true;
                    }
                }

                if (bCanSend) {
                    PendingIntent pi = PendingIntent.getActivity(MainActivity.context, 0,
                            new Intent(MainActivity.context, MainActivity.DoSendSMSMessage.class), 0);
                    SmsManager sms = SmsManager.getDefault();
                    sms.sendTextMessage(sSendTo, null, sPhone + " |" + sMessage, pi, null);
                    //Toast.makeText(MainActivity.context,  "sent message to " + sPhone + ", sMessage = " + sMessage, Toast.LENGTH_LONG).show();
                }
            }


        }
    }

    public static class DoListenForMessages
    {
        private Thread Thread1 = null;
        //private static final int SERVER_PORT = 8080;
        String message;
        private Context mainContext;
        private NotificationManagerCompat notificationManager;
        boolean bStopServer = false;
        boolean bStarted = false;
        boolean bConnected = false;
        private boolean bReadlineInitiated = false;
        private boolean bReadlineFinished = false;

        private PrintWriter output;
        private BufferedReader input;
        Socket socket;
        private PrintWriter outputFileReceivedReply;
        private BufferedReader inputFileReceivedReply;
        Socket socketFileReceivedReply;
        ServerSocket serverSocket;
        String sClientIP = "";
        TimeUtil tu = new TimeUtil();

        public int iCurrentPort = 0;

        SharedPreferences sharedPref;

        private boolean copyReceivedFile(InputStream inputStream,
                                               OutputStream out, Long length) {

            byte buf[] = new byte[512];
            int len;
            long total = 0;
            int progresspercentage = 0;
            try {
                while ((len = inputStream.read(buf)) != -1) {
                    try {
                        out.write(buf, 0, len);
                    } catch (Exception e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                    try {
                        total += len;
                        if (length > 0) {
                            ((MainActivity) mainContext).progressStatus = (int) ((total * 100) / length);
                        }
                    } catch (Exception e) {
                        // TODO: handle exception
                        e.printStackTrace();
                    }
                }
                ((MainActivity) mainContext).progressStatus = 100;
                out.close();
                inputStream.close();
            } catch (IOException e) {
                ((MainActivity) mainContext).progressStatus = 100;
                return false;
            }
            return true;
        }

        void StartServer(Context context, NotificationManagerCompat notificationManagerPassed) {


            notificationManager = notificationManagerPassed;
            mainContext = context;
            sharedPref = PreferenceManager.getDefaultSharedPreferences(mainContext);
            String SERVER_IP = NetworkUtils.getLocalIpAddress(context);
            bStarted = true;
            bStopServer = false;
            bConnected = false;
            iCurrentPort = MainActivity.gkiMessagePort;
            Thread1 = new Thread(new Thread1());
            Thread1.start();

        }

        private Handler DBUpdateHandler = new Handler() {
            public void handleMessage(Message msg) {
                MyDBHandlerMessage dbHandler = null;
                dbHandler = new MyDBHandlerMessage(mainContext, null, null, 1);
                //find the contact using the ip address
                MessageContact mc = dbHandler.findContactByIp(sClientIP);

                if (mc.getId() == 0) {
                    //didn't find contact, so need to add it
                    mc.setContactName(msg.getData().getString("message").split(Pattern.quote("|"))[0]);
                    TimeUtil tu = new TimeUtil();
                    String sInsertDate = tu.CurrentUTCDateTime();
                    mc.setContactInserted(sInsertDate);
                    mc.setContactIP(sClientIP);
                    dbHandler.addContact(mc);

                    NotificationUtils.GenerateNotification("Contact Added",
                            "Contact: " + mc.getContactName() + " added to message contacts",
                            1, null, false, mainContext,
                            notificationManager, NotificationCompat.PRIORITY_HIGH);

                    dbHandler = null;
                    dbHandler = new MyDBHandlerMessage(mainContext, null, null, 1);
                    //find the contact using the ip address
                    mc = dbHandler.findContactByIp(sClientIP);
                }

                String sInsertDate = tu.CurrentUTCDateTime();
                MessageData md = new MessageData();
                md.setDataFromContactID(mc.getId());
                md.setDataInserted(sInsertDate);
                md.setDataMessage(msg.getData().getString("message").split(Pattern.quote("|"))[1]);
                md.setDataToContactID(1);
                dbHandler.addMessage(md);

                NotificationUtils.GenerateNotification("Message Received from " + mc.getContactName(),
                        msg.getData().getString("message").split(Pattern.quote("|"))[1],
                        1, null, false, mainContext,
                        notificationManager, NotificationCompat.PRIORITY_HIGH);

            }
        };

        void StopServer() {
            bStopServer = true;
            bStarted = false;
            try {
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                socketFileReceivedReply.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                serverSocket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        class Thread1 implements Runnable {
            @Override
            public void run() {
                String saIP[];
                bConnected = false;
//            Socket socket;
                try {
//                ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
                    if (serverSocket != null) {
                        serverSocket = null;
                    }
                    serverSocket = new ServerSocket(MainActivity.gkiMessagePort);
                    try {
                        socket = serverSocket.accept();
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//                        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
                        output = new PrintWriter(socket.getOutputStream());
                        saIP = socket.getInetAddress().toString().split("/");
                        sClientIP = saIP[1];

                        bConnected = true;
                        if (!bStopServer) {
                            new Thread(new Thread3("Connected")).start();
                            //read the message
                            new Thread(new Thread2()).start();
                        }
                    } catch (IOException e) {
                        bConnected = false;
                        e.printStackTrace();
                    }
                } catch (IOException e) {
                    bConnected = false;
                    e.printStackTrace();
                }
            }
        }
        private class Thread2 implements Runnable {
            @Override
            public void run() {
                while (true) {
                    try {
                        bReadlineInitiated = true;
                        bReadlineFinished = false;
                        final String message = input.readLine();
                        bReadlineInitiated = false;
                        bReadlineFinished = true;
                        if (message != null) {
                            //is the message signalling that a file is to be received
                            // message format - message_name from settings|the message|optional - the name of a file to receive
                            String messageParts [] = message.split(Pattern.quote("|"));
                            if (messageParts.length > 2) {
                                new Thread(new Thread3File(messageParts)).start();
                                return;
                            } else {
                                //add new msg to the database
                                Bundle bundle = new Bundle();
                                bundle.putString("message", message);
                                Message msg = new Message();
                                msg.setData(bundle);
                                DBUpdateHandler.sendMessage(msg); //to add the message to the db

                                if (bStopServer) {
                                    return;
                                }
                                if (!message.isEmpty()) {
                                    //send acknowledgement to sender
                                    new Thread(new Thread3("Received")).start();
                                }

                            }
                            return;
                        } else {
                            if (!bStopServer) {
                                Thread1 = new Thread(new Thread1());
                                Thread1.start();
                            }
                            return;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
            }
        }
        class Thread3 implements Runnable {
            private String message;
            Thread3(String message) {
                this.message = message;
            }
            @Override
            public void run() {
                output.write(sharedPref.getString("message_name", "") + "|" + message + "\n");
                output.flush();
                if (message.equals("Received")){
                    try {
                        socket.close();
                        serverSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    bConnected = false;
                    bStopServer = false;
                    Thread1 = new Thread(new Thread1());
                    Thread1.start();
                }
            }
        }

        class Thread3File implements Runnable {
            private String sFilename;
            private Long lFileLength;
            private String sContactName;
            Thread3File(String messageParts []) {
                this.sContactName = messageParts[0];
                this.sFilename = messageParts[2];
                this.lFileLength = Long.parseLong(messageParts[3]);
            }
            @Override
            public void run() {
                try {
                    Log.d ("MainActivity", "Thread3File filename = = " + sFilename);
                    output.write(sharedPref.getString("message_name", "") + "|ReadyToReceiveFile\n");
                    output.flush();
                    ((MainActivity) mainContext).StartProgressBar.sendEmptyMessage(0);

                    final File f = new File(
                            Environment.getExternalStorageDirectory() + "/"
                                    + "Download/Homephones" + "/"
                                    + sFilename);

                    File dirs = new File(f.getParent());
                    if (!dirs.exists())
                        dirs.mkdirs();
                    f.createNewFile();

                    /*
                     * Recieve file length and copy after it
                     */
                    InputStream inputstream = socket.getInputStream();

                    if (copyReceivedFile(inputstream, new FileOutputStream(f),
                            lFileLength)) {
                        ((MainActivity) mainContext).progressStatus = 100;
                        Log.d ("MainActivity", "File Received - " + sFilename + " saved in Download/Homephones.");
                        NotificationUtils.GenerateNotification("File Received",
                                sFilename + " saved in Download/Homephones.",
                                1, null, false, mainContext,
                                notificationManager, NotificationCompat.PRIORITY_HIGH);

                        //add new msg to the database
                        Bundle bundle = new Bundle();
                        bundle.putString("message", sContactName + "|" +
                                sFilename + " saved in Download/Homephones.");
                        Message msg = new Message();
                        msg.setData(bundle);
                        DBUpdateHandler.sendMessage(msg); //to add the message to the db

                        if (bStopServer) {
                            return;
                        }
                        //send acknowledgement to sender

                        try {
                            socket.close();
                            serverSocket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        bConnected = false;
                        bStopServer = false;
                        Thread1 = new Thread(new Thread1());
                        Thread1.start();
                        new Thread(new ThreadStartFileReceivedReply(sClientIP, "ReceivedFile" + "|" + sFilename)).start();

                    } else {
                        Log.d ("MainActivity", "Failed to receive file - " + sFilename);
                    }


                } catch (IOException e) {
                    Log.d ("MainActivity", "Error receiving file - " + sFilename + ", Error = " + e.getMessage());
                }

            }
        }

        private class ThreadStartFileReceivedReply implements Runnable {
            private String sIPToReplyTo;
            private String sMessageToSend;
            ThreadStartFileReceivedReply(String sIPToReplyTo, String sMessageToSend) {
                this.sIPToReplyTo = sIPToReplyTo;
                this.sMessageToSend = sMessageToSend;
            }
            public void run() {
                Log.d ("MainActivity", "ThreadStartFileReceivedReply started");
                try {
                    socketFileReceivedReply = null;
                    socketFileReceivedReply = new Socket();
                    socketFileReceivedReply.connect(new InetSocketAddress(sIPToReplyTo, MainActivity.gkiMessagePort), 5000);
                    outputFileReceivedReply = new PrintWriter(socketFileReceivedReply.getOutputStream());
                    inputFileReceivedReply = new BufferedReader(new InputStreamReader(socketFileReceivedReply.getInputStream()));
                    new Thread(new Thread2FileReceivedReply(sMessageToSend)).start();
                } catch (IOException e) {
                    Toast.makeText(mainContext, "Cannot connect to send the file received message.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        }
        class Thread2FileReceivedReply implements Runnable {
            private String sMessageToSend;
            Thread2FileReceivedReply(String sMessageToSend) {
                this.sMessageToSend = sMessageToSend;
            }
            @Override
            public void run() {
                Log.d ("MainActivity", "Thread2FileReceivedReply started");
                while (true) {
                    try {
                        final String message = inputFileReceivedReply.readLine();
                        if (message != null) {
                            Log.d ("MainActivity", "Thread2FileReceivedReply message = " + message);
                            switch (message.split(Pattern.quote("|"))[1]) {
                                case "Connected":
                                {
                                    new Thread(new Thread3FileReceivedReply(sMessageToSend)).start();
                                    break;
                                }
                                case "Received":
                                {
                                    socketFileReceivedReply.close();
                                    socketFileReceivedReply = null;
                                    return;
                                }
                            }
                        } else {
                            Log.d ("MainActivity", "Thread2FileReceivedReply message is null");
                            return;
                        }
                    } catch (IOException e) {
                        Log.d ("MainActivity", "Thread2FileReceivedReply IOException = " + e.getMessage());
                        return;
                    }
                }
            }
        }
        class Thread3FileReceivedReply implements Runnable {
            private String message;
            Thread3FileReceivedReply(String message) {
                this.message = message;
            }
            @Override
            public void run() {
                outputFileReceivedReply.write(sharedPref.getString("message_name", "") + "|" + message + "\n");
                outputFileReceivedReply.flush();
            }
        }


    }

    public class DoSendFile extends AsyncTask<String,String,String> {
        private Thread Thread1 = null;
        //private static final int SERVER_PORT = 8080;
        String message;
        private Context mainContext;
        private NotificationManagerCompat notificationManager;
        boolean bStopServer = false;
        boolean bStarted = false;
        boolean bConnected = false;

        private PrintWriter output;
        private BufferedReader input;
        Socket socket;
        ServerSocket serverSocket;
        String sClientIP = "";
        TimeUtil tu = new TimeUtil();

        SharedPreferences sharedPref;

        @Override
        protected void onPreExecute() {
//            pbbar.setVisibility(View.VISIBLE);
        }

        @Override
        protected void onPostExecute(String r) {
//            pbbar.setVisibility(View.GONE);

        }

        @Override
        protected String doInBackground(String... params) {
            String z = "";


            return z;
        }
    }

    public class DoPrepareToSendFile {

        Socket socket;
        SharedPreferences  sharedPref;
        PrintWriter output;
        BufferedReader input;
        Context mainContext;
        Thread Thread1;

        void StartPrepareToSendFile (Context context, NotificationManagerCompat notificationManagerPassed) {

            notificationManager = notificationManagerPassed;
            mainContext = context;
            sharedPref = PreferenceManager.getDefaultSharedPreferences(mainContext);
            Thread1 = new Thread(new ThreadStart());
            Thread1.start();

        }

        private Handler FinishHandler = new Handler() {
            public void handleMessage(Message msg) {
                //finish();
            }
        };



        class ThreadStart implements Runnable {
            public void run() {
                try {
                    socket = null;
                    socket = new Socket();
                    socket.connect(new InetSocketAddress(mContact.getContactIP(), MainActivity.gkiMessagePort), 5000);
                    output = new PrintWriter(socket.getOutputStream());
                    input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    new Thread(new Thread2()).start();
                } catch (IOException e) {
                    e.printStackTrace();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Cannot send the file. Try again.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }
        class Thread2 implements Runnable {
            @Override
            public void run() {
                while (true) {
                    try {
                        final String message = input.readLine();
                        if (message != null) {
                            switch (message.split(Pattern.quote("|"))[1]) {
                                case "Connected":
                                {
//                                    new Thread(new Thread3(sMessageToSend)).start();
                                    break;
                                }
                                case "Received":
                                {
                                    socket.close();
                                    socket = null;
                                    FinishHandler.sendEmptyMessage(0); //to end this activity
                                    return;
                                }
                            }
                        } else {
                            Thread1 = new Thread(new ThreadStart());
                            Thread1.start();
                            return;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        Thread1 = new Thread(new ThreadStart());
                        Thread1.start();
                        return;
                    }
                }
            }
        }
        class Thread3 implements Runnable {
            private String message;
            Thread3(String message) {
                this.message = message;
            }
            @Override
            public void run() {
                output.write(sharedPref.getString("message_name", "") + "|" + message + "\n");
                output.flush();
            }
        }


    }


}


