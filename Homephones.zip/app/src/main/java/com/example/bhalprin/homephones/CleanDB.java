package com.example.bhalprin.homephones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.support.v7.app.AppCompatActivity;

import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.content.Intent;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.CalendarView;
import android.widget.TimePicker;
import android.widget.Toast;

import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;


/**
 * A login screen that offers login via username/password.
 */
public class CleanDB extends AppCompatActivity {

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private CleanDBCleanTask mCleanDBCleanTask = null;
    //    private UpdateAddTask mUpdateAddTask = null;
    private static final String TAG = "CleanDB";

    // UI references.
    private CalendarView mDateView;
    private TimePicker mTimeView;
    private View mProgressView;
    private View mCleanDBFormView;

    private int iDay;
    private int iMonth;
    private int iYear;
    private int iHourOfDay;
    private int iMinute;
    private String sCurrentDateTime;
    private String sNewDateTime;

    private int iSelectedMonth; //0 based , 0 - 11
    private int iSelectedDay;
    private int iSelectedYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clean_db);
        // Set up the login form.
        mDateView= (CalendarView) findViewById(R.id.cleandb_calendar);
        mTimeView = (TimePicker) findViewById(R.id.cleandb_timePicker);

        Button mCleanButton = (Button) findViewById(R.id.cleandb_cmdCleanDB);
        mCleanButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                attemptClean();
            }
        });

//        Button mCancelButton = (Button) findViewById(R.id.cleandb_cmdCancel);
//        mCancelButton.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                finish();
//            }
//        });
//

        TimeUtil tu = new TimeUtil();
        sCurrentDateTime = tu.CurrentDate();
        mDateView.setDate(new Date().getTime());
        mDateView.setMaxDate(new Date().getTime());

        mDateView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {

                iSelectedDay = dayOfMonth;
                iSelectedMonth = month;
                iSelectedYear = year;
            }
        });

        final Calendar c = Calendar.getInstance();
//        iYear = c.get(Calendar.YEAR);
//        iMonth = c.get(Calendar.MONTH);
//        iDay = c.get(Calendar.DAY_OF_MONTH);
        iHourOfDay = c.get(Calendar.HOUR_OF_DAY);
        iMinute = c.get(Calendar.MINUTE);
        sCurrentDateTime = sCurrentDateTime  +
                (String.valueOf(iHourOfDay).length() < 2 ? "0" + String.valueOf(iHourOfDay) : String.valueOf(iHourOfDay)) +
                (String.valueOf(iMinute).length() < 2 ? "0" + String.valueOf(iMinute) : String.valueOf(iMinute));

//        sCurrentDateTime = String.valueOf(iYear) +
//                (String.valueOf(iMonth).length() < 2 ? "0" + String.valueOf(iMonth) : String.valueOf(iMonth)) +
//                (String.valueOf(iDay).length() < 2 ? "0" + String.valueOf(iDay) : String.valueOf(iDay)) +
//                (String.valueOf(iHourOfDay).length() < 2 ? "0" + String.valueOf(iHourOfDay) : String.valueOf(iHourOfDay)) +
//                (String.valueOf(iMinute).length() < 2 ? "0" + String.valueOf(iMinute) : String.valueOf(iMinute));
//
//                //set the initial date and time to now
//        mDateView.(iYear, iMonth, iDay, null);

        mTimeView.setIs24HourView(true);
        mTimeView.setHour(iHourOfDay);
        mTimeView.setMinute(iMinute);

        mCleanDBFormView = findViewById(R.id.cleandb_cleancb_form);
        mProgressView = findViewById(R.id.cleandb_progress);

    }

    private void setReturnStatus (String sStatus)
    {
        Intent data = getIntent();
        data.putExtra("status", sStatus);
        setResult(RESULT_OK, data);
    }

    /**
     * Attempts to update the database with the entered values.
     * If there are form errors (missing name), the
     * errors are presented and no actual update attempt is made.
     */
    private void attemptClean() {
        if (mCleanDBCleanTask != null) {
            return;
        }
        final TimeUtil tu = new TimeUtil();

//        Date dt = new Date(mDateView.getDate());
//        sNewDateTime = tu.CurrentDateFromDate(dt);

        final Calendar c1 = Calendar.getInstance();
        c1.set(iSelectedYear, iSelectedMonth, iSelectedDay);

        iHourOfDay = mTimeView.getHour();
        iMinute = mTimeView.getMinute();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmm", Locale.US);
        sNewDateTime = sdf.format(c1.getTime());

        sNewDateTime = sNewDateTime +
                (String.valueOf(iHourOfDay).length() < 2 ? "0" + String.valueOf(iHourOfDay) : String.valueOf(iHourOfDay)) +
                (String.valueOf(iMinute).length() < 2 ? "0" + String.valueOf(iMinute) : String.valueOf(iMinute));

        boolean cancel = false;
        View focusView = null;

        // Check for a valid starting date/time.
        if (sNewDateTime.compareTo(sCurrentDateTime) > 0  ) {

            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Selected date/time cannot be greater than the current date/time.");

            altBx.setPositiveButton("Ok", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                }
            });
            altBx.show();
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView = mDateView;
            focusView.requestFocus();
        }
        else
        {
            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    c1.set(iSelectedYear, iSelectedMonth, iSelectedDay, iHourOfDay, iMinute, 0);
                    sNewDateTime = tu.CurrentUTCDateTimeFromDate(c1.getTime());

                    showProgress(true);
                    mCleanDBCleanTask = new CleanDBCleanTask();
                    mCleanDBCleanTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    View focusView = null;
                    focusView = mDateView;
                    focusView.requestFocus();
                }

            });
            altBx.show();
        }

    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mCleanDBFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mCleanDBFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mCleanDBFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mCleanDBFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /**
     * Represents an asynchronous task used to insert a new record.
     */
    public class CleanDBCleanTask extends AsyncTask<String, String, String>
    {
        private int iTotalToBeDeleted;
        private int iTotalInDBBefore;
        private int iTotalInDBAfterDelete;

        TimeUtil tu = new TimeUtil();
//        String mName = mNameView.getText().toString();
//        String mPhone = mPhoneView.getText().toString();
//        String mMisc = mMiscView.getText().toString();
//        String mMapInfo = mMapInfoView.getText().toString();

        @Override
        protected String doInBackground(String... params) {
            try {

                String s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetMyCountDisplay";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            sFields = result.split("<<");
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "0";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "MYCOUNT":
                                        {
                                            iTotalInDBBefore = Integer.parseInt(sValue);
                                            break;
                                        }
                                    }
                                }
                            }

                        }
                    }
                });


                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetNumberToBeRemoved";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";

                s = s + "<param>";
                s = s + "<name>InDate</name>";
                s = s + "<type>130</type>";
                s = s + "<direction>1</direction>";
                s = s + "<size>" + sNewDateTime.length() + "</size>";
                s = s + "<value>" + sNewDateTime + "</value>";
                s = s + "</param>";

                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            sFields = result.split("<<");
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "0";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "MYCOUNT":
                                        {
                                            iTotalToBeDeleted = Integer.parseInt(sValue);
                                            break;
                                        }
                                    }
                                }
                            }

                        }
                    }
                });

                //remove the deleted records

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "RemoveDeleted";
                s = s + "</commandtext>";
                s = s + "<returnsvalues>False</returnsvalues>"; //will return the new userid

                s = s + "<param>";
                s = s + "<name>InDate</name>";
                s = s + "<type>130</type>";
                s = s + "<direction>1</direction>";
                s = s + "<size>" + sNewDateTime.length() + "</size>";
                s = s + "<value>" + sNewDateTime + "</value>";
                s = s + "</param>";

                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        if (!result.isEmpty())
                        {
                        }
                    }
                });

                s = "<?xml version=\"1.0\"?>" + "\r\n";
                s = s + "<command><commandtext>";
                s = s + "GetMyCountDisplay";
                s = s + "</commandtext>";
                s = s + "<returnsdata>true</returnsdata>";
                s = s + "</command>";

                NetworkManager.getInstance().MyPostRequestReturningString(s, new MyListener<String>()
                {
                    @Override
                    public void getResult(String result)
                    {
                        String sRecords[];
                        String sFields[];
                        String sField[];
                        String sValue = "";
                        if (!result.isEmpty())
                        {
                            //do what you need with the result...
//                                Log.d("Response", result);
                            sFields = result.split("<<");
                            int idx = 0;
                            int idxRecords = 0;
                            sRecords = result.split(">>");
                            for (idxRecords = 0; idxRecords < sRecords.length; idxRecords++)
                            {
                                sFields = sRecords[idxRecords].split("<<");
                                for (idx = 0; idx < sFields.length; idx++)
                                {
                                    sField = sFields[idx].split(Pattern.quote("||"));
                                    if (sField.length > 1)
                                    {
                                        sValue = sField[1];
                                    }
                                    else
                                    {
                                        sValue = "0";
                                    }
                                    switch (sField[0].toUpperCase())
                                    {
                                        case "MYCOUNT":
                                        {
                                            iTotalInDBAfterDelete = Integer.parseInt(sValue);
                                            break;
                                        }
                                    }
                                }
                            }

                        }
                    }
                });

                return "To be deleted - " + String.valueOf(iTotalToBeDeleted) + ", Actually deleted - " + String.valueOf(iTotalInDBBefore - iTotalInDBAfterDelete);

            }
            catch (Exception e) {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mCleanDBCleanTask = null;
            showProgress(false);

            if (!sStatus.equals("0"))
            {
                setReturnStatus(sStatus);
                finish();
            } else
            {
//                mNameView.setError(getString(R.string.error_update_failed));
                mDateView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mCleanDBCleanTask = null;
            showProgress(false);
        }
    }


}

