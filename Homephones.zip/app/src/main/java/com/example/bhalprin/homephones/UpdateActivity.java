package com.example.bhalprin.homephones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.support.v7.app.AppCompatActivity;

import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

import android.util.Log;


/**
 * A login screen that offers login via username/password.
 */
public class UpdateActivity extends AppCompatActivity {

    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private UpdateAddTask mUpdateAddTask = null;
    private UpdateDeleteTask mUpdateDeleteTask = null;
    private UpdateReinstateTask mUpdateReinstateTask = null;
    private UpdateUpdateTask mUpdateUpdateTask = null;

    private static final String TAG = "UpdateActivity";

    // UI references.
    private EditText mNameView;
    private EditText mPhoneView;
    private EditText mMiscView;
    private EditText mMapInfoView;
    private View mProgressView;
    private View mUpdateFormView;
    private String sID = "";
    private String sUserID = "";

    private Boolean bDoingReinstate = false;

    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            boolean keepOriginal = true;
            try {
                StringBuilder sb = new StringBuilder(end - start);
                for (int i = start; i < end; i++) {
                    char c = source.charAt(i);
                    if (isCharAllowed(c)) // put your condition here
                        sb.append(c);
                    else
                        keepOriginal = false;
                }
                if (keepOriginal)
                    return null;
                else {
                    return sb;
//                    if (source instanceof Spanned) {
//                        SpannableString sp = new SpannableString(sb);
//                        TextUtils.copySpansFrom((Spanned) source, start, sb.length(), null, sp, 0);
//                        return sp;
//                    } else {
//                        return sb;
//                    }
                }
            } catch (Exception e) {
                return null;
            }
        }

        private boolean isCharAllowed(char c)
        {
            if (c < 128)
            {
                return MainActivity.giAllowedChars[c] == 1;
            }
            else
            {
                return false;
            }
        }
    };

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        // Set up the login form.
        mNameView = (EditText) findViewById(R.id.txtUpdateName);
        mNameView.setFilters(new InputFilter[] { filter });
        mPhoneView = (EditText) findViewById(R.id.txtUpdatePhone);
        mPhoneView.setFilters(new InputFilter[] { filter });
        mMiscView = (EditText) findViewById(R.id.txtUpdateMisc);
        mMiscView.setFilters(new InputFilter[] { filter });
        mMapInfoView = (EditText) findViewById(R.id.txtUpdateMapInfo);
        mMapInfoView.setFilters(new InputFilter[] { filter });

        Intent data = getIntent();
        if (data.hasExtra("id"))
        {
            sID = data.getExtras().getString("id");
            sUserID = data.getExtras().getString("userid");
            mNameView.setText(data.getExtras().getString("name"));
            mPhoneView.setText(data.getExtras().getString("phone"));
            mMiscView.setText(data.getExtras().getString("misc"));
            mMapInfoView.setText(data.getExtras().getString("mapinfo"));
        }
         if (data.hasExtra("doingReinstate"))
         {
             if (data.getExtras().getString("doingReinstate").equals("1")) {
                 bDoingReinstate = true;
             }
         }

         if (bDoingReinstate) {
             Button mAddButton = (Button) findViewById(R.id.update_cmdAdd);
             mAddButton.setVisibility (View.GONE);
             Button mDeleteButton = (Button) findViewById(R.id.update_cmdDelete);
             mDeleteButton.setVisibility (View.GONE);

             Button mUpdateButton = (Button) findViewById(R.id.update_cmdUpdate);
             mUpdateButton.setText("Add");
             mUpdateButton.setOnClickListener(new OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     attemptReinstate();
                 }
             });

             this.setTitle("Reinstating - " + mNameView.getText());

         } else {
             Button mAddButton = (Button) findViewById(R.id.update_cmdAdd);
             mAddButton.setOnClickListener(new OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     attemptAdd();
                 }
             });

             if ((!sID.equals("")) && (!(sID.equals(("-1"))))) //-1 means that this is a contact
             {
                 Button mDeleteButton = (Button) findViewById(R.id.update_cmdDelete);
                 mDeleteButton.setOnClickListener(new OnClickListener() {
                     @Override
                     public void onClick(View view) {
                         attemptDelete();
                     }
                 });

                 Button mUpdateButton = (Button) findViewById(R.id.update_cmdUpdate);
                 mUpdateButton.setOnClickListener(new OnClickListener() {
                     @Override
                     public void onClick(View view) {
                         attemptUpdate();
                     }
                 });

                 this.setTitle("Updating - " + mNameView.getText());
             }
             else if ((!sID.equals("")) && (sID.equals(("-1")))) //-1 means that this is a contact
             {
                 Button mDeleteButton = (Button) findViewById(R.id.update_cmdDelete);
                 mDeleteButton.setEnabled(false);

                 Button mUpdateButton = (Button) findViewById(R.id.update_cmdUpdate);
                 mUpdateButton.setEnabled(false);

                 this.setTitle("Adding - " + mNameView.getText());
             }
             else
             {
                 Button mDeleteButton = (Button) findViewById(R.id.update_cmdDelete);
                 mDeleteButton.setEnabled(false);

                 Button mUpdateButton = (Button) findViewById(R.id.update_cmdUpdate);
                 mUpdateButton.setEnabled(false);

                 this.setTitle("Adding new record");
             }
         }

        mUpdateFormView = findViewById(R.id.update_form);
        mProgressView = findViewById(R.id.update_progress);

    }

    private void setReturnStatus (String sStatus)
    {
        Intent data = getIntent();
        data.putExtra("status", sStatus);
        setResult(RESULT_OK, data);
    }

    /**
     * Attempts to update the database with the entered values.
     * If there are form errors (missing name), the
     * errors are presented and no actual update attempt is made.
     */
    private void attemptAdd() {
        if (mUpdateAddTask != null) {
            return;
        }

        // Reset errors.
        mNameView.setError(null);
        mPhoneView.setError(null);
        mMiscView.setError(null);
        mMapInfoView.setError(null);

        // Store values at the time of the login attempt.
        String sName = mNameView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid email address.
        if (TextUtils.isEmpty(sName)) {
            mNameView.setError(getString(R.string.error_field_required));
            focusView = mNameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {
            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mUpdateAddTask = new UpdateAddTask();
                    mUpdateAddTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    View focusView = null;
                    focusView = mNameView;
                    focusView.requestFocus();
                }

            });
            altBx.show();
        }

    }

    /**
     * Attempts to delete the selected record from the database
     * by setting its Deleted column to the current UTC time.
     */
    private void attemptDelete() {
        if (mUpdateDeleteTask != null) {
            return;
        }

        AlertDialog.Builder altBx = new AlertDialog.Builder(this);
        altBx.setTitle("");
        altBx.setMessage("Are you sure?");

        altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                // Reset errors.
                mNameView.setError(null);
                mPhoneView.setError(null);
                mMiscView.setError(null);
                mMapInfoView.setError(null);

                View focusView = null;

                // Show a progress spinner, and kick off a background task to
                // perform the user login attempt.
                showProgress(true);
                mUpdateDeleteTask = new UpdateDeleteTask();
                mUpdateDeleteTask.execute((String) null);
            }
        });
        altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                View focusView = null;
                focusView = mNameView;
                focusView.requestFocus();
            }

        });
        altBx.show();

    }

    /**
     * Attempts to reinstate the selected record with any new modifications into the database.
     * If there are form errors (missing name), the
     * errors are presented and no actual reinstate attempt is made.
     */
    private void attemptReinstate() {
        if (mUpdateReinstateTask != null) {
            return;
        }

        // Reset errors.
        mNameView.setError(null);
        mPhoneView.setError(null);
        mMiscView.setError(null);
        mMapInfoView.setError(null);

        // Store values at the time of the login attempt.
        String sName = mNameView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a name.
        if (TextUtils.isEmpty(sName)) {
            mNameView.setError(getString(R.string.error_field_required));
            focusView = mNameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {
            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mUpdateReinstateTask = new UpdateReinstateTask();
                    mUpdateReinstateTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    View focusView = null;
                    focusView = mNameView;
                    focusView.requestFocus();
                }

            });
            altBx.show();
        }
    }

    /**
     * Attempts to update the database with the entered values.
     * If there are form errors (missing name), the
     * errors are presented and no actual update attempt is made.
     */
    private void attemptUpdate() {
        if (mUpdateUpdateTask != null) {
            return;
        }

        // Reset errors.
        mNameView.setError(null);
        mPhoneView.setError(null);
        mMiscView.setError(null);
        mMapInfoView.setError(null);

        // Store values at the time of the login attempt.
        String sName = mNameView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a name.
        if (TextUtils.isEmpty(sName)) {
            mNameView.setError(getString(R.string.error_field_required));
            focusView = mNameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {
            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mUpdateUpdateTask = new UpdateUpdateTask();
                    mUpdateUpdateTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    View focusView = null;
                    focusView = mNameView;
                    focusView.requestFocus();
                }

            });
            altBx.show();
        }
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mUpdateFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mUpdateFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mUpdateFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mUpdateFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    /**
     * Represents an asynchronous task used to insert a new record.
     */
    public class UpdateAddTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String mName = mNameView.getText().toString();
        String mPhone = mPhoneView.getText().toString();
        String mMisc = mMiscView.getText().toString();
        String mMapInfo = mMapInfoView.getText().toString();

        @Override
        protected String doInBackground(String... params) {
            try {
                //Thread.sleep(2000);
                MyDBHandler dbHandler = new MyDBHandler(UpdateActivity.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                if (dbHandler.addDisplay(sUserID, mName, mPhone, mMisc, mMapInfo, sInsertDate))
                {
                    return "1";
                }
                else
                {
                    return "0";
                }

            }
            catch (Exception e) {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mUpdateAddTask = null;
            showProgress(false);

            if (sStatus != "0") {
                setReturnStatus(sStatus);
                finish();
            } else {
                mNameView.setError(getString(R.string.error_update_failed));
                mNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mUpdateAddTask = null;
            showProgress(false);
        }
    }

    /**
     * Represents an asynchronous task used to delete the record.
     */
    public class UpdateDeleteTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String sDeleteDate = tu.CurrentUTCDateTime();
        String dbID = sID;

        @Override
        protected String doInBackground(String... params) {
            try {
                //Thread.sleep(2000);
                MyDBHandler dbHandler = new MyDBHandler(UpdateActivity.this, null, null, 1);

                if (dbHandler.deleteDisplay(dbID, sDeleteDate))
                {
                    return "1";
                }
                else
                {
                    return "0";
                }

            }
            catch (Exception e) {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mUpdateDeleteTask = null;
            showProgress(false);

            if (sStatus != "0") {
                setReturnStatus(sStatus);
                finish();
            } else {
                mNameView.setError(getString(R.string.error_update_failed));
                mNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mUpdateDeleteTask = null;
            showProgress(false);
        }
    }

    /**
     * Represents an asynchronous task used to reinstate the current record.
     */
    public class UpdateReinstateTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String mName = mNameView.getText().toString();
        String mPhone = mPhoneView.getText().toString();
        String mMisc = mMiscView.getText().toString();
        String mMapInfo = mMapInfoView.getText().toString();
        String dbID = sID;

        @Override
        protected String doInBackground(String... params) {
            try {
                //Thread.sleep(2000);
                MyDBHandler dbHandler = new MyDBHandler(UpdateActivity.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                if (dbHandler.addDisplay(sUserID, mName, mPhone, mMisc, mMapInfo, sInsertDate))
                {
                    return "1";
                }
                else
                {
                    return "0";
                }

            }
            catch (Exception e) {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mUpdateReinstateTask = null;
            showProgress(false);

            if (sStatus != "0") {
                setReturnStatus(sStatus);
                finish();
            } else {
                mNameView.setError(getString(R.string.error_reinstate_failed));
                mNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mUpdateReinstateTask = null;
            showProgress(false);
        }
    }


    /**
     * Represents an asynchronous task used to update the current record.
     */
    public class UpdateUpdateTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String mName = mNameView.getText().toString();
        String mPhone = mPhoneView.getText().toString();
        String mMisc = mMiscView.getText().toString();
        String mMapInfo = mMapInfoView.getText().toString();
        String dbID = sID;

        @Override
        protected String doInBackground(String... params) {
            try {
                //Thread.sleep(2000);
                MyDBHandler dbHandler = new MyDBHandler(UpdateActivity.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                if (dbHandler.updateDisplay(dbID, mName, mPhone, mMisc, mMapInfo, sInsertDate))
                {
                    return "1";
                }
                else
                {
                    return "0";
                }

            }
            catch (Exception e) {
                return "0";
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mUpdateUpdateTask = null;
            showProgress(false);

            if (sStatus != "0") {
                setReturnStatus(sStatus);
                finish();
            } else {
                mNameView.setError(getString(R.string.error_update_failed));
                mNameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mUpdateUpdateTask = null;
            showProgress(false);
        }
    }

}

