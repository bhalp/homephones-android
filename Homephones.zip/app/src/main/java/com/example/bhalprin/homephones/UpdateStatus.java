package com.example.bhalprin.homephones;

/**
 * Created by bhalprin on 10/31/2016.
 */

public class UpdateStatus {
    private int miId;
    private String msLastInserted;
    private String msLastDeleted;
    private String msOrigLastInserted;
    private String msOrigLastDeleted;

    public UpdateStatus() {

    }

    public UpdateStatus(int iId, String sLastInserted, String sLastDeleted, String sOrigLastInserted, String sOrigLastDeleted)
    {
        this.miId = iId;
        this.msLastInserted = sLastInserted;
        this.msLastDeleted = sLastDeleted;
        this.msOrigLastInserted = sOrigLastInserted;
        this.msOrigLastDeleted = sOrigLastDeleted;
    }

    public UpdateStatus(String sLastInserted, String sLastDeleted, String sOrigLastInserted, String sOrigLastDeleted)
    {
        this.msLastInserted = sLastInserted;
        this.msLastDeleted = sLastDeleted;
        this.msOrigLastInserted = sOrigLastInserted;
        this.msOrigLastDeleted = sOrigLastDeleted;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public String getLastInserted()
    {
        return this.msLastInserted;
    }
    public void setLastInserted(String sValue)
    {
        this.msLastInserted = sValue;
    }
    public String getLastDeleted()
    {
        return this.msLastDeleted;
    }
    public void setLastDeleted(String sValue)
    {
        this.msLastDeleted = sValue;
    }
    public String getOrigLastInserted()
    {
        return this.msOrigLastInserted;
    }
    public void setOrigLastInserted(String sValue)
    {
        this.msOrigLastInserted = sValue;
    }
    public String getOrigLastDeleted()
    {
        return this.msOrigLastDeleted;
    }
    public void setOrigLastDeleted(String sValue)
    {
        this.msOrigLastDeleted = sValue;
    }

}
