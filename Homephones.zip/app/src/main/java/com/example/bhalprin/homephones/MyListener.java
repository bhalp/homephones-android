package com.example.bhalprin.homephones;

public interface MyListener<T>
{
    public void getResult(T String);
}

