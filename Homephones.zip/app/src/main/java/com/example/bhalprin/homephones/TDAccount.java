package com.example.bhalprin.homephones;

public class TDAccount {

    private int miId;
    private String msAccountId;
    private String msDisplayName;
    private String msAccessToken;
    private String msRefreshToken;
    private String msAccessTokenExpirationDate;

    public TDAccount() {

    }

    public TDAccount(int iId, String sAccountId, String sDisplayName, String sAccessToken, String sRefreshToken, String sAccessTokenExpirationDate)
    {
        this.miId = iId;
        this.msAccountId = sAccountId;
        this.msDisplayName = sDisplayName;
        this.msAccessToken = sAccessToken;
        this.msRefreshToken = sRefreshToken;
        this.msAccessTokenExpirationDate = sAccessTokenExpirationDate;
    }

    public TDAccount(String sAccountId, String sDisplayName, String sAccessToken, String sRefreshToken, String sAccessTokenExpirationDate)
    {
        this.msAccountId = sAccountId;
        this.msDisplayName = sDisplayName;
        this.msAccessToken = sAccessToken;
        this.msRefreshToken = sRefreshToken;
        this.msAccessTokenExpirationDate = sAccessTokenExpirationDate;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public String getAccountId()
    {
        return this.msAccountId;
    }
    public void setAccountId(String sValue)
    {
        this.msAccountId = sValue;
    }
    public String getDisplayName()
    {
        return this.msDisplayName;
    }
    public void setDisplayName(String sValue)
    {
        this.msDisplayName = sValue;
    }
    public String getAccessToken()
    {
        return this.msAccessToken;
    }
    public void setAccessToken(String sValue)
    {
        this.msAccessToken = sValue;
    }
    public String getRefreshToken()
    {
        return this.msRefreshToken;
    }
    public void setRefreshToken(String sValue)
    {
        this.msRefreshToken = sValue;
    }
    public String getAccessTokenExpirationDate()
    {
        return this.msAccessTokenExpirationDate;
    }
    public void setAccessTokenExpirationDate(String sValue) { this.msAccessTokenExpirationDate = sValue; }

}
