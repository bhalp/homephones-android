package com.example.bhalprin.homephones;

/**
 * Created by bhalprin on 9/20/2016.
 */

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import java.util.regex.Pattern;

public class MyExpandableListAdapter extends BaseExpandableListAdapter {

    private final SparseArray<DataGroup> groups;
    public LayoutInflater inflater;
    public Activity activity;
    public boolean bDoingContacts = false;
    public boolean bDoingMessageContacts = false;
    public boolean bDoingReinstate = false;

    public MyExpandableListAdapter(Activity act, SparseArray<DataGroup> groups) {
        activity = act;
        this.groups = groups;
        inflater = act.getLayoutInflater();
    }

    public MyExpandableListAdapter(Activity act, SparseArray<DataGroup> groups, int iOptions) {
        switch (iOptions){
            case 1: //doing contacts
            {
                this.bDoingContacts = true;
                break;
            }
            case 2: //doing message contacts
            {
                this.bDoingMessageContacts = true;
                break;
            }
            case 3: //doing reinstate
            {
                this.bDoingReinstate = true;
                break;
            }
        }
        activity = act;
        this.groups = groups;
        inflater = act.getLayoutInflater();
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return groups.get(groupPosition).children.get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }

    @Override
    public View getChildView(int groupPosition, final int childPosition,
                             boolean isLastChild, View convertView, ViewGroup parent) {
        final String children = (String) getChild(groupPosition, childPosition);
        final int iGroup = groupPosition;
        TextView text = null;

        if (bDoingMessageContacts) {

            if (convertView == null) {
                convertView = inflater.inflate(R.layout.listrow_details_message_last, null);
            }
            text = (TextView) convertView.findViewById(R.id.textViewMessageLast);
            Button btn = (Button) convertView.findViewById(R.id.cmdUpdateMessageLast);
            Button btnSend = (Button) convertView.findViewById(R.id.cmdSendMessageLast);
//            Button btnFiles = (Button) convertView.findViewById(R.id.cmdSendFileLast);

            String sWords [];
            sWords = children.split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
            text.setText(sWords[0]);

            if (childPosition == (groups.get(groupPosition).children.size() - 1)) {
                btn.setTag (groupPosition);
                btn.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(((MainActivity) activity), AddMessageContactActivity.class);
                        int iGroupIdx = (int)v.getTag();
                        i.putExtra("id", Integer.toString(groups.get(iGroupIdx).id));
                        i.putExtra("name", groups.get(iGroupIdx).string);
                        i.putExtra("ip", groups.get(iGroupIdx).phone);
                        ((MainActivity) activity).startActivityForResult(i, ((MainActivity) activity).MESSAGE_UPDATE_CONTACT_REQUEST);
                    }
                });

                btnSend.setTag (groupPosition);
                btnSend.setOnClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(((MainActivity) activity), MessageActivity.class);
                        int iGroupIdx = (int)v.getTag();
                        i.putExtra("id", groups.get(iGroupIdx).id);
                        i.putExtra("name", groups.get(iGroupIdx).string);
                        i.putExtra("ip", groups.get(iGroupIdx).phone);
                        i.putExtra("misc", groups.get(iGroupIdx).misc);
                        i.putExtra("groupId", iGroupIdx);
                        ((MainActivity) activity).startActivityForResult(i, ((MainActivity) activity).MESSAGE_SEND_REQUEST);
                    }
                });

//                btnFiles.setTag (groupPosition);
//                btnFiles.setOnClickListener(new OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Intent i = new Intent(((MainActivity) activity), DirectorySelectionActivity.class);
//                        int iGroupIdx = (int)v.getTag();
//                        i.putExtra("id", groups.get(iGroupIdx).id);
//                        i.putExtra("name", groups.get(iGroupIdx).string);
//                        i.putExtra("ip", groups.get(iGroupIdx).phone);
//                        ((MainActivity) activity).startActivityForResult(i, ((MainActivity) activity).MESSAGE_SELECT_FILE_TO_SEND);
//                    }
//                });
//
            }

        } else {
            //not doing message contacts
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.listrow_details, null);
            }
            text = (TextView) convertView.findViewById(R.id.textView1);
            Button btn = (Button) convertView.findViewById(R.id.cmdUpdate);
            Button btnCall = (Button) convertView.findViewById(R.id.cmdCallPhone);

            text.setText(children);
            if (((MainActivity) activity).mbCanUpdate)
            {
                btn.setTag (groupPosition);
                if (bDoingReinstate) {
                    btn.setText("Reinstate");
                    btn.setOnClickListener(new OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            if (((MainActivity) activity).mbCanUpdate)
                            {
                                Intent i = new Intent(((MainActivity) activity), UpdateActivity.class);
                                int iGroupIdx = (int)v.getTag();
                                //remove the delete date from the name
                                String sName = groups.get(iGroupIdx).string;
                                sName = sName.substring(0, sName.lastIndexOf(" ("));

                                i.putExtra("id", Integer.toString(groups.get(iGroupIdx).id));
                                i.putExtra("userid", Integer.toString(groups.get(iGroupIdx).userid));
                                i.putExtra("name", sName);
//                                i.putExtra("name", groups.get(iGroupIdx).string);
                                i.putExtra("phone", groups.get(iGroupIdx).phone);
                                i.putExtra("misc", groups.get(iGroupIdx).misc);
                                i.putExtra("mapinfo", groups.get(iGroupIdx).mapinfo);
                                i.putExtra("doingReinstate", "1");
                                ((MainActivity) activity).startActivityForResult(i, ((MainActivity) activity).REINSTATE_REQUEST);
                            }
                            else
                            {
                                Toast.makeText((MainActivity) activity, "Please enter an Update Password.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                } else {
                    if (bDoingContacts) {
                        btn.setText("Add");
                    }
                    btn.setOnClickListener(new OnClickListener() {

                        @Override
                        public void onClick(View v) {
                            if (((MainActivity) activity).mbCanUpdate)
                            {
                                Intent i = new Intent(((MainActivity) activity), UpdateActivity.class);
                                int iGroupIdx = (int)v.getTag();
                                i.putExtra("id", Integer.toString(groups.get(iGroupIdx).id));
                                i.putExtra("userid", Integer.toString(groups.get(iGroupIdx).userid));
                                i.putExtra("name", groups.get(iGroupIdx).string);
                                i.putExtra("phone", groups.get(iGroupIdx).phone);
                                i.putExtra("misc", groups.get(iGroupIdx).misc);
                                i.putExtra("mapinfo", groups.get(iGroupIdx).mapinfo);
                                ((MainActivity) activity).startActivityForResult(i, ((MainActivity) activity).UPDATE_REQUEST);
                            }
                            else
                            {
                                Toast.makeText((MainActivity) activity, "Please enter an Update Password.",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
            else
            {
                btn.setVisibility (View.GONE);
            }
            if ((!groups.get(groupPosition).phoneNumbers.isEmpty()) && (!bDoingReinstate))
            {
                btnCall.setVisibility (View.VISIBLE);
                btnCall.setTag (groupPosition);
                btnCall.setOnClickListener(new OnClickListener()
                {

                    @Override
                    public void onClick(View v)
                    {
                        int iGroupIdx = (int)v.getTag();
                        if (groups.get(iGroupIdx).phoneNumbers.size() == 1)
                        {
                            Intent i = new Intent(Intent.ACTION_DIAL);
                            String p = "tel:" + groups.get(iGroupIdx).phoneNumbers.get(0);
                            i.setData(Uri.parse(p));
                            ((MainActivity) activity).startActivity(i);
                        }
                        else
                        {
                            final CharSequence phones[] = new CharSequence[groups.get(iGroupIdx).phoneNumbers.size()];
                            for (int idx = 0; idx < groups.get(iGroupIdx).phoneNumbers.size(); idx++)
                            {
                                phones[idx] = groups.get(iGroupIdx).phoneNumbers.get(idx);
                            }

                            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                            builder.setTitle("Pick a phone number to dial");
                            builder.setItems(phones, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // the user clicked on colors[which]
                                    Intent i = new Intent(Intent.ACTION_DIAL);
                                    String p = "tel:" + phones[which];
                                    i.setData(Uri.parse(p));
                                    ((MainActivity) activity).startActivity(i);
                                }
                            });
                            builder.show();//                    Intent i = new Intent(Intent.ACTION_DIAL);
                        }
                    }
                });
            }
            else
            {
                btnCall.setVisibility (View.GONE);
            }

        }

////                    String tempString = sWords[0];
////                    SpannableString spanString = new SpannableString(tempString);
////                    spanString.setSpan(new RelativeSizeSpan(0.8f), 0, spanString.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
////                    spanString.setSpan(new TypefaceSpan("sans-serif"), 0, spanString.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
////                    spanString.setSpan(new UnderlineSpan(), 0, spanString.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);
////                    spanString.setSpan(new StyleSpan(Typeface.BOLD), 0, spanString.length(), Spanned.SPAN_INCLUSIVE_INCLUSIVE);


        return convertView;
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return groups.get(groupPosition).children.size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return groups.get(groupPosition);
    }

    @Override
    public int getGroupCount() {
        return groups.size();
    }

    @Override
    public void onGroupCollapsed(int groupPosition) {
        super.onGroupCollapsed(groupPosition);
    }

    @Override
    public void onGroupExpanded(int groupPosition) {
        super.onGroupExpanded(groupPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return 0;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded,
                             View convertView, ViewGroup parent) {

        TextView text = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.listrow_group, null);
        }
        DataGroup group = (DataGroup) getGroup(groupPosition);
        text = (TextView) convertView.findViewById(R.id.txtName);
        if (!group.sStatus.equals(""))
        {
            text.setText(group.string + " -- " + group.sStatus);
        }
        else
        {
            text.setText(group.string);
        }
        text = (TextView) convertView.findViewById(R.id.txtPhone);
        text.setText(group.phone);

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
