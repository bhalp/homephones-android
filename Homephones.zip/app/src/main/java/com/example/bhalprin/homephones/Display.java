package com.example.bhalprin.homephones;

/**
 * Update by bhalprin on 10/31/2016.
 */

public class Display {
    private int miId;
    private int miMainDBId;
    private int miUserId;
    private String msName;
    private String msPhone;
    private String msMisc;
    private String msMapInfo;
    private String msInserted;
    private String msDeleted;

    public Display() {
    }

    public Display(int iId, int iMainDBId, int iUserId, String sName, String sPhone, String sMisc, String sMapInfo, String sInserted, String sDeleted)
    {
        this.miId = iId;
        this.miMainDBId = iMainDBId;
        this.miUserId = iUserId;
        this.msName = sName;
        this.msPhone = sPhone;
        this.msMisc = sMisc;
        this.msMapInfo = sMapInfo;
        this.msInserted = sInserted;
        this.msDeleted = sDeleted;
    }

    public Display(int iMainDBId, int iUserId, String sName, String sPhone, String sMisc, String sMapInfo, String sInserted, String sDeleted)
    {
        this.miMainDBId = iMainDBId;
        this.miUserId = iUserId;
        this.msName = sName;
        this.msPhone = sPhone;
        this.msMisc = sMisc;
        this.msMapInfo = sMapInfo;
        this.msInserted = sInserted;
        this.msDeleted = sDeleted;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public int getDisplayMainDBId()
    {
        return this.miMainDBId;
    }
    public void setMainDBId(int iValue)
    {
        this.miMainDBId = iValue;
    }
    public int getDisplayUserId()
    {
        return this.miUserId;
    }
    public void setUserId(int iValue)
    {
        this.miUserId = iValue;
    }
    public String getDisplayName()
    {
        return this.msName;
    }
    public void setName(String sValue)
    {
        this.msName = sValue;
    }
    public String getDisplayPhone()
    {
        return this.msPhone;
    }
    public void setPhone(String sValue)
    {
        this.msPhone = sValue;
    }
    public String getDisplayMisc()
    {
        return this.msMisc;
    }
    public void setMisc(String sValue)
    {
        this.msMisc = sValue;
    }
    public String getDisplayMapInfo()
    {
        return this.msMapInfo;
    }
    public void setMapInfo(String sValue)
    {
        this.msMapInfo = sValue;
    }
    public String getDisplayInserted()
    {
        return this.msInserted;
    }
    public void setInserted(String sValue)
    {
        this.msInserted = sValue;
    }
    public String getDisplayDeleted()
    {
        return this.msDeleted;
    }
    public void setDeleted(String sValue)
    {
        this.msDeleted = sValue;
    }

}
