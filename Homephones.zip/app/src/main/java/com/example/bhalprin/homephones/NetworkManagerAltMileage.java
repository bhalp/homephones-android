package com.example.bhalprin.homephones;

/**
 * Created by bhalprin on 11/9/2016.
 */

import java.io.UnsupportedEncodingException;
import java.util.concurrent.CountDownLatch;

import com.android.volley.toolbox.*;
import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;


import android.content.Context;

public class NetworkManagerAltMileage {

    private static final String TAG = "NetworkManagerAltMileage";
    private static NetworkManagerAltMileage instance = null;

    private static final String getdataURL = "/mileagesite/getdata.asp";
    //    private static final String getdataURL = "http://bobsanping.homeip.net:81/homephones/getdata.asp";
    private Context callerContext;

    //for Volley API
    public RequestQueue requestQueue;

    private NetworkManagerAltMileage(Context context)
    {
        callerContext = context;
        requestQueue = Volley.newRequestQueue(context.getApplicationContext());
        //other stuf if you need
    }

    public static synchronized NetworkManagerAltMileage getInstance(Context context)
    {
        if (null == instance)
            instance = new NetworkManagerAltMileage(context);
        return instance;
    }

    //this is so you don't need to pass context each time
    public static synchronized NetworkManagerAltMileage getInstance()
    {
        if (null == instance)
        {
            throw new IllegalStateException(NetworkManagerAltMileage.class.getSimpleName() +
                    " is not initialized, call getInstance(...) first");
        }
        return instance;
    }

    public void MyPostRequestReturningStringAltMileage(final String sParam, final MyListener<String> listener)
    {

        final Object[] responseHolder = new Object[1];
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(callerContext);

        String url = "http://" + sharedPref.getString("alt_db_server_name", "") +
                ":" + sharedPref.getString("alt_db_server_port", "81") + getdataURL;

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>()
                {
                    @Override
                    public void onResponse(String response) {
                        // response
//                        Log.d("Response", response);
                        responseHolder[0] = response;
                        countDownLatch.countDown();
//                        if(null != response.toString())
//                            listener.getResult(response.toString());
                    }
                },
                new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        responseHolder[0] = error;
                        countDownLatch.countDown();
//                        Log.d("Error.Response", error.getMessage());
                    }
                }
        ) {

            @Override
            public String getBodyContentType() {
                return "application/text; charset=utf-8";
            }

            @Override
            public byte[] getBody() throws AuthFailureError {
                try {
                    return sParam.getBytes("utf-8");
                } catch (UnsupportedEncodingException uee) {
                    VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", sParam, "utf-8");
                    return null;
                }
            }
        };

        requestQueue.add(postRequest);
        try
        {
            countDownLatch.await();
        }
        catch (InterruptedException e)
        {
            throw new RuntimeException(e);
        }
        if (responseHolder[0] instanceof VolleyError)
        {
            final VolleyError volleyError = (VolleyError) responseHolder[0];
            //TODO: Handle error...
            Log.d("Error.Response", volleyError.getMessage());
        }
        else
        {
            final String response = (String) responseHolder[0];
            //TODO: Handle response...
            listener.getResult(response);
        }
    }

}
