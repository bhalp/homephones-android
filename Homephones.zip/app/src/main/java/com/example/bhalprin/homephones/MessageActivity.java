package com.example.bhalprin.homephones;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.preference.PreferenceManager;
import android.provider.OpenableColumns;
import android.renderscript.ScriptGroup;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.regex.Pattern;


public class MessageActivity extends AppCompatActivity {

    public static final int MENU_SEND_FILE_IDX = 0;
    public static final int MENU_SELECT_IDX = 1;
    public static final int MENU_DELETE_IDX = 2;

    public static final int MESSAGE_SELECT_FILE_TO_SEND = 1;

    public static DirectoryEntry mDirectoryEntry;

    public Thread Thread1 = null;
    String SERVER_IP;
    //int SERVER_PORT = 8080;

    private DoListenForMessagesMA dlm = new DoListenForMessagesMA();

    MessageContact mContact;
    SharedPreferences sharedPref;

    private PrintWriter output;
    private BufferedReader input;
    Socket socket;
    public Integer iTryConnectCnt = 0;

    public String sMessageToSend = "";

    public Boolean bDoingSelect = false;
    private DataGroup dg;
    private ListView lv;

    public EditText etMessage;
    public Button btnSend;

    private static ProgressDialog mProgressDialog;
    static int Percentage = 0;

    public static final String TAG = "MessageActivity";

    private static Boolean bDoingFileCopy = false;
    private Boolean bSendingFile = false;

    ProgressBar pbbarMessage;
    static int progressStatus = 0;
    private Handler handler = new Handler();

    public Integer iNumSelectedToDelete = 0;
    public String sBaseTitle = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        Intent data = getIntent();
        if (data.hasExtra("ip"))
        {

            pbbarMessage = (ProgressBar) findViewById(R.id.pbbarMessage);
            pbbarMessage.setVisibility(View.GONE);

            mContact = new MessageContact(data.getExtras().getInt("id"),
                    data.getExtras().getString("name"),
                    data.getExtras().getString("ip"), "","");
            SERVER_IP = data.getExtras().getString("ip");

            //tvMessages.setText(data.getExtras().getString("misc"));
            sBaseTitle = "Sending to " + mContact.getContactName();
            this.setTitle(sBaseTitle);

            lv = (ListView) findViewById(R.id.lvMessages);
            dg = MainActivity.groupsMessages.get(data.getExtras().getInt("groupId")) ;

            if (dg.messagechildren.size() == 0) {
                dg.messagechildren.add("No messages yet.");
            }
            lv.setAdapter(new MessageListAdapter(MessageActivity.this,this, dg.messagechildren, bDoingSelect, lv));
            activityVisible = true;


            etMessage = (EditText) findViewById(R.id.etMessage);
            btnSend = (Button) findViewById(R.id.btnSend);

            if (sharedPref.getBoolean("chkprefAllowMessages", false)) {
                MainActivity.dlm.StopServer();

                if (!dlm.bStarted) {
                    dlm.StartServer(this, MainActivity.notificationManager);
                }

                btnSend.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (bDoingSelect) {
                            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    switch (which){
                                        case DialogInterface.BUTTON_POSITIVE:
                                            //Yes button clicked
                                            bDoingSelect = false;
                                            setTitle(sBaseTitle);
                                            etMessage.setEnabled(true);
                                            btnSend.setEnabled(true);
                                            btnSend.setText("Send");
                                            Boolean bDeletedSomething = false;
                                            CheckBox cb;
                                            ConstraintLayout ll;
                                            for (int i = 0; i < lv.getCount(); i++) {
                                                String tmp [] = lv.getItemAtPosition(i).toString().split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
                                                if (tmp.length == 5) {
                                                    if (tmp[4].equals("1")) {
                                                        if (!bDeletedSomething) {

                                                        } else {

                                                        }
                                                        MyDBHandlerMessage dbHandler = null;
                                                        dbHandler = new MyDBHandlerMessage( MessageActivity.this, null, null, 1);
                                                        dbHandler.deleteMessage(tmp[3]);
                                                        bDeletedSomething = true;
                                                    }
                                                }
                                            }
                                            if (bDeletedSomething) {
                                                MyDBHandlerMessage dbHandler = null;
                                                dbHandler = new MyDBHandlerMessage(MessageActivity.this, null, null, 1);
                                                DataGroup gp;
                                                gp = dbHandler.getAllMessagesForContact(dg);
                                                lv.setAdapter(new MessageListAdapter(MessageActivity.this,MessageActivity.this, gp.messagechildren, bDoingSelect,lv));
                                            } else {
                                                lv.setAdapter(new MessageListAdapter(MessageActivity.this,MessageActivity.this, dg.messagechildren, bDoingSelect,lv));
                                            }
                                            invalidateOptionsMenu();
                                            break;

                                        case DialogInterface.BUTTON_NEGATIVE:
                                            //No button clicked
                                            break;
                                    }
                                }
                            };

                            AlertDialog.Builder builder = new AlertDialog.Builder(MessageActivity.this);
                            builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                                    .setNegativeButton("No", dialogClickListener).show();

                        } else {
                            iTryConnectCnt = 0;
                            sMessageToSend = etMessage.getText().toString().trim();
                            if (sMessageToSend.equals("")) {
                                etMessage.setText("");
                            } else {
                                bSendingFile = false;
                                StartThreadStart();
                            }
                        }

                    }
                });
            } else {
                etMessage.setEnabled(false);
                btnSend.setEnabled(false);
            }



        } else {
            finish();
        }

    }

    public static boolean isActivityVisible() {
        return activityVisible;
    }

    public static void activityResumed() {
        activityVisible = true;
    }

    public static void activityPaused() {
        activityVisible = false;
    }

    private static boolean activityVisible;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_message, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu) {

        if (bDoingSelect) {
            menu.getItem(MENU_SELECT_IDX).setVisible(false);
            menu.getItem(MENU_SEND_FILE_IDX).setVisible(false);
            menu.getItem(MENU_DELETE_IDX).setVisible(false);
        } else {
            menu.getItem(MENU_SELECT_IDX).setVisible(true);
            menu.getItem(MENU_SEND_FILE_IDX).setVisible(true);
            menu.getItem(MENU_DELETE_IDX).setVisible(false);
        }
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == MESSAGE_SELECT_FILE_TO_SEND) {

            mDirectoryEntry = new DirectoryEntry();

            mDirectoryEntry.uri = data.getData();
            mDirectoryEntry.mimeType = getContentResolver().getType(mDirectoryEntry.uri);

            Cursor returnCursor =
                    getContentResolver().query(mDirectoryEntry.uri, null, null, null, null);
            /*
             * Get the column indexes of the data in the Cursor,
             * move to the first row in the Cursor, get the data,
             * and display it.
             */
            int nameIndex = returnCursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = returnCursor.getColumnIndex(OpenableColumns.SIZE);
            returnCursor.moveToFirst();
            mDirectoryEntry.fileName = returnCursor.getString(nameIndex);
            mDirectoryEntry.fileLength = returnCursor.getLong(sizeIndex);

            if (returnCursor != null) {
                try {
                    returnCursor.close();
                } catch (RuntimeException rethrown) {
                    throw rethrown;
                } catch (Exception ignored) {
                }
            }
            sMessageToSend = mDirectoryEntry.uri.toString();

//            List ps = data.getData().getPathSegments();
            //ps[0] = "document", ps[1] = primary:Download/Adobe Acrobat/20170216_134546.jpg or 67E3-6141:DCIM/Camera/20170216_134546.jpg
//            data.putExtra("currentDirectoryUri", ps.get(1).toString());


//            String sDirParts [];
//            sDirParts = ps.get(1).toString().split(Pattern.quote(":"));
//            String sDir = "";
//            if (sDirParts.length > 1) {
//                sDir = File.separator + sDirParts[sDirParts.length - 1];
//            }
//            String sDevice [] = sDirParts[0].split(Pattern.quote("/"));
//            if (sDevice[sDevice.length - 1].toUpperCase().equals("PRIMARY")) {
//                //file in internal memory
//                mDirectoryEntry.directory = Environment.getExternalStorageDirectory().toString() + sDir;  // /storage/emulated/0
//            } else {
//                //file on sd card
//                mDirectoryEntry.directory = "/storage/" + sDevice[sDevice.length - 1] + sDir;
//            }
//
//            String state = Environment.getExternalStorageState();
//
//            File file = Environment.getExternalStorageDirectory();
//            File textFile = new File(mDirectoryEntry.directory);
//
//            sMessageToSend = mDirectoryEntry.directory;
//            mDirectoryEntry.fileLength = textFile.length();

            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which){
                        case DialogInterface.BUTTON_POSITIVE:
                            //Yes button clicked so send the file
                            bSendingFile = true;
                            new Thread(new ThreadStartFile()).start();
//                                    Thread1 = new Thread(new ThreadStart());
//                                    Thread1.start();
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            //No button clicked
                            break;
                    }
                }
            };

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Are you sure you want to send " + mDirectoryEntry.fileName + "?").setPositiveButton("Yes", dialogClickListener)
                    .setNegativeButton("No", dialogClickListener).show();

//
//
//
//
//
//            if (data.hasExtra("currentDirectoryUri"))
//            {
//                mDirectoryEntry = new DirectoryEntry();
//
//                mDirectoryEntry.fileName = data.getStringExtra("filename");
//                mDirectoryEntry.mimeType = data.getStringExtra("mimeType");
//
//                //currentDirectoryURI contains
//                // /tree/primary:Download/Adobe Acrobat -- internal storage
//                // /tree/67E3-6141:DCIM/Camera -- sd card
//
//                if (!data.getStringExtra("currentDirectoryUri").equals("")) {
//                    //  /storage/67E3-6141/Android/data/com.example.bhalprin.homephones/files/Download
//                    sDirParts = data.getStringExtra("currentDirectoryUri").split(Pattern.quote(":"));
//                    String sDir = "";
//                    if (sDirParts.length > 1) {
//                        sDir = File.separator + sDirParts[sDirParts.length - 1];
//                    }
//                    String sDevice [] = sDirParts[0].split(Pattern.quote("/"));
//                    if (sDevice[sDevice.length - 1].toUpperCase().equals("PRIMARY")) {
//                        //file in internal memory
//                        mDirectoryEntry.directory = Environment.getExternalStorageDirectory().toString() + sDir;  // /storage/emulated/0
//                    } else {
//                        //file on sd card
//                        mDirectoryEntry.directory = "/storage/" + sDevice[sDevice.length - 1] + sDir;
//                    }
//
//                    mContact = new MessageContact();
//                    mContact.setId(data.getIntExtra("contactID", 0));
//                    mContact.setContactIP(data.getStringExtra("contactIP"));
//                    mContact.setContactName(data.getStringExtra("contactName"));
//
//                    String state = Environment.getExternalStorageState();
//
//                    File file = Environment.getExternalStorageDirectory();
//                    File textFile = new File(mDirectoryEntry.directory + File.separator + mDirectoryEntry.fileName);
//
//                    sMessageToSend = mDirectoryEntry.directory + File.separator + mDirectoryEntry.fileName;
//                    mDirectoryEntry.fileLength = textFile.length();
//
//                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            switch (which){
//                                case DialogInterface.BUTTON_POSITIVE:
//                                    //Yes button clicked so send the file
//                                    bSendingFile = true;
//                                    new Thread(new ThreadStartFile()).start();
////                                    Thread1 = new Thread(new ThreadStart());
////                                    Thread1.start();
//                                    break;
//
//                                case DialogInterface.BUTTON_NEGATIVE:
//                                    //No button clicked
//                                    break;
//                            }
//                        }
//                    };
//
//                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
//                    builder.setMessage("Are you sure you want to send " + mDirectoryEntry.fileName + "?").setPositiveButton("Yes", dialogClickListener)
//                            .setNegativeButton("No", dialogClickListener).show();
//
////                    try {
////
////
////                    } catch (FileNotFoundException e) {
////                        // TODO: handle exception
////                        e.printStackTrace();
////                    } catch (IOException e) {
////                        // TODO Auto-generated catch block
////                        e.printStackTrace();
////                    }
//
//                } else {
//                    //shouldn't get here
//                }
//
//
////                BufferedReader reader = null;
////                try {
////                    Toast.makeText(this, "Sd card available", Toast.LENGTH_LONG).show();
////                    File file = Environment.getExternalStorageDirectory();
////                    File textFile = new File(mDirectoryEntry.directory + File.separator + mDirectoryEntry.fileName);
////
////                    System.out.println("file name is   ::" + textFile.getName());
////                    Long FileLength = textFile.length();
////                    try {
////                        String Extension = textFile.getName();
////                        Log.d("Name of File-> ", "" + Extension);
////                    } catch (Exception e) {
////                        // TODO: handle exception
////                        e.printStackTrace();
////                    }
////
////                    reader = new BufferedReader(new FileReader(textFile));
////                    NotificationUtils.GenerateNotification("Can open file",
////                            mDirectoryEntry.directory + File.separator + mDirectoryEntry.fileName,
////                            1, null, false, this,
////                            MainActivity.notificationManager, NotificationCompat.PRIORITY_HIGH);
//////                        StringBuilder textBuilder = new StringBuilder();
//////                        String line;
//////                        while((line = reader.readLine()) != null) {
//////                            textBuilder.append(line);
//////                            textBuilder.append("\n");
//////
//////                        }
//////                        String sTmp = textBuilder.toString();
//////                        textView.setText(textBuilder);
////
////                } catch (FileNotFoundException e) {
////                    // TODO: handle exception
////                    e.printStackTrace();
////                } catch (IOException e) {
////                    // TODO Auto-generated catch block
////                    e.printStackTrace();
////                }
////                finally{
////                    if(reader != null){
////                        try {
////                            reader.close();
////                        } catch (IOException e) {
////                            // TODO Auto-generated catch block
////                            e.printStackTrace();
////                        }
////                    }
////                }
//
//
//            }
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        LinearLayout main_view = (LinearLayout) findViewById(R.id.llMessages);
        switch (item.getItemId())
        {
            case R.id.menu_message_send_file:
            {
                // Use system file browser
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("*/*");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(intent, "Choose the file to Send.."), MESSAGE_SELECT_FILE_TO_SEND);


//                Intent i = new Intent(this, DirectorySelectionActivity.class);
//                i.putExtra("id", mContact.getId());
//                i.putExtra("name", mContact.getContactName());
//                i.putExtra("ip", mContact.getContactIP());
//                startActivityForResult(i, MESSAGE_SELECT_FILE_TO_SEND);
                return true;
            }

            case R.id.menu_message_select:
            {
                bDoingSelect = true;
                iNumSelectedToDelete = 0;
                etMessage.setEnabled(false);
                btnSend.setEnabled(false);
                btnSend.setText("Delete");
                lv.setAdapter(new MessageListAdapter(MessageActivity.this,this, dg.messagechildren, bDoingSelect, lv));
                invalidateOptionsMenu();
                return true;
            }
            case R.id.menu_message_delete:
            {
                this.setTitle(sBaseTitle);
                etMessage.setEnabled(true);
                btnSend.setEnabled(true);
                btnSend.setText("Send");
                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which){
                            case DialogInterface.BUTTON_POSITIVE:
                                //Yes button clicked
                                bDoingSelect = false;
                                Boolean bDeletedSomething = false;
                                CheckBox cb;
                                ConstraintLayout ll;
                                for (int i = 0; i < lv.getCount(); i++) {
                                    String tmp [] = lv.getItemAtPosition(i).toString().split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
                                    if (tmp.length == 5) {
                                        if (tmp[4].equals("1")) {
                                            if (!bDeletedSomething) {

                                            } else {

                                            }
                                            MyDBHandlerMessage dbHandler = null;
                                            dbHandler = new MyDBHandlerMessage( MessageActivity.this, null, null, 1);
                                            dbHandler.deleteMessage(tmp[3]);
                                            bDeletedSomething = true;
                                        }
                                    }
                                }
                                if (bDeletedSomething) {
                                    MyDBHandlerMessage dbHandler = null;
                                    dbHandler = new MyDBHandlerMessage(MessageActivity.this, null, null, 1);
                                    DataGroup gp;
                                    gp = dbHandler.getAllMessagesForContact(dg);
                                    lv.setAdapter(new MessageListAdapter(MessageActivity.this,MessageActivity.this, gp.messagechildren, bDoingSelect,lv));
                                } else {
                                    lv.setAdapter(new MessageListAdapter(MessageActivity.this,MessageActivity.this, dg.messagechildren, bDoingSelect,lv));
                                }
                                invalidateOptionsMenu();
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };

                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();

                return true;
            }

            default:
                return super.onOptionsItemSelected(item);
        }
    }



    @Override
    protected void onResume() {
        super.onResume();
        MessageActivity.activityResumed();
        Log.d ("MessageActivity", "onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        MessageActivity.activityPaused();
        Log.d ("MessageActivity", "onPause");
        Intent data = getIntent();
        data.putExtra("status", "1");
        setResult(RESULT_OK, data);
    }

    @Override
    public void onBackPressed() {
        if (bDoingSelect) {
            bDoingSelect = false;
            this.setTitle(sBaseTitle);
            etMessage.setEnabled(true);
            btnSend.setEnabled(true);
            btnSend.setText("Send");
            if (dg.messagechildren.size() > 0) {
                for (int idx = 0; idx < dg.messagechildren.size(); idx++) {
                    String sTmp [] = ((String) dg.messagechildren.get(idx)).split(Pattern.quote(MainActivity.gksMessageFieldSeparator));
                    if (sTmp[sTmp.length - 1].equals("1")) {
                        sTmp[sTmp.length - 1] = "0"; //reset selected flag
                        String sSep = "";
                        String sNew = "";
                        for (int idx2 = 0; idx2 < sTmp.length; idx2++) {
                            sNew = sNew + sSep + sTmp[idx2];
                            sSep = MainActivity.gksMessageFieldSeparator;
                        }
                        dg.messagechildren.set(idx, sNew);
                    }
                }
            }

            lv.setAdapter(new MessageListAdapter(MessageActivity.this,this, dg.messagechildren, bDoingSelect,lv));
            invalidateOptionsMenu();
        } else {
            dlm.StopServer();
            Intent data = getIntent();
            data.putExtra("status", "1");
            setResult(RESULT_OK, data);
            finish();
        }
//        super.onBackPressed(); //commented because if this is done this activity is closed
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MessageActivity.activityPaused();
        Log.d ("MessageActivity", "onDestroy");
    }

    @Override
    protected void onStop() {
        super.onStop();
        MessageActivity.activityPaused();
        Log.d ("MessageActivity", "onStop");
    }

    public Handler StartProgressBar = new Handler() {
        public void handleMessage(Message msg) {
            // Set the progress status zero on each button click
            progressStatus = 0;
            // Visible the progress bar and text view
            pbbarMessage.setVisibility(View.VISIBLE);

            // Start the lengthy operation in a background thread
            new Thread(new Runnable() {
                @Override
                public void run() {
                    while(progressStatus < 100){

                        // Try to sleep the thread for 20 milliseconds
                        try{
                            Thread.sleep(20);
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }

                        // Update the progress bar
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                pbbarMessage.setProgress(progressStatus);
                                // If task execution completed
                                if(progressStatus == 100){
                                    // Hide the progress bar from layout after finishing task
                                    pbbarMessage.setVisibility(View.GONE);
                                }
                            }
                        });
                    }
                }
            }).start(); // Start the operation
        }
    };


    public void StartThreadStart () {
        bSendingFile = false;
        Thread1 = new Thread(new ThreadStart());
        Thread1.start();
    }

    private Handler FinishHandler = new Handler() {
        public void handleMessage(Message msg) {
            setReturnStatus("1");
            //finish();
        }
    };

    private void RefreshMessageList () {
        MyDBHandlerMessage dbHandler = new MyDBHandlerMessage(this, null, null, 1);
        DataGroup group = dbHandler.getAllMessagesForContact(dg);
        lv.setAdapter(new MessageListAdapter(MessageActivity.this,this, group.messagechildren, bDoingSelect, lv));
        etMessage.setText("");
    }

    private void setReturnStatus (String sStatus)
    {
        Intent data = getIntent();
        data.putExtra("status", sStatus);

        TimeUtil tu = new TimeUtil();
        String sInsertDate = tu.CurrentUTCDateTime();

        MessageData mData = new MessageData();
        mData.setDataFromContactID(1);
        mData.setDataToContactID(mContact.getId());
//        if (bSendingFile) {
//            mData.setDataMessage("file sent: " + mDirectoryEntry.fileName);
//        } else {
            mData.setDataMessage(sMessageToSend);
//        }
        mData.setDataInserted(sInsertDate);

        MyDBHandlerMessage dbHandler = new MyDBHandlerMessage(this, null, null, 1);
        dbHandler.addMessage(mData);

        DataGroup group = new DataGroup();

        dbHandler = null;
        dbHandler = new MyDBHandlerMessage(this, null, null, 1);

        group = dbHandler.getAllMessagesForContact(dg);
        lv.setAdapter(new MessageListAdapter(MessageActivity.this,this, group.messagechildren, bDoingSelect, lv));
        etMessage.setText("");

        setResult(RESULT_OK, data);

    }

    public class ThreadStart implements Runnable {

        public void run() {
            try {
                iTryConnectCnt++;
                socket = null;
                socket = new Socket();
                socket.connect(new InetSocketAddress(SERVER_IP, MainActivity.gkiMessagePort), 5000);
                output = new PrintWriter(socket.getOutputStream());
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                new Thread(new Thread2()).start();
            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MessageActivity.this, "Cannot connect to send the message. Try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
    public class ThreadStartFile implements Runnable {
        public void run() {
            try {
                iTryConnectCnt++;
                socket = null;
                socket = new Socket();
                socket.connect(new InetSocketAddress(SERVER_IP, MainActivity.gkiMessagePort), 5000);
                output = new PrintWriter(socket.getOutputStream());
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                new Thread(new Thread2File()).start();
            } catch (IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MessageActivity.this, "Cannot connect to send the file. Try again.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
    public class ThreadStartFileReceivedReply implements Runnable {
        private String sIPToReplyTo;
        ThreadStartFileReceivedReply(String sIPToReplyTo) {
            this.sIPToReplyTo = sIPToReplyTo;
        }
        public void run() {
            try {
                iTryConnectCnt++;
                socket = null;
                socket = new Socket();
                socket.connect(new InetSocketAddress(sIPToReplyTo, MainActivity.gkiMessagePort), 5000);
                output = new PrintWriter(socket.getOutputStream());
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                new Thread(new Thread2FileReceivedReply()).start();
            } catch (IOException e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MessageActivity.this, "Cannot connect to send the file received message.",
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    }
    class Thread2 implements Runnable {
        @Override
        public void run() {
            Log.d ("MessageActivity", "Thread2 started");
            while (true) {
                try {
                    final String message = input.readLine();
                    if (message != null) {
                        Log.d ("MessageActivity", "Thread2 message = " + message);
                        switch (message.split(Pattern.quote("|"))[1]) {
                            case "Connected":
                            {
                                new Thread(new Thread3(sMessageToSend)).start();
                                break;
                            }
                            case "Received":
                            {
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        tvMessages.append("server: " + message + "\n");
//                                    }
//                                });
                                socket.close();
                                socket = null;
                                FinishHandler.sendEmptyMessage(0); //to end this activity
                                return;
                            }
                        }
                    } else {
                        Thread1 = new Thread(new ThreadStart());
                        Thread1.start();
                        return;
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Thread1 = new Thread(new ThreadStart());
                    Thread1.start();
                    return;
                }
            }
        }
    }
    class Thread2File implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    final String message = input.readLine();
                    if (message != null) {
                        Log.d ("MessageActivity", "Thread2File message = " + message);
                        switch (message.split(Pattern.quote("|"))[1]) {
                            case "Connected":
                            {
                                new Thread(new Thread3("SendingFile|" + mDirectoryEntry.fileName + "|" + mDirectoryEntry.fileLength)).start();
                                break;
                            }
                            case "ReadyToReceiveFile":
                            {
                                new Thread(new Thread3File(sMessageToSend)).start();
                                return;
//                                break;
                            }
                            case "Received":
                            {
//                                runOnUiThread(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        tvMessages.append("server: " + message + "\n");
//                                    }
//                                });
                                socket.close();
                                socket = null;
                                FinishHandler.sendEmptyMessage(0); //to end this activity
                                return;
                            }
                        }
                    } else {
                        Log.d ("MessageActivity", "Thread2File message is null");
//                        Thread1 = new Thread(new ThreadStart(true));
//                        Thread1.start();
//                        return;
                    }
                } catch (IOException e) {
                    Log.d ("MessageActivity", "Thread2File bDoingFileCopy = " + bDoingFileCopy + ", IOException = " + e.getMessage());
//                    if (!bDoingFileCopy && !bSendingFile) {
//                        Thread1 = new Thread(new ThreadStart());
//                        Thread1.start();
//                    }
                    return;
                }
            }
        }
    }
    class Thread2FileReceivedReply implements Runnable {
        @Override
        public void run() {
            Log.d ("MessageActivity", "Thread2FileReceivedReply started");
            while (true) {
                try {
                    final String message = input.readLine();
                    if (message != null) {
                        Log.d ("MessageActivity", "Thread2FileReceivedReply message = " + message);
                        switch (message.split(Pattern.quote("|"))[1]) {
                            case "Connected":
                            {
                                new Thread(new Thread3(sMessageToSend)).start();
                                break;
                            }
                            case "Received":
                            {
                                socket.close();
                                socket = null;
//                                FinishHandler.sendEmptyMessage(0); //to end this activity
                                return;
                            }
                        }
                    } else {
                        Log.d ("MessageActivity", "Thread2FileReceivedReply message is null");
//                        Thread1 = new Thread(new ThreadStart());
//                        Thread1.start();
                        return;
                    }
                } catch (IOException e) {
                    Log.d ("MessageActivity", "Thread2FileReceivedReply IOException = " + e.getMessage());
//                    Thread1 = new Thread(new ThreadStart());
//                    Thread1.start();
                    return;
                }
            }
        }
    }
    class Thread3 implements Runnable {
        private String message;
        Thread3(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            Log.d ("MessageActivity", "Thread3 message = " + message);
            // message format - message_name from settings|the message
            output.write(sharedPref.getString("message_name", "") + "|" + message + "\n");
            output.flush();
        }
    }
    class Thread3File implements Runnable {
        private String message;
        Thread3File(String message) {
            this.message = message;
        }
        @Override
        public void run() {
            // message contains the path of the file to send
            try {
                Log.d ("MessageActivity", "Thread3File sMessageToSend = " + sMessageToSend);
//                output.close(); //close the existing output stream
                StartProgressBar.sendEmptyMessage(0);

                OutputStream stream = socket.getOutputStream();

                InputStream is = getContentResolver().openInputStream(mDirectoryEntry.uri);

//                InputStream is = new FileInputStream(sMessageToSend);

                if (is!= null) {
                    bDoingFileCopy = true;
                    copyFile(is, stream);
                    //input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    bDoingFileCopy = false;
                    bSendingFile = false;
                    socket.close();
                    socket = null;
                }

//                output = new PrintWriter(socket.getOutputStream()); //reopen the PrintWriter output stream for later use

            } catch (IOException e) {
                Log.d ("MessageActivity", "Thread3File Error = " + e.getMessage());
            }
        }
    }

    public class DoListenForMessagesMA
    {
        private Thread Thread1L = null;
        //private static final int SERVER_PORT = 8080;
        String message;
        private Context mainContext;
        private NotificationManagerCompat notificationManager;
        Boolean bStopServer = false;
        boolean bStarted = false;
        boolean bConnected = false;
//        private boolean bReadlineInitiated = false;
//        private boolean bReadlineFinished = false;

        private PrintWriter output;
        private BufferedReader input;
        Socket socket;
        ServerSocket serverSocket;
        String sClientIP = "";
        TimeUtil tu = new TimeUtil();

        SharedPreferences sharedPref;

        void StartServer(Context context, NotificationManagerCompat notificationManagerPassed) {


            notificationManager = notificationManagerPassed;
            mainContext = context;
            sharedPref = PreferenceManager.getDefaultSharedPreferences(mainContext);
            String SERVER_IP = NetworkUtils.getLocalIpAddress(context);
            bStarted = true;
            bStopServer = false;
            bConnected = false;
            Thread1 = new Thread(new Thread1L());
            Thread1.start();

        }

        private Handler DBUpdateHandlerMA = new Handler() {
            public void handleMessage(Message msg) {
                MyDBHandlerMessage dbHandler = null;
                dbHandler = new MyDBHandlerMessage(mainContext, null, null, 1);
                //find the contact using the ip address
                MessageContact mc = dbHandler.findContactByIp(sClientIP);

                if (mc.getId() == 0) {
                    //didn't find contact, so need to add it
                    mc.setContactName(msg.getData().getString("message").split(Pattern.quote("|"))[0]);
                    TimeUtil tu = new TimeUtil();
                    String sInsertDate = tu.CurrentUTCDateTime();
                    mc.setContactInserted(sInsertDate);
                    mc.setContactIP(sClientIP);
                    dbHandler.addContact(mc);

                    NotificationUtils.GenerateNotification("Contact Added",
                            "Contact: " + mc.getContactName() + " added to message contacts",
                            1, null, false, mainContext,
                            notificationManager, NotificationCompat.PRIORITY_HIGH);

                    dbHandler = null;
                    dbHandler = new MyDBHandlerMessage(mainContext, null, null, 1);
                    //find the contact using the ip address
                    mc = dbHandler.findContactByIp(sClientIP);
                }

                String sInsertDate = tu.CurrentUTCDateTime();
                MessageData md = new MessageData();
                md.setDataFromContactID(mc.getId());
                md.setDataInserted(sInsertDate);
                md.setDataMessage(msg.getData().getString("message").split(Pattern.quote("|"))[1]);
                md.setDataToContactID(1);
                dbHandler.addMessage(md);

                NotificationUtils.GenerateNotification("Message Received from " + mc.getContactName(),
                        msg.getData().getString("message").split(Pattern.quote("|"))[1],
                        1, null, false, mainContext,
                        notificationManager, NotificationCompat.PRIORITY_HIGH);

                if (dg.id == mc.getId()) {
                    RefreshMessageList ();
                }
            }
        };

        private Handler DBUpdateHandlerMAReceivedReply = new Handler() {
            public void handleMessage(Message msg) {
                MyDBHandlerMessage dbHandler = null;
                dbHandler = new MyDBHandlerMessage(mainContext, null, null, 1);
                //find the contact using the ip address
                MessageContact mc = dbHandler.findContactByIp(sClientIP);

                if (mc.getId() == 0) {
                    //didn't find contact, so need to add it
                    mc.setContactName(msg.getData().getString("message").split(Pattern.quote("|"))[0]);
                    TimeUtil tu = new TimeUtil();
                    String sInsertDate = tu.CurrentUTCDateTime();
                    mc.setContactInserted(sInsertDate);
                    mc.setContactIP(sClientIP);
                    dbHandler.addContact(mc);

                    NotificationUtils.GenerateNotification("Contact Added",
                            "Contact: " + mc.getContactName() + " added to message contacts",
                            1, null, false, mainContext,
                            notificationManager, NotificationCompat.PRIORITY_HIGH);

                    dbHandler = null;
                    dbHandler = new MyDBHandlerMessage(mainContext, null, null, 1);
                    //find the contact using the ip address
                    mc = dbHandler.findContactByIp(sClientIP);
                }

                String sInsertDate = tu.CurrentUTCDateTime();
                MessageData md = new MessageData();
                md.setDataFromContactID(1);
                md.setDataInserted(sInsertDate);
                md.setDataMessage("File sent: " + msg.getData().getString("message").split(Pattern.quote("|"))[2]);
                md.setDataToContactID(mc.getId());
                dbHandler.addMessage(md);

                NotificationUtils.GenerateNotification("File sent to " + mc.getContactName(),
                        msg.getData().getString("message").split(Pattern.quote("|"))[2],
                        1, null, false, mainContext,
                        notificationManager, NotificationCompat.PRIORITY_HIGH);

                if (dg.id == mc.getId()) {
                    RefreshMessageList ();
                }
            }
        };

        void StopServer() {
            bStopServer = true;
            bStarted = false;
            try {
                socket.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                serverSocket.close();
//                if (bConnected) {
//                    socket.close();
//                    serverSocket.close();
//                    bConnected = false;
//                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        class Thread1L implements Runnable {
            @Override
            public void run() {
                String saIP[];
                bConnected = false;
//            Socket socket;
                try {
//                ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
                    if (serverSocket != null) {
                        serverSocket = null;
                    }
                    serverSocket = new ServerSocket(MainActivity.gkiMessagePort);
                    Log.d ("MessageActivity", "Thread1L creating new serverSocket");
                    try {
                        socket = serverSocket.accept();
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        output = new PrintWriter(socket.getOutputStream());
                        saIP = socket.getInetAddress().toString().split("/");
                        sClientIP = saIP[1];

                        bConnected = true;
                        if (!bStopServer) {
                            new Thread(new Thread3L("Connected")).start();
                            //read the message
                            new Thread(new Thread2L()).start();
                        }
                    } catch (IOException e) {
                        bConnected = false;
                        e.printStackTrace();
                    }
                } catch (IOException e) {
                    bConnected = false;
                    e.printStackTrace();
                }
            }
        }
        private class Thread2L implements Runnable {
            @Override
            public void run() {
                while (true) {
                    try {
//                        bReadlineInitiated = true;
//                        bReadlineFinished = false;
                        final String message = input.readLine();
//                        bReadlineInitiated = false;
//                        bReadlineFinished = true;
                        if (message != null) {
                            //is the message signalling that a file is to be received
                            // message format - message_name from settings|the message|optional - the name of a file to receive
                            String messageParts [] = message.split(Pattern.quote("|"));
                            if (messageParts.length > 2) {
                                if (messageParts[1].equals("ReceivedFile")) {
                                    //should be contact name|"ReceivedFile"|file name received
                                    //add new msg to the database
                                    Bundle bundle = new Bundle();
                                    bundle.putString("message", message);
                                    Message msg = new Message();
                                    msg.setData(bundle);
                                    DBUpdateHandlerMAReceivedReply.sendMessage(msg); //to add the message to the db

                                    if (bStopServer) {
                                        return;
                                    }
                                    if (!message.isEmpty()) {
                                        //send acknowledgement to sender
                                        new Thread(new Thread3L("Received")).start();
                                    }
                                } else {
                                    //going to receive a file named messageParts[2] with a length of messageParts[3]
                                    //send acknowledgement to sender
                                    new Thread(new Thread3LFile(messageParts)).start();
                                }


                                return;
                            } else {
                                //add new msg to the database
                                Bundle bundle = new Bundle();
                                bundle.putString("message", message);
                                Message msg = new Message();
                                msg.setData(bundle);
                                DBUpdateHandlerMA.sendMessage(msg); //to add the message to the db

                                if (bStopServer) {
                                    return;
                                }
                                if (!message.isEmpty()) {
                                    //send acknowledgement to sender
                                    new Thread(new Thread3L("Received")).start();
                                }
                                return;
                            }

                        } else {
                            Log.d ("MessageActivity", "Thread2L message is null, bStopServer = " + bStopServer.toString());
                            if (!bStopServer) {
                                Thread1 = new Thread(new Thread1L());
                                Thread1.start();
                            }
                            return;
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
            }
        }
        class Thread3L implements Runnable {
            private String message;
            Thread3L(String message) {
                this.message = message;
            }
            @Override
            public void run() {
                Log.d ("MessageActivity", "Thread3L message = " + message);
                output.write(sharedPref.getString("message_name", "") + "|" + message + "\n");
                output.flush();
                if (message.equals("Received")){
                    try {
                        socket.close();
                        serverSocket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    bConnected = false;
                    bStopServer = false;
                    Thread1 = new Thread(new Thread1L());
                    Thread1.start();
                }
            }
        }
        class Thread3LFile implements Runnable {
            private String sFilename;
            private Long lFileLength;
            private String sContactName;
            Thread3LFile(String messageParts []) {
                this.sContactName = messageParts[0];
                this.sFilename = messageParts[2];
                this.lFileLength = Long.parseLong(messageParts[3]);
            }
            @Override
            public void run() {
                try {
                    Log.d ("MessageActivity", "Thread3LFile filename = = " + sFilename);
                    output.write(sharedPref.getString("message_name", "") + "|ReadyToReceiveFile\n");
                    output.flush();

                    StartProgressBar.sendEmptyMessage(0);

                    //output.close(); //close the existing output stream
                    //input.close(); //close the existing input stream

//                    if (mProgressDialog == null)
//                        mProgressDialog = new ProgressDialog(mainContext,
//                                ProgressDialog.THEME_HOLO_LIGHT);
//                    final Runnable r = new Runnable() {
//
//                        public void run() {
//                            // TODO Auto-generated method stub
//                            mProgressDialog.setMessage("Receiving...");
//                            mProgressDialog.setIndeterminate(false);
//                            mProgressDialog.setMax(100);
//                            mProgressDialog.setProgress(0);
//                            mProgressDialog.setProgressNumberFormat(null);
////						mProgressDialog.setCancelable(false);
//                            mProgressDialog
//                                    .setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
//                            mProgressDialog.show();
//                        }
//                    };
//                    handler.post(r);

                    final File f = new File(
                            Environment.getExternalStorageDirectory() + "/"
                                    + "Download/Homephones" + "/"
                                    + sFilename);

                    File dirs = new File(f.getParent());
                    if (!dirs.exists())
                        dirs.mkdirs();
                    f.createNewFile();

                    /*
                     * Receive file length and copy after it
                     */
                    InputStream inputstream = socket.getInputStream();

                    if (copyReceivedFile(inputstream, new FileOutputStream(f),
                            lFileLength)) {
//                        if (mProgressDialog != null) {
//                            if (mProgressDialog.isShowing()) {
//                                mProgressDialog.dismiss();
//                            }
//                        }
                        Log.d ("MessageActivity", "File Received - " + sFilename + " saved in Download/Homephones.");
                        NotificationUtils.GenerateNotification("File Received",
                                sFilename + " saved in Download/Homephones.",
                                1, null, false, mainContext,
                                notificationManager, NotificationCompat.PRIORITY_HIGH);

                        //add new msg to the database
                        Bundle bundle = new Bundle();
                        bundle.putString("message", sContactName + "|" +
                                sFilename + " saved in Download/Homephones.");
                        Message msg = new Message();
                        msg.setData(bundle);
                        DBUpdateHandlerMA.sendMessage(msg); //to add the message to the db

                        if (bStopServer) {
                            return;
                        }
                        //send acknowledgement to sender
//                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//                        output = new PrintWriter(socket.getOutputStream());

                        try {
                            socket.close();
                            serverSocket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        bConnected = false;
                        bStopServer = false;
                        Thread1 = new Thread(new Thread1L());
                        Thread1.start();
                        sMessageToSend = "ReceivedFile" + "|" + sFilename;
                        new Thread(new ThreadStartFileReceivedReply(sClientIP)).start();

                    } else {
                        Log.d ("MessageActivity", "Failed to receive file - " + sFilename);
                    }


                } catch (IOException e) {
                    Log.d ("MessageActivity", "Error receiving file - " + sFilename + ", Error = " + e.getMessage());
                }
                progressStatus = 100;
            }
        }


    }

    public static boolean copyFile(InputStream inputStream, OutputStream out) {
        long total = 0;
        long test = 0;
        byte buf[] = new byte[512];
        int len;
        try {
            while ((len = inputStream.read(buf)) != -1) {
                out.write(buf, 0, len);
                try {
                    total += len;
                    if (mDirectoryEntry.fileLength > 0) {
                        progressStatus = (int) ((total * 100) / mDirectoryEntry.fileLength);
                    }
                } catch (Exception e) {
                    // TODO: handle exception
                    progressStatus = 100;
                }
            }
            progressStatus = 100;

            out.close();
            //inputStream.close();
        } catch (IOException e) {
            //Log.d(MainActivity.TAG, e.toString());
            progressStatus = 100;
            return false;
        }
        return true;
    }

    public static boolean copyReceivedFile(InputStream inputStream,
                                           OutputStream out, Long length) {

        byte buf[] = new byte[512];
        int len;
        long total = 0;
        int progresspercentage = 0;
        try {
            while ((len = inputStream.read(buf)) != -1) {
                try {
                    out.write(buf, 0, len);
                } catch (Exception e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                try {
                    total += len;
                    if (length > 0) {
                        progressStatus = (int) ((total * 100) / length);
                    }
                } catch (Exception e) {
                    // TODO: handle exception
                }
            }
            out.close();
            inputStream.close();
        } catch (IOException e) {
            return false;
        }
        progressStatus = 100;
        return true;
    }



}
