package com.example.bhalprin.homephones;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
/**
 * Launcher Activity for the Directory Selection sample app.
 */
public class DirectorySelectionActivity extends FragmentActivity {

    private MessageContact mContact;
    private String contactIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_directory_selection);
        if (savedInstanceState == null) {

            Intent data = getIntent();
            if (data.hasExtra("ip")) {
                mContact = new MessageContact(data.getExtras().getInt("id"),
                        data.getExtras().getString("name"),
                        data.getExtras().getString("ip"), "", "");
                contactIP = data.getExtras().getString("ip");
                getSupportFragmentManager().beginTransaction()
                        .add(R.id.container, DirectorySelectionFragment.newInstance(mContact.getContactName(),
                                mContact.getContactIP(),
                                mContact.getId()))
                        .commit();
            } else {
                finish();
            }
        }
    }
}