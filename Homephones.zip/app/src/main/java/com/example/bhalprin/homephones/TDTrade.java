package com.example.bhalprin.homephones;

public class TDTrade {

    private int miId;
    private String msAccountId;
    private String msSymbol;
    private String msDate;
    private String msAmount;
    private String msPrice;
    private String msCost;

    public TDTrade()
    {
    }

    public TDTrade(int iId, String sAccountId, String sSymbol, String sDate, String sAmount, String sPrice,  String sCost)
    {
        this.miId = iId;
        this.msAccountId = sAccountId;
        this.msSymbol = sSymbol;
        this.msDate = sDate;
        this.msAmount = sAmount;
        this.msPrice = sPrice;
        this.msCost = sCost;
    }

    public TDTrade(String sAccountId, String sSymbol, String sDate, String sAmount, String sPrice,  String sCost)
    {
        this.msAccountId = sAccountId;
        this.msSymbol = sSymbol;
        this.msDate = sDate;
        this.msAmount = sAmount;
        this.msPrice = sPrice;
        this.msCost = sCost;
    }

    public int getId()
    {
        return this.miId;
    }
    public void setId(int iValue)
    {
        this.miId = iValue;
    }
    public String getAccountId()
    {
        return this.msAccountId;
    }
    public void setAccountId(String sValue)
    {
        this.msAccountId = sValue;
    }
    public String getSymbol()
    {
        return this.msSymbol;
    }
    public void setSymbol(String sValue)
    {
        this.msSymbol = sValue;
    }
    public String getTDTradeDate()
    {
        return this.msDate;
    }
    public void setTDTradeDate(String sValue)
    {
        this.msDate = sValue;
    }
    public String getTDAmount()
    {
        return this.msAmount;
    }
    public void setTDAmount(String sValue)
    {
        this.msAmount = sValue;
    }
    public String getTDPrice()
    {
        return this.msPrice;
    }
    public void setTDPrice(String sValue)
    {
        this.msPrice = sValue;
    }
    public String getTDCost() { return this.msCost; }
    public void setTDCost(String sValue)
    {
        this.msCost = sValue;
    }

}
