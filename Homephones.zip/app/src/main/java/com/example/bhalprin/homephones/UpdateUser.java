package com.example.bhalprin.homephones;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;

import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.util.Log;
import android.util.Base64;
import android.widget.Toast;

public class UpdateUser extends AppCompatActivity {

    private UpdateuserAddTask mAuthTask = null;
    private static final String TAG = "UpdateUserActivity";

    // UI references.
    private EditText mUsernameView;
    private EditText mPasswordView;
    private EditText mPasswordRetypeView;
    private EditText mUpdatePasswordView;
    private EditText mUpdatePasswordRetypeView;
    private View mProgressView;
    private View mLoginFormView;
    private String sUserId = "";

    InputFilter filter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            boolean keepOriginal = true;
            StringBuilder sb = new StringBuilder(end - start);
            for (int i = start; i < end; i++) {
                char c = source.charAt(i);
                if (isCharAllowed(c)) // put your condition here
                    sb.append(c);
                else
                    keepOriginal = false;
            }
            if (keepOriginal)
                return null;
            else {
                if (source instanceof Spanned) {
                    SpannableString sp = new SpannableString(sb);
                    TextUtils.copySpansFrom((Spanned) source, start, sb.length(), null, sp, 0);
                    return sp;
                } else {
                    return sb;
                }
            }
        }

        private boolean isCharAllowed(char c)
        {
            if (c < 128)
            {
                return MainActivity.giAllowedCharsUserInfo[c] == 1;
            }
            else
            {
                return false;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_user);
        // Set up the login form.
        mUsernameView = (EditText) findViewById(R.id.updateuserusername);
        mUsernameView.setFilters(new InputFilter[] { filter });
        mPasswordView = (EditText) findViewById(R.id.updateuserpassword);
        mPasswordView.setFilters(new InputFilter[] { filter });
        mPasswordRetypeView = (EditText) findViewById(R.id.updateuserpassword_retype);
        mPasswordRetypeView.setFilters(new InputFilter[] { filter });
        mUpdatePasswordView = (EditText) findViewById(R.id.updateuserupdatepassword);
        mUpdatePasswordView.setFilters(new InputFilter[] { filter });
        mUpdatePasswordRetypeView = (EditText) findViewById(R.id.updateuserupdatepassword_retype);
        mUpdatePasswordRetypeView.setFilters(new InputFilter[] { filter });

        Intent data = getIntent();
        if (data.hasExtra("userid"))
        {
            sUserId = data.getExtras().getString("userid");
            mUsernameView.setText(data.getExtras().getString("username"));
            mPasswordView.setText(data.getExtras().getString("browsepwd"));
            mPasswordRetypeView.setText(data.getExtras().getString("browsepwd"));
            mUpdatePasswordView.setText(data.getExtras().getString("updatepwd"));
            mUpdatePasswordRetypeView.setText(data.getExtras().getString("updatepwd"));
        }



        Button mAddButton = (Button) findViewById(R.id.updateuser_cmdUpdateUser);
        mAddButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view)
            {
                attemptUpdateuser();
            }
        });

        mLoginFormView = findViewById(R.id.updateuser_form);
        mProgressView = findViewById(R.id.update_user_progress);

    }

    private void setUserID (String sUsername, String sPassword, String sUpdatePassword)
    {
        Intent data = getIntent();
        data.putExtra("username", sUsername);
        data.putExtra("password", sPassword);
        data.putExtra("updatepassword", sUpdatePassword);
        setResult(RESULT_OK, data);
    }

    /**
     * Attempts to sign in or register the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptUpdateuser() {
        if (mAuthTask != null) {
            return;
        }

        // Reset errors.
        mUsernameView.setError(null);
        mPasswordView.setError(null);
        mPasswordRetypeView.setError(null);
        mUpdatePasswordView.setError(null);
        mUpdatePasswordRetypeView.setError(null);

        // Store values at the time of the update attempt.
        String username = mUsernameView.getText().toString();
        String password = mPasswordView.getText().toString();
        String passwordretype = mPasswordRetypeView.getText().toString();
        String updatepassword = mUpdatePasswordView.getText().toString();
        String updatepasswordretype = mUpdatePasswordRetypeView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password.
        if (!isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid password.
        if (!isPasswordValid(updatepassword)) {
            mUpdatePasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mUpdatePasswordView;
            cancel = true;
        }

        // Check for a matching passwords.
        if (!password.equals(passwordretype)) {
            mPasswordView.setError(getString(R.string.error_passwords_dont_match));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a matching updatepasswords.
        if (!updatepassword.equals(updatepasswordretype)) {
            mUpdatePasswordView.setError(getString(R.string.error_passwords_dont_match));
            focusView = mUpdatePasswordView;
            cancel = true;
        }

        // Check for a valid user name.
        if (TextUtils.isEmpty(username)) {
            mUsernameView.setError(getString(R.string.error_field_required));
            focusView = mUsernameView;
            cancel = true;
        }

        if (cancel)
        {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        }
        else
        {

            AlertDialog.Builder altBx = new AlertDialog.Builder(this);
            altBx.setTitle("");
            altBx.setMessage("Are you sure?");

            altBx.setPositiveButton("Yes", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    // Show a progress spinner, and kick off a background task to
                    // perform the user login attempt.
                    showProgress(true);
                    mAuthTask = new UpdateuserAddTask();
                    mAuthTask.execute((String) null);
                }
            });
            altBx.setNegativeButton("No", new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int which)
                {
                    mUsernameView.requestFocus();
                }

            });
            altBx.show();
        }

    }

    private boolean isPasswordValid(String password)
    {
        return !(password.length() < 1);
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    private void showProgress(final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = getResources().getInteger(android.R.integer.config_shortAnimTime);

            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
            mLoginFormView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mLoginFormView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }


    /**
     * Represents an asynchronous task used to insert a new user record.
     */
    public class UpdateuserAddTask extends AsyncTask<String, String, String>
    {

        TimeUtil tu = new TimeUtil();
        String username = mUsernameView.getText().toString();
        String password = mPasswordView.getText().toString();
        String updatepassword = mUpdatePasswordView.getText().toString();

        @Override
        protected String doInBackground(String... params) {
            try {

                MyDBHandler dbHandler = new MyDBHandler(UpdateUser.this, null, null, 1);
                String sInsertDate = tu.CurrentUTCDateTime();

                String password64 = Base64.encodeToString( password.toUpperCase().getBytes(), Base64.DEFAULT );
                String updatepassword64 = Base64.encodeToString( updatepassword.toUpperCase().getBytes(), Base64.DEFAULT );

                //check for duplicate username
                Userid us = null;
                us = dbHandler.findUserid(username);
                String sReturn = "";
                if (us == null) //should never happen - this should be the user being changed
                {
                    //this is ok - the username is being changed
                    sReturn = "1"; //ok so far
                }
                else
                {
                    //this is ok if the userid is the same as the one being updated
                    if (String.valueOf(us.getUserId()).equals(sUserId))
                    {
                        sReturn = "1";
                    }
                    else
                    {
                        sReturn = "2";
                    }
                }
                if (sReturn.equals("1"))
                {
                    dbHandler.updateUserid(sUserId, username.toUpperCase(), password64.substring(0,password64.length() - 1), updatepassword64.substring(0,updatepassword64.length() - 1), sInsertDate );
                    return "1"; //success
                }
                else
                {
                    return sReturn;
                }

            }
            catch (Exception e) {
                return e.getMessage(); //exception occurred
            }
        }

        @Override
        protected void onPostExecute(String sStatus) {
            mAuthTask = null;
            showProgress(false);

            if (sStatus.equals("1")) {
                setUserID(username, password, updatepassword);
                finish();
            }
            else if (sStatus.equals("2"))
            {
                mUsernameView.setError(getString(R.string.error_adduser_user_already_exists));
                mUsernameView.requestFocus();
            }
            else
            {
                mUsernameView.setError(sStatus);
                mUsernameView.requestFocus();
            }
        }

        @Override
        protected void onCancelled() {
            mAuthTask = null;
            showProgress(false);
        }
    }

}

